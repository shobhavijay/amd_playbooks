"""
multiply_images.py — generate N recipe JPEGs on-demand from a small base set.

Purpose
-------
Flood the vLLM / Ray pipeline with many inference requests WITHOUT shipping a
huge image corpus to the GPU box. Ship only the ~13 base recipes, then expand
to any N impromptu on the target machine.

Modes (choose based on what you want to stress)
-----------------------------------------------
  stamp   (default) — copy each image and stamp a UNIQUE request-ID onto it.
                      Changes the OCR'd text, so every request produces a
                      DIFFERENT downstream 72B prompt. This DEFEATS vLLM prefix
                      caching → real GPU compute on every request. Use this to
                      genuinely saturate the GPU.
  symlink           — zero-disk symlinks cycling the base set. Instant and uses
                      no extra disk, but images are byte-identical → vLLM prefix
                      cache serves most requests cheaply (inflated throughput).
                      Use ONLY to test Ray scheduling, not GPU saturation.
  copy              — plain byte copies. Defeats file-level dedup but NOT prefix
                      caching (decoded pixels are identical). Rarely what you want.

The argument is a MULTIPLIER: it makes N copies of EACH base image.
With 13 base recipes:
  N=1  → 13 images  (one copy of each)
  N=2  → 26 images  (each recipe duplicated once)
  N=100 → 1300 images
Every output gets a unique request-ID stamp, so even copies of the same recipe
are byte-distinct (defeats vLLM prefix caching).

Usage
-----
  # 2× each recipe → 26 stamped images (your simple test)
  python multiply_images.py 2 --out data_flood --clean

  # 100× each recipe → 1300 images for GPU flooding
  python multiply_images.py 100 --out data_flood --clean

  # zero-disk symlinks (scheduling test only)
  python multiply_images.py 50 --mode symlink --out data_flood

Then point the Ray benchmark at the generated directory:
  python benchmark_pipeline_ray.py --images data_flood --flood --concurrency 32
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

IMAGE_EXTS = {".jpeg", ".jpg", ".png"}


def _base_images(base_dir: Path) -> list[Path]:
    """Return real base images, excluding macOS ._ AppleDouble stubs."""
    imgs = sorted(
        p for p in base_dir.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS
        and not p.name.startswith("._")
    )
    if not imgs:
        raise SystemExit(f"No base images found in {base_dir}")
    return imgs


def _stamp(src: Path, dst: Path, req_id: str) -> None:
    """
    Copy `src` to `dst` with a small unique `req_id` stamped in the corner.
    The stamp changes the OCR text so each variant yields a distinct prompt,
    defeating vLLM prefix caching.
    """
    from PIL import Image, ImageDraw

    img = Image.open(src).convert("RGB")
    draw = ImageDraw.Draw(img)
    # White plate behind the text so it stays legible on any background,
    # then black text — a real, OCR-able token unique to this variant.
    draw.rectangle((3, 3, 3 + 9 * len(req_id), 20), fill=(255, 255, 255))
    draw.text((5, 5), req_id, fill=(0, 0, 0))
    img.save(dst, "JPEG", quality=92)


def main() -> None:
    ap = argparse.ArgumentParser(description="Multiply recipe JPEGs for load testing")
    ap.add_argument("multiplier", type=int,
                    help="how many copies of EACH base image (N=2 → 2× every recipe)")
    ap.add_argument("--base", default="data", help="base image dir (default: data)")
    ap.add_argument("--out", default="data_flood", help="output dir (default: data_flood)")
    ap.add_argument("--mode", choices=["stamp", "symlink", "copy"], default="stamp",
                    help="stamp=unique (defeats prefix cache), symlink=zero-disk, copy=plain")
    ap.add_argument("--clean", action="store_true", help="wipe the output dir first")
    args = ap.parse_args()

    base = _base_images(Path(args.base))
    out = Path(args.out)
    if args.clean and out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    total = args.multiplier * len(base)
    print(f"Generating {args.multiplier}× {len(base)} base recipes = {total} images "
          f"(mode={args.mode}) → {out}")

    idx = 0
    for copy_n in range(args.multiplier):
        for src in base:
            req_id = f"REQ-{idx:06d}"
            dst = out / f"{src.stem}_c{copy_n}_{req_id}{src.suffix}"

            if args.mode == "symlink":
                if dst.exists() or dst.is_symlink():
                    dst.unlink()
                dst.symlink_to(src.resolve())
            elif args.mode == "copy":
                shutil.copy2(src, dst)
            else:  # stamp
                _stamp(src, dst, req_id)

            idx += 1
            if idx % 500 == 0:
                print(f"  {idx}/{total}")

    print(f"✓ Generated {total} images in {out}  ({args.multiplier}× each of {len(base)} recipes, mode={args.mode})")


if __name__ == "__main__":
    main()
