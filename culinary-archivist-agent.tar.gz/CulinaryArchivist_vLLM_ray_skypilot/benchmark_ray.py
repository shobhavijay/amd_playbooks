"""
CulinaryArchivist — Ray Benchmark
===================================
Uses Ray remote actors as load generators to measure vLLM performance
under true parallel pressure (no GIL, each actor has its own event loop).

Architecture under test
-----------------------
  Ray actors (this script)
       │
       ├─► Ray Serve gateway :8080  /chat /vision /embed /ocr
       │       └─► vLLM :8000-8003   (E2E through Ray Serve layer)
       │
       └─► vLLM direct :8000-8003    (TTFT + ITL via streaming; bypasses gateway)

Two targets
-----------
  gateway  — measures end-to-end latency INCLUDING Ray Serve actor overhead
  vllm     — measures TTFT + ITL directly; isolates vLLM performance

Concurrency sweep
-----------------
Runs each endpoint at concurrency levels 1 → 2 → 4 → 8 (configurable).
At each level: N actors × R requests each, all launched in parallel via ray.get().
This reveals the "knee" where latency starts degrading faster than throughput grows.

Usage
-----
  # Full sweep — gateway E2E + vLLM direct TTFT, all endpoints
  python benchmark_ray.py

  # Gateway only, custom sweep
  python benchmark_ray.py --target gateway --concurrency 1 2 4 8 16

  # vLLM direct text TTFT only
  python benchmark_ray.py --target vllm --suite text --concurrency 1 4 8

  # Save report
  python benchmark_ray.py --output results_ray.json

Prerequisites
-------------
  Ray Serve gateway running:   python -m ray_serve.serve_app
  vLLM servers running:        vllm serve ... (ports 8000-8003)
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import statistics
import time
from pathlib import Path
from typing import Any

import ray
import requests as _requests  # used only for health check outside actors

# ── Endpoint config ────────────────────────────────────────────────────────────

GATEWAY_URL      = "http://localhost:8080"
VLLM_TEXT_URL    = "http://localhost:8000/v1"
VLLM_VISION_URL  = "http://localhost:8001/v1"
VLLM_EMBED_URL   = "http://localhost:8002/v1"
VLLM_OCR_URL     = "http://localhost:8003/v1"

TEXT_MODEL   = "Qwen/Qwen2.5-72B-Instruct"
#TEXT_MODEL   = "Qwen/Qwen2.5-32B-Instruct"
VISION_MODEL = "Qwen/Qwen2.5-VL-7B-Instruct"
EMBED_MODEL  = "BAAI/bge-m3"
OCR_MODEL    = "stepfun-ai/GOT-OCR2_0"

# ── Representative prompts from the actual pipeline ───────────────────────────

TEXT_PROMPTS = [
    {
        "label": "short_classify",
        "messages": [
            {"role": "system", "content": "You are a recipe region classifier. Reply with JSON only."},
            {"role": "user",   "content": 'Classify: Sambar with drumstick, tamarind, toor dal. Output: {"region":"...","confidence":0.0}'},
        ],
        "max_tokens": 64,
    },
    {
        "label": "medium_evaluate",
        "messages": [
            {"role": "system", "content": "You are a culinary historian. Evaluate recipe transcription quality on a 0-1 scale."},
            {"role": "user",   "content": (
                "Recipe: Grilled Halloumi with Ezme Salsa. Ingredients: 250g halloumi, 2 tomatoes, "
                "1 red onion, parsley, pomegranate molasses, olive oil, lemon.\n"
                'Output JSON: {"quality_score":0.0,"issues":[],"region":""}'
            )},
        ],
        "max_tokens": 256,
    },
    {
        "label": "long_historian",
        "messages": [
            {"role": "system", "content": "You are a culinary historian. Enrich the recipe with historical context."},
            {"role": "user",   "content": (
                "Enrich: Sameya Payasam — South Indian dessert, broken wheat, jaggery, "
                "coconut milk, cardamom, ghee. Kerala festival dish.\n"
                "Provide: origin, historical period, cultural significance, regional variants, substitutions."
            )},
        ],
        "max_tokens": 1024,
    },
]

EMBED_TEXTS = [
    "Sambar with drumstick and tamarind",
    "Grilled halloumi with ezme salsa and pomegranate molasses",
    "Sameya payasam broken wheat jaggery coconut milk Kerala festival dessert",
    "Rolled mushroom omelette with herbs",
    "North Indian dal makhani with cream and butter",
    "Thai green curry with galangal and kaffir lime",
    "Turkish baklava with pistachios and honey syrup",
    "Cypriot lountza cured pork tenderloin with coriander seeds",
]

_DATA_DIR = Path(__file__).parent / "data"
_IMAGES   = sorted(_DATA_DIR.glob("*.jpeg")) + sorted(_DATA_DIR.glob("*.jpg")) + sorted(_DATA_DIR.glob("*.png"))
_IMAGE_B64: str = (
    base64.b64encode(_IMAGES[0].read_bytes()).decode() if _IMAGES
    else "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAAR"
         "CAABAAEDASIAAhEBAxEB/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAA"
         "AAAAAAAAAAAAAP/aAAwDAQACEQMRAD8AKwABmX/Z"
)

VISION_PROMPT = (
    "Transcribe this recipe image. Extract: recipe name, ingredients with quantities, "
    "and preparation steps. Output JSON with keys: name, ingredients, steps."
)

OCR_PROMPT_NOTE = "Single image passed; GOT-OCR2_0 ignores text prompt — image_b64 is the only input."


# ── Stats helpers ──────────────────────────────────────────────────────────────

def _pct(data: list[float]) -> dict[str, float]:
    if not data:
        return {}
    s = sorted(data)
    n = len(s)
    return {
        "min":  round(s[0], 1),
        "p50":  round(statistics.median(s), 1),
        "p95":  round(s[min(int(n * 0.95), n - 1)], 1),
        "p99":  round(s[min(int(n * 0.99), n - 1)], 1),
        "max":  round(s[-1], 1),
        "mean": round(statistics.mean(s), 1),
    }


# ══════════════════════════════════════════════════════════════════════════════
#  RAY ACTORS — one class per target/endpoint combination
#
#  Each actor is a separate process managed by Ray.  It holds its own HTTP
#  client and runs requests in a tight loop.  ray.get() on the returned refs
#  blocks until all actors finish, giving true parallel pressure on the server.
# ══════════════════════════════════════════════════════════════════════════════

@ray.remote
class GatewayWorker:
    """
    Hits the Ray Serve gateway (:8080) for all four endpoints.
    Non-streaming — measures E2E latency including the Ray Serve actor hop.
    """

    def __init__(self, worker_id: int):
        import requests
        self._id      = worker_id
        self._session = requests.Session()

    def run_chat(self, n_requests: int, prompt_idx: int = 0) -> list[dict]:
        prompt = TEXT_PROMPTS[prompt_idx % len(TEXT_PROMPTS)]
        results = []
        for _ in range(n_requests):
            t0 = time.perf_counter()
            resp = self._session.post(
                f"{GATEWAY_URL}/chat",
                json={
                    "messages":    prompt["messages"],
                    "max_tokens":  prompt["max_tokens"],
                    "temperature": 0.0,
                },
                timeout=300,
            )
            e2e_ms = round((time.perf_counter() - t0) * 1000, 1)
            ok = resp.status_code == 200
            out_len = len(resp.json().get("content", "")) if ok else 0
            results.append({"label": prompt["label"], "e2e_ms": e2e_ms, "ok": ok, "chars": out_len})
        return results

    def run_vision(self, n_requests: int) -> list[dict]:
        results = []
        for _ in range(n_requests):
            t0 = time.perf_counter()
            resp = self._session.post(
                f"{GATEWAY_URL}/vision",
                json={"prompt": VISION_PROMPT, "image_b64": _IMAGE_B64, "max_tokens": 512, "temperature": 0.0},
                timeout=300,
            )
            e2e_ms = round((time.perf_counter() - t0) * 1000, 1)
            ok = resp.status_code == 200
            results.append({"label": "vision_recipe_ocr", "e2e_ms": e2e_ms, "ok": ok})
        return results

    def run_embed(self, n_requests: int) -> list[dict]:
        results = []
        for _ in range(n_requests):
            t0 = time.perf_counter()
            resp = self._session.post(
                f"{GATEWAY_URL}/embed",
                json={"texts": EMBED_TEXTS},
                timeout=60,
            )
            e2e_ms = round((time.perf_counter() - t0) * 1000, 1)
            ok = resp.status_code == 200
            n_vecs = len(resp.json().get("embeddings", [])) if ok else 0
            results.append({"label": "embed_batch", "e2e_ms": e2e_ms, "ok": ok, "n_vecs": n_vecs})
        return results

    def run_ocr(self, n_requests: int) -> list[dict]:
        results = []
        for _ in range(n_requests):
            t0 = time.perf_counter()
            resp = self._session.post(
                f"{GATEWAY_URL}/ocr",
                json={"image_b64": _IMAGE_B64},
                timeout=300,
            )
            e2e_ms = round((time.perf_counter() - t0) * 1000, 1)
            ok = resp.status_code == 200
            results.append({"label": "ocr_recipe", "e2e_ms": e2e_ms, "ok": ok})
        return results


@ray.remote
class VllmStreamWorker:
    """
    Hits vLLM servers directly (:8000-8003) with streaming enabled.
    Captures TTFT and ITL by recording per-token timestamps.

    Why direct (not through gateway): the Ray Serve gateway buffers the full
    response before returning — streaming is not wired in gateway.py.
    Streaming directly gives true TTFT and inter-token latency numbers.
    """

    def __init__(self, worker_id: int):
        from openai import OpenAI
        self._id          = worker_id
        self._text_client = OpenAI(base_url=VLLM_TEXT_URL,   api_key="EMPTY", timeout=300)
        self._vis_client  = OpenAI(base_url=VLLM_VISION_URL, api_key="EMPTY", timeout=300)
        self._emb_client  = OpenAI(base_url=VLLM_EMBED_URL,  api_key="EMPTY", timeout=60)

    def run_text_stream(self, n_requests: int, prompt_idx: int = 0) -> list[dict]:
        prompt = TEXT_PROMPTS[prompt_idx % len(TEXT_PROMPTS)]
        results = []
        for _ in range(n_requests):
            timestamps: list[float] = []
            start = time.perf_counter()
            stream = self._text_client.chat.completions.create(
                model=TEXT_MODEL,
                messages=prompt["messages"],
                max_tokens=prompt["max_tokens"],
                temperature=0.0,
                stream=True,
            )
            for chunk in stream:
                if chunk.choices and (chunk.choices[0].delta.content or ""):
                    timestamps.append(time.perf_counter())
            end = time.perf_counter()

            ttft_ms = round((timestamps[0] - start) * 1000, 1) if timestamps else 0.0
            itl_ms  = [round((timestamps[i] - timestamps[i-1]) * 1000, 1)
                       for i in range(1, len(timestamps))]
            e2e_ms  = round((end - start) * 1000, 1)
            results.append({
                "label":    prompt["label"],
                "ttft_ms":  ttft_ms,
                "itl_ms":   itl_ms,
                "e2e_ms":   e2e_ms,
                "n_tokens": len(timestamps),
            })
        return results

    def run_vision_e2e(self, n_requests: int) -> list[dict]:
        results = []
        for _ in range(n_requests):
            start = time.perf_counter()
            resp = self._vis_client.chat.completions.create(
                model=VISION_MODEL,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{_IMAGE_B64}"}},
                        {"type": "text", "text": VISION_PROMPT},
                    ],
                }],
                max_tokens=512,
                temperature=0.0,
            )
            e2e_ms  = round((time.perf_counter() - start) * 1000, 1)
            n_toks  = resp.usage.completion_tokens if resp.usage else 0
            results.append({"label": "vision_direct", "e2e_ms": e2e_ms, "n_tokens": n_toks})
        return results

    def run_embed_e2e(self, n_requests: int) -> list[dict]:
        results = []
        for _ in range(n_requests):
            start = time.perf_counter()
            resp = self._emb_client.embeddings.create(model=EMBED_MODEL, input=EMBED_TEXTS)
            e2e_ms = round((time.perf_counter() - start) * 1000, 1)
            results.append({"label": "embed_direct", "e2e_ms": e2e_ms, "n_vecs": len(resp.data)})
        return results


# ══════════════════════════════════════════════════════════════════════════════
#  SWEEP RUNNER
#  For each concurrency level: spawn N actors, fire R requests each, collect.
# ══════════════════════════════════════════════════════════════════════════════

def _flatten(nested: list[list[dict]]) -> list[dict]:
    return [item for sublist in nested for item in sublist]


def sweep_gateway_chat(
    concurrency_levels: list[int],
    requests_per_actor: int = 3,
) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors = [GatewayWorker.remote(i) for i in range(n)]
        futures = [a.run_chat.remote(requests_per_actor, i % len(TEXT_PROMPTS))
                   for i, a in enumerate(actors)]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es  = [r["e2e_ms"] for r in all_results if r["ok"]]
        errors = sum(1 for r in all_results if not r["ok"])
        tput   = round(len(e2es) / (sum(e2es) / 1000), 2) if e2es else 0
        pcts   = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  p99={pcts.get('p99','?')}ms  tput={tput} req/s  errors={errors}")
        rows.append({"concurrency": n, "errors": errors, "throughput_req_s": tput, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


def sweep_gateway_vision(concurrency_levels: list[int], requests_per_actor: int = 2) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors = [GatewayWorker.remote(i) for i in range(n)]
        futures = [a.run_vision.remote(requests_per_actor) for a in actors]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es  = [r["e2e_ms"] for r in all_results if r["ok"]]
        errors = sum(1 for r in all_results if not r["ok"])
        pcts   = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  p99={pcts.get('p99','?')}ms  errors={errors}")
        rows.append({"concurrency": n, "errors": errors, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


def sweep_gateway_embed(concurrency_levels: list[int], requests_per_actor: int = 5) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors = [GatewayWorker.remote(i) for i in range(n)]
        futures = [a.run_embed.remote(requests_per_actor) for a in actors]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es   = [r["e2e_ms"] for r in all_results if r["ok"]]
        errors = sum(1 for r in all_results if not r["ok"])
        total_vecs = sum(r.get("n_vecs", 0) for r in all_results if r["ok"])
        vec_s  = round(total_vecs / (sum(e2es) / 1000), 0) if e2es else 0
        pcts   = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  {vec_s:.0f} vec/s  errors={errors}")
        rows.append({"concurrency": n, "errors": errors, "throughput_vec_s": vec_s, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


def sweep_gateway_ocr(concurrency_levels: list[int], requests_per_actor: int = 2) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors = [GatewayWorker.remote(i) for i in range(n)]
        futures = [a.run_ocr.remote(requests_per_actor) for a in actors]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es   = [r["e2e_ms"] for r in all_results if r["ok"]]
        errors = sum(1 for r in all_results if not r["ok"])
        pcts   = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  p99={pcts.get('p99','?')}ms  errors={errors}")
        rows.append({"concurrency": n, "errors": errors, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


def sweep_vllm_text_stream(concurrency_levels: list[int], requests_per_actor: int = 3) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors = [VllmStreamWorker.remote(i) for i in range(n)]
        futures = [a.run_text_stream.remote(requests_per_actor, i % len(TEXT_PROMPTS))
                   for i, a in enumerate(actors)]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        ttfts = [r["ttft_ms"]  for r in all_results if r["ttft_ms"] > 0]
        itls  = [v for r in all_results for v in r["itl_ms"]]
        e2es  = [r["e2e_ms"]   for r in all_results]
        total_toks = sum(r["n_tokens"] for r in all_results)
        tput  = round(total_toks / (sum(e2es) / 1000), 1) if e2es else 0

        print(f"TTFT p50={_pct(ttfts).get('p50','?')}ms  ITL p50={_pct(itls).get('p50','?')}ms  "
              f"E2E p50={_pct(e2es).get('p50','?')}ms  {tput} tok/s")
        rows.append({
            "concurrency":       n,
            "throughput_tok_s":  tput,
            "ttft_ms":           _pct(ttfts),
            "itl_ms":            _pct(itls),
            "e2e_ms":            _pct(e2es),
        })
    return rows


def sweep_vllm_vision(concurrency_levels: list[int], requests_per_actor: int = 2) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors  = [VllmStreamWorker.remote(i) for i in range(n)]
        futures = [a.run_vision_e2e.remote(requests_per_actor) for a in actors]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es  = [r["e2e_ms"] for r in all_results]
        total_toks = sum(r.get("n_tokens", 0) for r in all_results)
        tput  = round(total_toks / (sum(e2es) / 1000), 1) if e2es else 0
        pcts  = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  p99={pcts.get('p99','?')}ms  {tput} tok/s")
        rows.append({"concurrency": n, "throughput_tok_s": tput, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


def sweep_vllm_embed(concurrency_levels: list[int], requests_per_actor: int = 5) -> list[dict]:
    rows = []
    for n in concurrency_levels:
        print(f"    concurrency={n:>2}  ({n * requests_per_actor} total requests) ...", end=" ", flush=True)
        actors  = [VllmStreamWorker.remote(i) for i in range(n)]
        futures = [a.run_embed_e2e.remote(requests_per_actor) for a in actors]
        all_results = _flatten(ray.get(futures))
        for a in actors:
            ray.kill(a)

        e2es      = [r["e2e_ms"] for r in all_results]
        total_vecs = sum(r.get("n_vecs", 0) for r in all_results)
        vec_s     = round(total_vecs / (sum(e2es) / 1000), 0) if e2es else 0
        pcts      = _pct(e2es)
        print(f"p50={pcts.get('p50','?')}ms  {vec_s:.0f} vec/s")
        rows.append({"concurrency": n, "throughput_vec_s": vec_s, **{f"e2e_{k}": v for k, v in pcts.items()}})
    return rows


# ── Health checks ─────────────────────────────────────────────────────────────

def _check_endpoint(url: str, label: str) -> bool:
    try:
        r = _requests.get(url, timeout=3)
        print(f"  {label:<30} ✓  ({r.status_code})")
        return True
    except Exception as e:
        print(f"  {label:<30} ✗  ({e})")
        return False


def run_health_checks(target: str) -> bool:
    print("\n  Endpoint health checks:")
    ok = True
    if target in ("gateway", "all"):
        ok &= _check_endpoint(f"{GATEWAY_URL}/health", f"Gateway  {GATEWAY_URL}/health")
    if target in ("vllm", "all"):
        ok &= _check_endpoint(f"{VLLM_TEXT_URL.replace('/v1','')}/health", f"vLLM text   :{VLLM_TEXT_URL.split(':')[2].split('/')[0]}")
        ok &= _check_endpoint(f"{VLLM_VISION_URL.replace('/v1','')}/health", f"vLLM vision :{VLLM_VISION_URL.split(':')[2].split('/')[0]}")
        ok &= _check_endpoint(f"{VLLM_EMBED_URL.replace('/v1','')}/health", f"vLLM embed  :{VLLM_EMBED_URL.split(':')[2].split('/')[0]}")
    return ok


# ── Pretty print helpers ───────────────────────────────────────────────────────

def _section(title: str) -> None:
    print(f"\n{'─' * 64}")
    print(f"  {title}")
    print(f"{'─' * 64}")


def _print_sweep_table(rows: list[dict], metric_keys: list[str]) -> None:
    if not rows:
        return
    header = f"  {'conc':>5}  " + "  ".join(f"{k:>12}" for k in metric_keys)
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in rows:
        vals = [str(row.get(k, "—")) for k in metric_keys]
        print(f"  {row['concurrency']:>5}  " + "  ".join(f"{v:>12}" for v in vals))


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    parser = argparse.ArgumentParser(description="CulinaryArchivist Ray benchmark")
    parser.add_argument(
        "--target",
        choices=["gateway", "vllm", "all"],
        default="all",
        help="gateway=Ray Serve :8080  vllm=direct :8000-8003  all=both",
    )
    parser.add_argument(
        "--suite",
        choices=["text", "vision", "embed", "ocr", "all"],
        default="all",
    )
    parser.add_argument(
        "--concurrency",
        nargs="+",
        type=int,
        default=[1, 2, 4, 8],
        metavar="N",
        help="Concurrency levels to sweep (default: 1 2 4 8)",
    )
    parser.add_argument(
        "--requests",
        type=int,
        default=3,
        help="Requests per actor per concurrency level (default 3)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="",
        help="Write JSON report to this file",
    )
    args = parser.parse_args()

    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  CulinaryArchivist — Ray Benchmark  (AMD MI350X)             ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(f"  target={args.target}  suite={args.suite}  "
          f"concurrency={args.concurrency}  requests/actor={args.requests}")

    if _IMAGES:
        print(f"  Image for vision/OCR: {_IMAGES[0].name}")
    else:
        print("  No image in data/ — using 1×1 placeholder for vision/OCR")

    # Health checks (soft — we continue even if some endpoints are down)
    run_health_checks(args.target)

    # Init Ray — connects to an existing cluster if RAY_ADDRESS is set,
    # otherwise starts a local Ray instance on this machine.
    print("\n  Initialising Ray...")
    ray.init(ignore_reinit_error=True)
    print(f"  Ray cluster resources: {ray.cluster_resources()}")

    report: dict[str, Any] = {
        "timestamp":   time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "target":      args.target,
        "suite":       args.suite,
        "concurrency": args.concurrency,
        "image":       _IMAGES[0].name if _IMAGES else "placeholder",
    }

    # ── Gateway sweeps ─────────────────────────────────────────────────────────
    if args.target in ("gateway", "all"):

        if args.suite in ("text", "all"):
            _section(f"GATEWAY /chat  (Qwen2.5-32B via Ray Serve)")
            rows = sweep_gateway_chat(args.concurrency, args.requests)
            report["gateway_chat"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "throughput_req_s", "errors"])

        if args.suite in ("vision", "all"):
            _section(f"GATEWAY /vision  (Qwen2.5-VL-7B via Ray Serve)")
            rows = sweep_gateway_vision(args.concurrency, max(1, args.requests // 2))
            report["gateway_vision"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "errors"])

        if args.suite in ("embed", "all"):
            _section(f"GATEWAY /embed  (bge-m3 via Ray Serve)  batch={len(EMBED_TEXTS)}")
            rows = sweep_gateway_embed(args.concurrency, args.requests)
            report["gateway_embed"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "throughput_vec_s", "errors"])

        if args.suite in ("ocr", "all"):
            _section(f"GATEWAY /ocr  (GOT-OCR2_0 via Ray Serve)")
            rows = sweep_gateway_ocr(args.concurrency, max(1, args.requests // 2))
            report["gateway_ocr"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "errors"])

    # ── vLLM direct sweeps (streaming → TTFT + ITL) ────────────────────────────
    if args.target in ("vllm", "all"):

        if args.suite in ("text", "all"):
            _section(f"vLLM DIRECT :8000  (Qwen2.5-32B, streaming)")
            rows = sweep_vllm_text_stream(args.concurrency, args.requests)
            report["vllm_text"] = rows
            for row in rows:
                print(f"  conc={row['concurrency']:>2}  "
                      f"TTFT p50={row['ttft_ms'].get('p50','?')}ms p99={row['ttft_ms'].get('p99','?')}ms  "
                      f"ITL p50={row['itl_ms'].get('p50','?')}ms  "
                      f"{row['throughput_tok_s']} tok/s")

        if args.suite in ("vision", "all"):
            _section(f"vLLM DIRECT :8001  (Qwen2.5-VL-7B)")
            rows = sweep_vllm_vision(args.concurrency, max(1, args.requests // 2))
            report["vllm_vision"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "throughput_tok_s"])

        if args.suite in ("embed", "all"):
            _section(f"vLLM DIRECT :8002  (bge-m3)  batch={len(EMBED_TEXTS)}")
            rows = sweep_vllm_embed(args.concurrency, args.requests)
            report["vllm_embed"] = rows
            _print_sweep_table(rows, ["e2e_p50", "e2e_p99", "throughput_vec_s"])

    # ── Final summary ──────────────────────────────────────────────────────────
    print(f"\n{'═' * 64}")
    print("  SUMMARY  (p50 ms at each concurrency level)")
    print(f"{'═' * 64}")

    def _row_summary(key: str, metric: str, label: str) -> None:
        if key not in report:
            return
        vals = "  ".join(
            f"c{r['concurrency']}={r.get(metric, r.get(f'{metric}_p50', '?'))}ms"
            for r in report[key]
        )
        print(f"  {label:<38} {vals}")

    _row_summary("gateway_chat",   "e2e_p50",  "Gateway /chat E2E")
    _row_summary("gateway_vision", "e2e_p50",  "Gateway /vision E2E")
    _row_summary("gateway_embed",  "e2e_p50",  "Gateway /embed E2E")
    _row_summary("gateway_ocr",    "e2e_p50",  "Gateway /ocr E2E")

    if "vllm_text" in report:
        vals = "  ".join(
            f"c{r['concurrency']}={r['ttft_ms'].get('p50','?')}ms"
            for r in report["vllm_text"]
        )
        print(f"  {'vLLM text TTFT':<38} {vals}")
        vals = "  ".join(
            f"c{r['concurrency']}={r['itl_ms'].get('p50','?')}ms"
            for r in report["vllm_text"]
        )
        print(f"  {'vLLM text ITL':<38} {vals}")

    _row_summary("vllm_vision", "e2e_p50", "vLLM vision E2E")
    _row_summary("vllm_embed",  "e2e_p50", "vLLM embed E2E")

    ray.shutdown()

    if args.output:
        Path(args.output).write_text(json.dumps(report, indent=2))
        print(f"\n  Report written → {args.output}")
    else:
        print("\n  (pass --output results_ray.json to save the full report)")


if __name__ == "__main__":
    main()
