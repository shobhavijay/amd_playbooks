#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Deploy the state plane to the HOST cluster and prove both vclusters can reach
# it. Run this on the MI300X box. Idempotent — safe to re-run.
#
#   ./k8s/state-plane-gate.sh              deploy + verify, print the settings
#   ./k8s/state-plane-gate.sh --verify     verify only, change nothing
#   ./k8s/state-plane-gate.sh --wire       ALSO point the agent at the state plane
#   ./k8s/state-plane-gate.sh --unwire     put the agent back on sqlite/hostPath
#
# Deploying and wiring are deliberately separate. Running the gate to check
# connectivity must not silently change which backend the next demo run uses.
#
# The step that matters is 6. A pod inside a vcluster resolves DNS through the
# vcluster's own CoreDNS, which knows nothing about host-cluster services, so
# `postgres.archivist-state.svc.cluster.local` may not resolve there. Step 6
# tries DNS first, falls back to the Service ClusterIP (vcluster pods are real
# host pods and share host pod networking), and tells you which one to use.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

HOST_CTX="${HOST_CTX:-default}"
NS="archivist-state"
TENANTS=(team-a team-b)
VERIFY_ONLY=false; WIRE=false; UNWIRE=false
case "${1:-}" in
  --verify) VERIFY_ONLY=true ;;
  --wire)   WIRE=true ;;
  --unwire) UNWIRE=true ;;
  "")       ;;
  *) echo "usage: $(basename "$0") [--verify|--wire|--unwire]" >&2; exit 2 ;;
esac

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ok(){ printf '  \033[32m✓\033[0m %s\n' "$*"; }
no(){ printf '  \033[31m✗\033[0m %s\n' "$*"; }
warn(){ printf '  \033[33m!\033[0m %s\n' "$*"; }
hdr(){ printf '\n\033[1m%s\033[0m\n' "$*"; }

# ── 1. context sanity ────────────────────────────────────────────────────────
hdr "1. Contexts"
kubectl --context "$HOST_CTX" get nodes >/dev/null 2>&1 \
  || { no "host context '$HOST_CTX' unreachable — set HOST_CTX=<name>"; exit 1; }
NODES=$(kubectl --context "$HOST_CTX" get nodes --no-headers | wc -l | tr -d ' ')
ok "host context '$HOST_CTX' reachable — $NODES node(s)"
[[ "$NODES" -gt 1 ]] && warn "more than one node: pin Postgres to a node (local-path PVs are node-bound)"

for T in "${TENANTS[@]}"; do
  CTX="vcluster_${T}_${T}_default"
  kubectl --context "$CTX" get ns >/dev/null 2>&1 \
    && ok "vcluster context $CTX reachable" \
    || { no "vcluster context $CTX unreachable"; exit 1; }
done

if $UNWIRE; then
  hdr "Unwiring — the agent returns to sqlite on the hostPath"
  for T in "${TENANTS[@]}"; do
    CTX="vcluster_${T}_${T}_default"
    kubectl --context "$CTX" -n default delete secret archivist-state-env \
      --ignore-not-found >/dev/null && ok "$T: archivist-state-env removed"
  done
  echo
  echo "  The state plane itself is untouched and still holds your data."
  echo "  envFrom in archivist.sky.yaml is optional:true, so the next run just"
  echo "  finds no Secret and falls back to sqlite/persistent/local."
  exit 0
fi

# ── 2. credentials (generated here, never committed) ─────────────────────────
hdr "2. Credentials"
if kubectl --context "$HOST_CTX" -n "$NS" get secret archivist-state-secrets >/dev/null 2>&1; then
  ok "secret archivist-state-secrets already exists — leaving it alone"
else
  $VERIFY_ONLY && { no "secret missing and --verify given"; exit 1; }
  kubectl --context "$HOST_CTX" create namespace "$NS" --dry-run=client -o yaml \
    | kubectl --context "$HOST_CTX" apply -f - >/dev/null
  # Alphanumeric only: a '/' or '+' in the password would need escaping in the
  # postgresql:// DSN that config.py builds.
  gen(){ LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 32; }
  kubectl --context "$HOST_CTX" -n "$NS" create secret generic archivist-state-secrets \
    --from-literal=POSTGRES_PASSWORD="$(gen)" \
    --from-literal=MINIO_ROOT_PASSWORD="$(gen)" >/dev/null
  ok "generated archivist-state-secrets (32-char alphanumeric)"
fi

# ── 3. apply ─────────────────────────────────────────────────────────────────
hdr "3. Manifests"
if $VERIFY_ONLY; then
  warn "--verify: skipping apply"
else
  kubectl --context "$HOST_CTX" apply -f "$HERE/state-plane.yaml" | sed 's/^/  /'
fi

# ── 4. wait for rollout ──────────────────────────────────────────────────────
hdr "4. Rollout"
for D in postgres chroma minio; do
  if kubectl --context "$HOST_CTX" -n "$NS" rollout status "deploy/$D" --timeout=180s >/dev/null 2>&1; then
    ok "$D ready"
  else
    no "$D not ready — kubectl --context $HOST_CTX -n $NS describe deploy/$D"
    kubectl --context "$HOST_CTX" -n "$NS" get pods -l "app=$D" | sed 's/^/      /'
    exit 1
  fi
done

PGPW=$(kubectl --context "$HOST_CTX" -n "$NS" get secret archivist-state-secrets -o jsonpath='{.data.POSTGRES_PASSWORD}' | base64 -d)
MCPW=$(kubectl --context "$HOST_CTX" -n "$NS" get secret archivist-state-secrets -o jsonpath='{.data.MINIO_ROOT_PASSWORD}' | base64 -d)
PG_CIP=$(kubectl --context "$HOST_CTX" -n "$NS" get svc postgres -o jsonpath='{.spec.clusterIP}')
CH_CIP=$(kubectl --context "$HOST_CTX" -n "$NS" get svc chroma   -o jsonpath='{.spec.clusterIP}')
MN_CIP=$(kubectl --context "$HOST_CTX" -n "$NS" get svc minio    -o jsonpath='{.spec.clusterIP}')

# ── 5. which heartbeat path does this Chroma answer on? ──────────────────────
hdr "5. Chroma API version"
CHROMA_HB=""
for P in /api/v2/heartbeat /api/v1/heartbeat; do
  # A throwaway curl pod: the MinIO server image has no curl of its own.
  if kubectl --context "$HOST_CTX" -n "$NS" run "hb-$RANDOM" --rm -i --restart=Never --quiet \
       --image=curlimages/curl:latest --command -- \
       curl -sf -m 5 "http://chroma:8000$P" >/dev/null 2>&1; then
    CHROMA_HB="$P"; ok "chroma answers on $P"; break
  fi
done
[[ -z "$CHROMA_HB" ]] && warn "no heartbeat path answered — check: kubectl -n $NS logs deploy/chroma"

# ── 6. THE GATE — reach the state plane from inside each vcluster ────────────
hdr "6. Reachability from inside each vcluster"
DNS_NAME="postgres.$NS.svc.cluster.local"
RECOMMENDED=""
for T in "${TENANTS[@]}"; do
  CTX="vcluster_${T}_${T}_default"
  for MODE in dns clusterip; do
    [[ $MODE == dns ]] && HOSTVAL="$DNS_NAME" || HOSTVAL="$PG_CIP"
    POD="gate-$T-$MODE-$RANDOM"
    if kubectl --context "$CTX" run "$POD" --rm -i --restart=Never --quiet \
         --image=postgres:16-alpine \
         --env="PGPASSWORD=$PGPW" --command -- \
         psql -h "$HOSTVAL" -U archivist -d archivist -tAc 'select 1' >/dev/null 2>&1; then
      ok "$T → postgres via $MODE ($HOSTVAL)"
      [[ $MODE == dns && -z "$RECOMMENDED" ]] && RECOMMENDED="dns"
    else
      no "$T → postgres via $MODE ($HOSTVAL)"
      [[ $MODE == dns ]] && warn "expected on stock vcluster — see networking.replicateServices.fromHost"
    fi
  done
done
[[ -z "$RECOMMENDED" ]] && RECOMMENDED="clusterip"

# ── 7. MinIO bucket ──────────────────────────────────────────────────────────
hdr "7. MinIO bucket"
if $VERIFY_ONLY; then
  warn "--verify: skipping bucket creation"
else
  kubectl --context "$HOST_CTX" -n "$NS" run mc-init-$RANDOM --rm -i --restart=Never --quiet \
    --image=minio/mc:latest --command -- sh -c \
    "mc alias set local http://minio:9000 archivist '$MCPW' >/dev/null && \
     mc mb --ignore-existing local/archivist >/dev/null && echo created" >/dev/null 2>&1 \
    && ok "bucket 'archivist' present" \
    || warn "bucket step failed — create manually via the mc image"
fi

# ── 8. the values config.py needs ────────────────────────────────────────────
hdr "8. Settings for the agent (work package B)"
if [[ "$RECOMMENDED" == dns ]]; then
  PGH="$DNS_NAME"; CHH="chroma.$NS.svc.cluster.local"; MNH="minio.$NS.svc.cluster.local"
  echo "  resolution: in-vcluster DNS works — using service names"
else
  PGH="$PG_CIP"; CHH="$CH_CIP"; MNH="$MN_CIP"
  echo "  resolution: DNS did NOT work from the tenants — using Service ClusterIPs"
  echo "  (stable for the life of the Service; re-run this script if you recreate them)"
fi
cat <<EOF

  # Three independent switches — adopt them one at a time if you prefer.
  # On a single node only the Postgres one buys anything (fencing).
  ARCHIVIST_STATE_BACKEND=postgres
  ARCHIVIST_CHROMA_MODE=server
  ARCHIVIST_BLOB_STORE=s3

  ARCHIVIST_PG_DSN=postgresql://archivist:${PGPW}@${PGH}:5432/archivist
  ARCHIVIST_CHROMA_HOST=${CHH}
  ARCHIVIST_CHROMA_PORT=8000
  ARCHIVIST_S3_ENDPOINT=http://${MNH}:9000
  ARCHIVIST_S3_BUCKET=archivist
  ARCHIVIST_S3_ACCESS_KEY=archivist
  ARCHIVIST_S3_SECRET_KEY=${MCPW}

  ⚠ contains live credentials — do not paste into a file you commit.
EOF

# ── 9. wire the agent to the state plane (opt-in) ────────────────────────────
hdr "9. Wiring"
if $WIRE; then
  # The host-cluster Secret is invisible from inside a vcluster, so each tenant
  # gets its own copy in `default` — the namespace the agent pod lands in, and
  # the same place tenant-info lives.
  for T in "${TENANTS[@]}"; do
    CTX="vcluster_${T}_${T}_default"
    kubectl --context "$CTX" -n default delete secret archivist-state-env \
      --ignore-not-found >/dev/null
    kubectl --context "$CTX" -n default create secret generic archivist-state-env \
      --from-literal=ARCHIVIST_STATE_BACKEND=postgres \
      --from-literal=ARCHIVIST_CHROMA_MODE=server \
      --from-literal=ARCHIVIST_BLOB_STORE=s3 \
      --from-literal=ARCHIVIST_EMBED_BACKEND=local \
      --from-literal=ARCHIVIST_PG_DSN="postgresql://archivist:${PGPW}@${PGH}:5432/archivist" \
      --from-literal=ARCHIVIST_CHROMA_HOST="${CHH}" \
      --from-literal=ARCHIVIST_CHROMA_PORT=8000 \
      --from-literal=ARCHIVIST_S3_ENDPOINT="http://${MNH}:9000" \
      --from-literal=ARCHIVIST_S3_BUCKET=archivist \
      --from-literal=ARCHIVIST_S3_ACCESS_KEY=archivist \
      --from-literal=ARCHIVIST_S3_SECRET_KEY="${MCPW}" >/dev/null
    ok "$T: archivist-state-env created in namespace default"
  done
  echo
  echo "  Wired: checkpoints + manifest -> Postgres, vectors -> Chroma,"
  echo "         generated PDFs -> MinIO (s3://archivist/...)."
  echo "  The agent now needs no shared filesystem at all."
  echo
  echo "  archivist.sky.yaml picks this up via envFrom (optional: true)."
  echo "  Confirm on the next run — the banner should read:"
  echo "      checkpoints : postgres  ${PGH}:5432/archivist"
  echo "  Revert any time with:  $(basename "$0") --unwire"
else
  warn "not wired — the agent still uses sqlite on the hostPath"
  echo "  Re-run with --wire when you want it to use the state plane."
fi

hdr "Gate complete"
