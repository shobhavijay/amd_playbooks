#!/usr/bin/env bash
# Merge the agent's pod_config into ~/.sky/config.yaml, idempotently.
#
# This is NOT optional and it is easy to forget — it was missed on two separate
# boxes. Without it the job cycles STARTING -> PENDING forever with no pod, and
# the only trace is ErrImagePull buried in the controller's provision.log.
#
# It merges rather than overwrites: allowed_contexts and the jobs.controller pin
# already in ~/.sky/config.yaml are preserved.
#
#   ./k8s/apply-sky-config.sh            merge and show the result
#   ./k8s/apply-sky-config.sh --check    verify only, non-zero if missing
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/sky-config-pod_config.yaml"
DST="$HOME/.sky/config.yaml"
MODE="${1:-apply}"

# PyYAML usually lives in sky-venv rather than the system python. Try each
# candidate by simply running it; ones that do not exist fail silently.
PY=""
for c in python3 "$HOME/sky-venv/bin/python" python; do
  "$c" -c "import yaml" >/dev/null 2>&1 && { PY="$c"; break; }
done
[ -n "$PY" ] || { echo "No python with PyYAML found. Try: source ~/sky-venv/bin/activate" >&2; exit 1; }

"$PY" - "$SRC" "$DST" "$MODE" <<'PYEOF'
import sys, pathlib
try:
    import yaml
except ImportError:
    sys.exit("PyYAML missing:  pip install pyyaml")

src, dst, mode = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
block = yaml.safe_load(src.read_text())["kubernetes"]["pod_config"]
cfg = (yaml.safe_load(dst.read_text()) if dst.exists() else {}) or {}
have = (cfg.get("kubernetes") or {}).get("pod_config")

def container(pc):
    return ((pc or {}).get("spec", {}).get("containers") or [{}])[0]

ok = bool(have) and container(have).get("imagePullPolicy") == "IfNotPresent"

if mode == "--check":
    print("OK: pod_config present with imagePullPolicy: IfNotPresent" if ok
          else "MISSING: run ./k8s/apply-sky-config.sh")
    sys.exit(0 if ok else 1)

if ok:
    print("already applied — nothing to do")
    sys.exit(0)

cfg.setdefault("kubernetes", {})["pod_config"] = block
dst.parent.mkdir(parents=True, exist_ok=True)
if dst.exists():
    bak = dst.with_suffix(".yaml.bak")
    bak.write_text(dst.read_text())
    print(f"backed up -> {bak}")
dst.write_text(yaml.dump(cfg, sort_keys=False))
print(f"merged pod_config into {dst}")
print("  kubernetes keys now:", ", ".join(sorted(cfg["kubernetes"])))
print()
print("⚠ The jobs controller caches this. If one already exists, recreate it:")
print("    sky jobs cancel -a -y; sky down -a -y")
PYEOF
