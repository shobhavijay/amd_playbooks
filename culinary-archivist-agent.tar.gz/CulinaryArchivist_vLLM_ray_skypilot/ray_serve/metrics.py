"""
Ray Serve custom metrics — Prometheus-compatible.

Defined here at module level so all deployments share the same metric objects.
Exported automatically on the Ray metrics port (RAY_METRICS_PORT, default 9090).

Metrics:
  culinary_archivist_requests_total       — request count per endpoint + status
  culinary_archivist_request_duration_sec — latency histogram per endpoint
  culinary_archivist_errors_total         — error count per endpoint
"""
from ray.util.metrics import Counter, Histogram

# ── Request counter ───────────────────────────────────────────────────────────
# Tags: endpoint = "chat" | "vision" | "embed"
#       status   = "success" | "error"
requests_total = Counter(
    name="culinary_archivist_requests_total",
    description="Total LLM gateway requests",
    tag_keys=("endpoint", "status"),
)

# ── Latency histogram ─────────────────────────────────────────────────────────
# Buckets cover fast cache hits (0.5s) through slow vision calls (120s)
request_duration_sec = Histogram(
    name="culinary_archivist_request_duration_sec",
    description="LLM gateway request duration in seconds",
    boundaries=[0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0, 120.0],
    tag_keys=("endpoint",),
)

# ── Error counter ─────────────────────────────────────────────────────────────
errors_total = Counter(
    name="culinary_archivist_errors_total",
    description="Total LLM gateway errors",
    tag_keys=("endpoint",),
)
