"""
Ray Serve deployments — one per vLLM model endpoint.

Each deployment is a thin, stateful actor that holds an OpenAI client pointed
at the corresponding vLLM server.  Ray Serve manages lifecycle, health, and
(when needed) replica scaling.

TextModelDeployment  → VLLM_TEXT_BASE_URL   (port 8000)
VisionModelDeployment→ VLLM_VISION_BASE_URL (port 8001)
EmbedModelDeployment → VLLM_EMBED_BASE_URL  (port 8002)
"""
import logging

from openai import OpenAI
from ray import serve

log = logging.getLogger(__name__)


# ── Text ──────────────────────────────────────────────────────────────────────

@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 0.5},
)
class TextModelDeployment:
    """Proxies chat-completion requests to the vLLM text endpoint."""

    def __init__(self):
        from culinary_archivist import config
        self._client = OpenAI(
            base_url=config.VLLM_TEXT_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
        self._model = config.VLLM_TEXT_MODEL
        log.info("TextModelDeployment ready — %s @ %s", self._model, config.VLLM_TEXT_BASE_URL)

    def chat(
        self,
        messages:    list[dict],
        max_tokens:  int   = 2048,
        temperature: float = 0.0,
    ) -> str:
        log.debug("TextModel.chat: max_tokens=%d", max_tokens)
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return resp.choices[0].message.content


# ── Vision ────────────────────────────────────────────────────────────────────

@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 0.5},
)
class VisionModelDeployment:
    """Proxies multimodal chat-completion requests to the vLLM vision endpoint."""

    def __init__(self):
        from culinary_archivist import config
        self._client = OpenAI(
            base_url=config.VLLM_VISION_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
        self._model = config.VLLM_VISION_MODEL
        log.info("VisionModelDeployment ready — %s @ %s", self._model, config.VLLM_VISION_BASE_URL)

    def vision_chat(
        self,
        prompt:      str,
        image_b64:   str,
        max_tokens:  int   = 1024,
        temperature: float = 0.0,
    ) -> str:
        log.debug("VisionModel.vision_chat: max_tokens=%d", max_tokens)
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
                    },
                    {
                        "type": "text",
                        "text": prompt,
                    },
                ],
            }],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return resp.choices[0].message.content


# ── GOT-OCR 2.0 ──────────────────────────────────────────────────────────────

@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 0.5},
)
class OCRModelDeployment:
    """
    Proxies OCR requests to GOT-OCR 2.0 on port 8003.
    Purpose-built for handwritten and printed document text extraction.
    """

    def __init__(self):
        from culinary_archivist import config
        self._client = OpenAI(
            base_url=config.VLLM_OCR_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
        self._model = config.VLLM_OCR_MODEL
        log.info("OCRModelDeployment ready — %s @ %s", self._model, config.VLLM_OCR_BASE_URL)

    def ocr_image(self, image_b64: str) -> str:
        log.debug("OCRModel.ocr_image")
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
                    },
                    {"type": "text", "text": "OCR:"},
                ],
            }],
            max_tokens=2048,
            temperature=0,
        )
        return resp.choices[0].message.content


# ── Embed ─────────────────────────────────────────────────────────────────────

@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 0.5},
)
class EmbedModelDeployment:
    """Proxies embedding requests to the vLLM embed endpoint."""

    def __init__(self):
        from culinary_archivist import config
        self._client = OpenAI(
            base_url=config.VLLM_EMBED_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
        self._model = config.VLLM_EMBED_MODEL
        log.info("EmbedModelDeployment ready — %s @ %s", self._model, config.VLLM_EMBED_BASE_URL)

    def embed(self, texts: list[str]) -> list[list[float]]:
        log.debug("EmbedModel.embed: n=%d", len(texts))
        resp = self._client.embeddings.create(
            model=self._model,
            input=texts,
        )
        return [item.embedding for item in resp.data]
