"""
Ray Serve HTTP gateway — single ingress that routes to the three model deployments.

Endpoints:
  GET  /health   → liveness check
  POST /chat     → text model (chat completions)
  POST /vision   → vision model (multimodal chat)
  POST /embed    → embed model (text embeddings)

All endpoints accept and return JSON.  The LangGraph pipeline talks to this
gateway via ray_serve_client.py; the three model deployments are internal.

Metrics (Prometheus — scraped from Ray metrics port 9090):
  culinary_archivist_requests_total        — count per endpoint + status
  culinary_archivist_request_duration_sec  — latency histogram per endpoint
  culinary_archivist_errors_total          — error count per endpoint
"""
import logging
import time

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from ray import serve
from ray.serve.handle import DeploymentHandle

from ray_serve.metrics import errors_total, request_duration_sec, requests_total

log = logging.getLogger(__name__)

# FastAPI app — defined at module level so @serve.ingress can wrap it
_app = FastAPI(
    title="Culinary Archivist LLM Gateway",
    description="Ray Serve proxy for vLLM text / vision / embed endpoints",
)


# ── Request / response models ─────────────────────────────────────────────────

class ChatRequest(BaseModel):
    messages:    list[dict]
    max_tokens:  int   = 2048
    temperature: float = 0.0

class VisionRequest(BaseModel):
    prompt:      str
    image_b64:   str
    max_tokens:  int   = 1024
    temperature: float = 0.0

class EmbedRequest(BaseModel):
    texts: list[str]

class OcrRequest(BaseModel):
    image_b64: str


# ── Gateway deployment ────────────────────────────────────────────────────────

@serve.deployment(num_replicas=1)
@serve.ingress(_app)
class LLMGateway:
    """
    HTTP ingress deployment.  Receives requests and dispatches them to the
    appropriate model deployment via Ray Serve handles (async remote calls).
    """

    def __init__(
        self,
        text:   DeploymentHandle,
        vision: DeploymentHandle,
        embed:  DeploymentHandle,
        ocr:    DeploymentHandle,
    ):
        self._text   = text
        self._vision = vision
        self._embed  = embed
        self._ocr    = ocr
        log.info("LLMGateway ready — routes: /chat  /vision  /embed  /ocr  /health")

    @_app.get("/health")
    async def health(self):
        return {"status": "ok", "deployments": ["text", "vision", "embed"]}

    @_app.post("/chat")
    async def chat(self, req: ChatRequest):
        log.debug("Gateway /chat: max_tokens=%d", req.max_tokens)
        t0 = time.time()
        try:
            content = await self._text.chat.remote(
                req.messages, req.max_tokens, req.temperature
            )
            requests_total.inc(tags={"endpoint": "chat", "status": "success"})
            return {"content": content}
        except Exception as e:
            errors_total.inc(tags={"endpoint": "chat"})
            requests_total.inc(tags={"endpoint": "chat", "status": "error"})
            log.error("Gateway /chat error: %s", e)
            raise HTTPException(status_code=502, detail=str(e))
        finally:
            request_duration_sec.observe(time.time() - t0, tags={"endpoint": "chat"})

    @_app.post("/vision")
    async def vision(self, req: VisionRequest):
        log.debug("Gateway /vision: max_tokens=%d", req.max_tokens)
        t0 = time.time()
        try:
            content = await self._vision.vision_chat.remote(
                req.prompt, req.image_b64, req.max_tokens, req.temperature
            )
            requests_total.inc(tags={"endpoint": "vision", "status": "success"})
            return {"content": content}
        except Exception as e:
            errors_total.inc(tags={"endpoint": "vision"})
            requests_total.inc(tags={"endpoint": "vision", "status": "error"})
            log.error("Gateway /vision error: %s", e)
            raise HTTPException(status_code=502, detail=str(e))
        finally:
            request_duration_sec.observe(time.time() - t0, tags={"endpoint": "vision"})

    @_app.post("/embed")
    async def embed_endpoint(self, req: EmbedRequest):
        log.debug("Gateway /embed: n=%d", len(req.texts))
        t0 = time.time()
        try:
            embeddings = await self._embed.embed.remote(req.texts)
            requests_total.inc(tags={"endpoint": "embed", "status": "success"})
            return {"embeddings": embeddings}
        except Exception as e:
            errors_total.inc(tags={"endpoint": "embed"})
            requests_total.inc(tags={"endpoint": "embed", "status": "error"})
            log.error("Gateway /embed error: %s", e)
            raise HTTPException(status_code=502, detail=str(e))
        finally:
            request_duration_sec.observe(time.time() - t0, tags={"endpoint": "embed"})

    @_app.post("/ocr")
    async def ocr(self, req: OcrRequest):
        log.debug("Gateway /ocr: image_len=%d", len(req.image_b64))
        t0 = time.time()
        try:
            text = await self._ocr.ocr_image.remote(req.image_b64)
            requests_total.inc(tags={"endpoint": "ocr", "status": "success"})
            return {"text": text}
        except Exception as e:
            errors_total.inc(tags={"endpoint": "ocr"})
            requests_total.inc(tags={"endpoint": "ocr", "status": "error"})
            log.error("Gateway /ocr error: %s", e)
            raise HTTPException(status_code=502, detail=str(e))
        finally:
            request_duration_sec.observe(time.time() - t0, tags={"endpoint": "ocr"})
