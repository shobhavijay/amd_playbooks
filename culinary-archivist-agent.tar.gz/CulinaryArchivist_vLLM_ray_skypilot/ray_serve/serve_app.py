"""
Entry point — start Ray, deploy the LLM gateway, and run until interrupted.

Usage:
    # From the project root (venv activated):
    python -m ray_serve.serve_app

    # Or directly:
    python ray_serve/serve_app.py

The gateway will be available at http://localhost:8080 (RAY_SERVE_PORT).
Set LLM_BACKEND=ray_serve in .env to route the pipeline through it.

Prerequisites:
    - vLLM text  model running on port 8000  (VLLM_TEXT_BASE_URL)
    - vLLM vision model running on port 8001  (VLLM_VISION_BASE_URL)
    - vLLM embed  model running on port 8002  (VLLM_EMBED_BASE_URL)
"""
import logging
import time

import ray
from ray import serve

from culinary_archivist import config, identity
from ray_serve.deployments import EmbedModelDeployment, OCRModelDeployment, TextModelDeployment, VisionModelDeployment
from ray_serve.gateway import LLMGateway

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s — %(message)s")
log = logging.getLogger(__name__)

# Ports are env-driven: the agent pod publishes these as a k8s Service, and
# hardcoding them collides when two tenants share a node.
RAY_SERVE_PORT     = config.RAY_SERVE_PORT
RAY_SERVE_HOST     = config.RAY_SERVE_HOST
RAY_DASHBOARD_PORT = config.RAY_DASHBOARD_PORT
RAY_METRICS_PORT   = config.RAY_METRICS_PORT


def start() -> None:
    identity.print_banner(role="agent (Ray Serve gateway)")

    log.info("Initialising Ray...")
    # Ray stays LOCAL to this pod. Do not try to span a Ray cluster across the
    # two vclusters — the pod is the failover unit, and a cross-tenant head node
    # would just become a second thing to recover.
    ray.init(
        ignore_reinit_error=True,
        dashboard_host="0.0.0.0",       # allow SSH-tunnelled dashboard access
        dashboard_port=RAY_DASHBOARD_PORT,
        _metrics_export_port=RAY_METRICS_PORT,
    )

    log.info("Deploying LLM Gateway on port %d...", RAY_SERVE_PORT)

    serve.start(http_options={"host": RAY_SERVE_HOST, "port": RAY_SERVE_PORT})

    # Bind each model deployment, then compose them into the gateway
    text    = TextModelDeployment.bind()
    vision  = VisionModelDeployment.bind()
    embed   = EmbedModelDeployment.bind()
    ocr     = OCRModelDeployment.bind()
    gateway = LLMGateway.bind(text, vision, embed, ocr)

    serve.run(gateway, name="llm_gateway", route_prefix="/")

    log.info("=" * 60)
    log.info("LLM Gateway   : http://localhost:%d", RAY_SERVE_PORT)
    log.info("  GET  /health  — liveness check")
    log.info("  POST /chat    — text model  (Qwen2.5-32B)")
    log.info("  POST /vision  — vision model (Qwen2.5-VL-7B)")
    log.info("  POST /embed   — embed model  (bge-m3)")
    log.info("  POST /ocr     — OCR model    (GOT-OCR2_0) — best for handwriting")
    log.info("Ray Dashboard : http://localhost:%d", RAY_DASHBOARD_PORT)
    log.info("Prometheus    : http://localhost:%d  (metrics scrape target)", RAY_METRICS_PORT)
    log.info("Tenant        : %s", config.TENANT_NAME)
    log.info("")
    log.info("── SSH tunnel from your laptop ──────────────────────────")
    log.info("  ssh -L 8265:localhost:8265 -L 9090:localhost:9090 user@<gpu-ip>")
    log.info("  Then open http://localhost:8265 in your browser.")
    log.info("")
    log.info("Set LLM_BACKEND=ray_serve in .env to route the pipeline here.")
    log.info("Press Ctrl+C to stop.")
    log.info("=" * 60)

    try:
        while True:
            time.sleep(5)
    except KeyboardInterrupt:
        log.info("Shutting down...")
        serve.shutdown()
        ray.shutdown()
        log.info("Ray Serve stopped.")


if __name__ == "__main__":
    start()
