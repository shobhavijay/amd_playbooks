"""
Shared utilities for Google Places and Foursquare clients.

Extracted here so neither client imports internals from the other.
"""
from __future__ import annotations

import math
from typing import TypedDict


# ── Shared result type ────────────────────────────────────────────────────────

class PlaceResult(TypedDict):
    name:         str
    address:      str
    rating:       float        # 0–5 scale (both sources normalised to this)
    review_count: int
    distance_mi:  float
    website:      str
    open_now:     bool | None  # None if hours not available
    price_level:  str          # "" | "$" | "$$" | "$$$" | "$$$$"
    source:       str          # "google" | "foursquare"
    lat:          float
    lng:          float


# ── Distance ──────────────────────────────────────────────────────────────────

def haversine_mi(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Great-circle distance in miles between two lat/lng points."""
    R = 3958.8  # Earth radius in miles
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.asin(math.sqrt(a))


# ── Deduplication ─────────────────────────────────────────────────────────────

def deduplicate(results: list[PlaceResult]) -> list[PlaceResult]:
    """Remove duplicate venues by normalised store name."""
    seen: set[str] = set()
    out: list[PlaceResult] = []
    for r in results:
        key = r["name"].lower().strip()
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out


# ── Region → store search terms ───────────────────────────────────────────────
# generic  = mainstream ethnic grocery stores appropriate for this cuisine region
# specialty = niche/specialist stores for hard-to-find ingredients

REGION_STORE_TERMS: dict[str, dict[str, list[str]]] = {
    "SOUTH_INDIAN": {
        "generic":   ["Indian grocery store", "South Indian grocery", "Asian supermarket"],
        "specialty": ["South Indian specialty store", "Tamil grocery store", "spice shop Indian"],
    },
    "NORTH_INDIAN": {
        "generic":   ["Indian grocery store", "Pakistani grocery store", "desi grocery"],
        "specialty": ["North Indian spice shop", "Mughlai grocery", "halal Indian market"],
    },
    "PUNJABI": {
        "generic":   ["Indian grocery store", "Punjabi grocery"],
        "specialty": ["Punjabi specialty store", "amritsari food shop"],
    },
    "BENGALI": {
        "generic":   ["Indian grocery store", "Bengali grocery"],
        "specialty": ["Bengali specialty store", "Kolkata food shop"],
    },
    "GUJARATI": {
        "generic":   ["Indian grocery store", "Gujarati grocery"],
        "specialty": ["Gujarati specialty store", "Jain food shop"],
    },
    "MAHARASHTRIAN": {
        "generic":   ["Indian grocery store", "Maharashtra grocery"],
        "specialty": ["Maharashtrian specialty store", "konkan food shop"],
    },
    "KERALA": {
        "generic":   ["Indian grocery store", "Kerala grocery", "Malayali store"],
        "specialty": ["Kerala specialty store", "Malabar spice shop"],
    },
    "RAJASTHANI": {
        "generic":   ["Indian grocery store", "Rajasthani grocery"],
        "specialty": ["Rajasthani specialty store", "marwari food shop"],
    },
    "MEXICAN": {
        "generic":   ["Mexican grocery store", "Latin supermercado", "tienda mexicana"],
        "specialty": ["Oaxacan food store", "Mexican specialty market", "molino tortilleria"],
    },
    "THAI": {
        "generic":   ["Asian grocery store", "Thai grocery", "Southeast Asian supermarket"],
        "specialty": ["Thai specialty store", "Southeast Asian market"],
    },
    "CHINESE": {
        "generic":   ["Chinese grocery store", "Asian supermarket", "H Mart"],
        "specialty": ["Hong Kong market", "Sichuan specialty store", "dim sum grocery"],
    },
    "JAPANESE": {
        "generic":   ["Japanese grocery store", "Asian supermarket", "Mitsuwa"],
        "specialty": ["Japanese specialty store", "miso sake shop", "Japanese market"],
    },
    "KOREAN": {
        "generic":   ["Korean grocery store", "H Mart", "Asian supermarket"],
        "specialty": ["Korean specialty store", "kimchi shop", "Korean market"],
    },
    "VIETNAMESE": {
        "generic":   ["Vietnamese grocery store", "Asian supermarket", "pho supply store"],
        "specialty": ["Vietnamese specialty store", "Southeast Asian market"],
    },
    "MEDITERRANEAN": {
        "generic":   ["Middle Eastern grocery", "Mediterranean market", "Greek deli"],
        "specialty": ["Mediterranean specialty store", "Lebanese grocery", "halal butcher"],
    },
    "TURKISH": {
        "generic":   ["Turkish grocery store", "Middle Eastern grocery"],
        "specialty": ["Turkish specialty store", "Turkish deli"],
    },
    "LEBANESE": {
        "generic":   ["Lebanese grocery store", "Middle Eastern market"],
        "specialty": ["Lebanese specialty store", "Arabic grocery"],
    },
    "MOROCCAN": {
        "generic":   ["Moroccan grocery store", "North African market", "Middle Eastern grocery"],
        "specialty": ["Moroccan specialty store", "ras el hanout spice shop"],
    },
    "PERSIAN": {
        "generic":   ["Persian grocery store", "Iranian market", "Middle Eastern grocery"],
        "specialty": ["Persian specialty store", "Iranian food shop"],
    },
    "FRENCH": {
        "generic":   ["European deli", "French grocery", "gourmet grocery store"],
        "specialty": ["French specialty food store", "fromagerie", "French patisserie supplies"],
    },
    "ITALIAN": {
        "generic":   ["Italian grocery store", "European deli", "gourmet grocery"],
        "specialty": ["Italian specialty store", "salumeria", "Italian deli"],
    },
    "SPANISH": {
        "generic":   ["Spanish grocery store", "European deli", "Latin market"],
        "specialty": ["Spanish specialty store", "jamon iberico shop", "Spanish deli"],
    },
    "GREEK": {
        "generic":   ["Greek grocery store", "Mediterranean market"],
        "specialty": ["Greek specialty store", "Greek deli"],
    },
    "ETHIOPIAN": {
        "generic":   ["Ethiopian grocery store", "African market"],
        "specialty": ["Ethiopian specialty store", "injera teff shop"],
    },
    "WEST_AFRICAN": {
        "generic":   ["African grocery store", "West African market"],
        "specialty": ["West African specialty store", "Nigerian grocery"],
    },
    "CARIBBEAN": {
        "generic":   ["Caribbean grocery store", "West Indian market"],
        "specialty": ["Caribbean specialty store", "Jamaican food shop"],
    },
    "CAJUN": {
        "generic":   ["Cajun grocery store", "Southern food store", "Louisiana market"],
        "specialty": ["Cajun specialty store", "andouille boudin shop"],
    },
    "AMERICAN": {
        "generic":   ["grocery store", "supermarket", "Whole Foods"],
        "specialty": ["specialty food store", "gourmet grocery", "artisan food shop"],
    },
    "UNKNOWN": {
        "generic":   ["international grocery store", "ethnic market", "world foods grocery"],
        "specialty": ["specialty food store", "gourmet grocery", "international market"],
    },
}
