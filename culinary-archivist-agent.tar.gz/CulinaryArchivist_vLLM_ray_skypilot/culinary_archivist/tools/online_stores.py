"""
Online store matcher — pairs recipe ingredients with the best online retailers.

Two tiers, mirroring the local store logic:

  Tier 1 (generic)   — widely available ingredients for a cuisine region.
                        Returns 2 mainstream/region-matched stores that carry
                        most of these in one order.

  Tier 2 (specialty) — hard-to-find ingredients.
                        Returns 2 niche specialty retailers per ingredient,
                        chosen from the region-matched + universal pools.

All matching is done in a single LLM call per tier so API usage is bounded:
  - 1 call for all generic ingredients → 2 stores
  - 1 call for all specialty ingredients → up to 2 stores × N ingredients

The LLM receives the full curated store registry and reasons about which
stores most plausibly stock each ingredient based on their stated specialty.
No web scraping, no live inventory checks — this is reasoning-based matching.

Output schema returned by match_generic() and match_specialty():

  match_generic(generic_ingredients, region) →
    [
      {"name": "patelbros.com", "url": "https://www.patelbros.com",
       "reason": "Full South Indian pantry, ships nationwide"},
      ...
    ]

  match_specialty(specialty_ingredients, region) →
    {
      "kasuri methi": [
        {"name": "kalustyans.com", "url": "https://www.kalustyans.com",
         "reason": "Largest South Asian dry goods selection in the US"},
        ...
      ],
      ...
    }
"""
from __future__ import annotations

import json
import logging
import re

from culinary_archivist import llm_client

log = logging.getLogger(__name__)


# ── Online store registry ─────────────────────────────────────────────────────
# Each entry: name, url, ships_to, specialty description, region_affinity list.
# region_affinity links stores to cuisine regions — the LLM uses this as a
# strong prior but can override it for universal stores.

ONLINE_STORES: list[dict] = [
    # ── South Asian ───────────────────────────────────────────────────────────
    {
        "name":            "Kalustyan's",
        "url":             "https://www.kalustyans.com",
        "ships_to":        "US",
        "specialty":       "Largest specialty food retailer in the US for South Asian, "
                           "Middle Eastern, and global pantry staples. Extensive spice "
                           "selection including rare Indian, Persian, and North African ingredients.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "PUNJABI", "BENGALI",
                            "GUJARATI", "MAHARASHTRIAN", "KERALA", "RAJASTHANI",
                            "PERSIAN", "LEBANESE", "MOROCCAN", "MEDITERRANEAN", "TURKISH"],
    },
    {
        "name":            "Patel Brothers",
        "url":             "https://www.patelbros.com",
        "ships_to":        "US",
        "specialty":       "Leading South Asian grocery chain with online ordering. "
                           "Comprehensive selection of Indian, Pakistani, and Bangladeshi "
                           "pantry items — dals, flours, spices, pickles, frozen items.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "PUNJABI", "BENGALI",
                            "GUJARATI", "MAHARASHTRIAN", "KERALA", "RAJASTHANI"],
    },
    {
        "name":            "Diaspora Co.",
        "url":             "https://www.diasporacospice.com",
        "ships_to":        "US, CA, UK",
        "specialty":       "Single-origin Indian spices sourced directly from small farms. "
                           "Exceptional turmeric, black pepper, cardamom, chilli, coriander. "
                           "Best for high-quality individual spices, not pantry staples.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "KERALA", "PUNJABI"],
    },
    {
        "name":            "iShopIndian",
        "url":             "https://www.ishopindian.com",
        "ships_to":        "US",
        "specialty":       "Online Indian grocery with broad selection of regional Indian "
                           "products — Brahmin's, MTR, Eastern, Aachi, and other regional brands. "
                           "Good for brand-specific South and North Indian products.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "KERALA", "BENGALI"],
    },

    # ── Spice specialists (cross-regional) ────────────────────────────────────
    {
        "name":            "The Spice House",
        "url":             "https://www.thespicehouse.com",
        "ships_to":        "US, CA",
        "specialty":       "Premium global spice retailer. Strong selection of single spices, "
                           "spice blends, and hard-to-find varieties from South Asia, Middle East, "
                           "Africa, and Latin America.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "MEXICAN", "MOROCCAN",
                            "ETHIOPIAN", "CARIBBEAN", "MEDITERRANEAN"],
    },
    {
        "name":            "Spice Jungle",
        "url":             "https://www.spicejungle.com",
        "ships_to":        "US",
        "specialty":       "Bulk exotic and specialty spices. Wide range of South Asian, "
                           "African, and Middle Eastern spices including asafoetida, kalonji, "
                           "fenugreek, amchur, dried rose petals, and mace blades.",
        "region_affinity": ["SOUTH_INDIAN", "NORTH_INDIAN", "MOROCCAN", "PERSIAN",
                            "LEBANESE", "ETHIOPIAN"],
    },
    {
        "name":            "Burlap & Barrel",
        "url":             "https://www.burlapandbarrel.com",
        "ships_to":        "US, CA, UK, EU",
        "specialty":       "Small-batch single-origin spices sourced directly from farmers "
                           "worldwide. Excellent for rare varieties: royal cinnamon, saffron, "
                           "smoked paprika, urfa biber, sumac, black lime.",
        "region_affinity": ["MEDITERRANEAN", "TURKISH", "PERSIAN", "MOROCCAN",
                            "SOUTH_INDIAN", "NORTH_INDIAN"],
    },

    # ── Latin / Mexican ───────────────────────────────────────────────────────
    {
        "name":            "My Mexican Pantry",
        "url":             "https://www.mymexicanpantry.com",
        "ships_to":        "US",
        "specialty":       "Authentic Mexican pantry staples including dried chillies "
                           "(ancho, guajillo, pasilla, mulato), masa harina, epazote, "
                           "piloncillo, Mexican oregano, and specialty chocolate.",
        "region_affinity": ["MEXICAN", "CAJUN", "CARIBBEAN"],
    },
    {
        "name":            "MexGrocer",
        "url":             "https://www.mexgrocer.com",
        "ships_to":        "US, CA",
        "specialty":       "Broad Mexican and Latin American grocery selection. "
                           "Canned goods, salsas, moles, spice blends, and specialty "
                           "flours including huitlacoche and nopal products.",
        "region_affinity": ["MEXICAN", "CARIBBEAN"],
    },

    # ── East / Southeast Asian ────────────────────────────────────────────────
    {
        "name":            "ImportFood",
        "url":             "https://www.importfood.com",
        "ships_to":        "US, CA, AU, UK",
        "specialty":       "Thai grocery specialist. Kaffir lime leaves, galangal, "
                           "Thai basil, shrimp paste, fish sauce, coconut products, "
                           "and specialty Thai noodles and curry pastes.",
        "region_affinity": ["THAI", "VIETNAMESE", "CAMBODIAN"],
    },
    {
        "name":            "Umami Insider",
        "url":             "https://www.umamiinsider.com",
        "ships_to":        "US",
        "specialty":       "Japanese pantry specialist. Dashi, mirin, sake, soy sauces, "
                           "miso varieties, bonito flakes, konbu, Japanese rice, and "
                           "specialty condiments.",
        "region_affinity": ["JAPANESE", "KOREAN"],
    },
    {
        "name":            "Weee! Asian Grocery",
        "url":             "https://www.sayweee.com",
        "ships_to":        "US (select cities)",
        "specialty":       "Asian grocery delivery covering Chinese, Japanese, Korean, "
                           "Vietnamese, Filipino, and South Asian products. Strong for "
                           "fresh produce and refrigerated items.",
        "region_affinity": ["CHINESE", "JAPANESE", "KOREAN", "VIETNAMESE", "THAI",
                            "SOUTH_INDIAN"],
    },

    # ── Mediterranean / Middle Eastern / African ──────────────────────────────
    {
        "name":            "Adriana's Caravan",
        "url":             "https://www.adrianascaravan.com",
        "ships_to":        "US",
        "specialty":       "Mediterranean and Middle Eastern specialty foods. "
                           "Sumac, za'atar, harissa, preserved lemons, pomegranate molasses, "
                           "freekeh, mastic, dried rose buds, and specialty grains.",
        "region_affinity": ["MEDITERRANEAN", "LEBANESE", "TURKISH", "MOROCCAN",
                            "PERSIAN", "GREEK"],
    },
    {
        "name":            "Woyome African Foods",
        "url":             "https://www.woyome.com",
        "ships_to":        "US",
        "specialty":       "West and East African grocery specialist. Egusi, ogiri, "
                           "crayfish, fufu flour, injera teff, berbere spice blend, "
                           "and specialty African grains and dried fish.",
        "region_affinity": ["WEST_AFRICAN", "ETHIOPIAN"],
    },

    # ── European ─────────────────────────────────────────────────────────────
    {
        "name":            "iGourmet",
        "url":             "https://www.igourmet.com",
        "ships_to":        "US",
        "specialty":       "Artisan European and gourmet foods. Specialty cheeses, "
                           "cured meats, truffle products, European pantry staples, "
                           "and imported French, Italian, and Spanish specialty items.",
        "region_affinity": ["FRENCH", "ITALIAN", "SPANISH", "GREEK", "MEDITERRANEAN"],
    },
    {
        "name":            "Zingerman's",
        "url":             "https://www.zingermans.com",
        "ships_to":        "US",
        "specialty":       "Artisan specialty foods with a strong European focus. "
                           "Estate olive oils, aged balsamic, specialty breads, "
                           "hand-crafted cheeses, and hard-to-find condiments.",
        "region_affinity": ["ITALIAN", "FRENCH", "MEDITERRANEAN"],
    },

    # ── Universal (broad coverage) ────────────────────────────────────────────
    {
        "name":            "Amazon",
        "url":             "https://www.amazon.com",
        "ships_to":        "Worldwide",
        "specialty":       "Broadest availability. Most specialty food items available "
                           "via Amazon Pantry, Whole Foods, or third-party sellers. "
                           "Best for items unavailable at dedicated specialty stores, "
                           "or when fast Prime delivery is needed.",
        "region_affinity": [],   # universal — applies to all regions
    },
    {
        "name":            "Nuts.com",
        "url":             "https://www.nuts.com",
        "ships_to":        "US, CA",
        "specialty":       "Specialty in dried fruits, nuts, seeds, grains, and flours. "
                           "Good for dried coconut, sesame seeds, poppy seeds, specialty "
                           "flours, dried legumes, and bulk pantry items.",
        "region_affinity": [],   # universal
    },
    {
        "name":            "World Market",
        "url":             "https://www.worldmarket.com",
        "ships_to":        "US",
        "specialty":       "International pantry with products from 50+ countries. "
                           "Good for mainstream imported condiments, noodles, sauces, "
                           "and grocery staples that sit between generic and specialty.",
        "region_affinity": [],   # universal
    },
]


# ── LLM prompts ───────────────────────────────────────────────────────────────

def _build_store_list_text(region: str) -> str:
    """
    Build a compact store directory for the LLM prompt.
    Region-affinity stores are listed first, universal stores last.
    """
    region_key = region.upper()

    affinity_stores  = [s for s in ONLINE_STORES if region_key in s["region_affinity"]]
    universal_stores = [s for s in ONLINE_STORES if not s["region_affinity"]]
    # Include a sample of non-affinity stores so the LLM isn't blind to alternatives
    other_stores     = [s for s in ONLINE_STORES
                        if s["region_affinity"] and region_key not in s["region_affinity"]][:4]

    ordered = affinity_stores + universal_stores + other_stores

    lines = []
    for s in ordered:
        affinity_note = " [region match]" if region_key in s["region_affinity"] else ""
        lines.append(
            f"- {s['name']} ({s['url']}) — ships to: {s['ships_to']}{affinity_note}\n"
            f"  {s['specialty']}"
        )
    return "\n".join(lines)


_GENERIC_PROMPT_TEMPLATE = """\
You are a culinary sourcing assistant.

RECIPE REGION: {region}

GENERIC INGREDIENTS (standard for this cuisine — need regular grocery-level availability):
{ingredients}

AVAILABLE ONLINE STORES:
{store_list}

Task: Pick the 2 best online stores from the list above to order MOST of these generic \
ingredients in a single order. Prefer stores marked [region match] — they are likely to \
stock regional brands and formats (e.g. correct flour grind, regional pickle brands).

Return ONLY a JSON array with exactly 2 objects. No explanation, no markdown.
Each object must have exactly these keys:
  "name"   : store name (must match exactly from the list above)
  "url"    : store URL (must match exactly from the list above)
  "reason" : one sentence explaining why this store suits these specific ingredients

Example output:
[
  {{"name": "Patel Brothers", "url": "https://www.patelbros.com", "reason": "..."}},
  {{"name": "Amazon", "url": "https://www.amazon.com", "reason": "..."}}
]
"""

_SPECIALTY_PROMPT_TEMPLATE = """\
You are a culinary sourcing assistant.

RECIPE REGION: {region}

SPECIALTY INGREDIENTS (hard to find — require specialty retailers):
{ingredients}

AVAILABLE ONLINE STORES:
{store_list}

Task: For EACH specialty ingredient, pick the 2 best online stores from the list above \
that most plausibly stock it. Prefer stores marked [region match]. Use "Amazon" only as \
a last resort when no specialty store is a good fit.

Return ONLY a JSON object. No explanation, no markdown. Keys are ingredient names \
(exactly as given), values are arrays of exactly 2 store objects.
Each store object has exactly these keys:
  "name"   : store name (must match exactly from the list above)
  "url"    : store URL (must match exactly from the list above)
  "reason" : one sentence explaining why this store stocks this specific ingredient

Example output:
{{
  "kasuri methi": [
    {{"name": "Kalustyan's", "url": "https://www.kalustyans.com", "reason": "..."}},
    {{"name": "Patel Brothers", "url": "https://www.patelbros.com", "reason": "..."}}
  ],
  "sumac": [
    {{"name": "Adriana's Caravan", "url": "https://www.adrianascaravan.com", "reason": "..."}},
    {{"name": "Kalustyan's", "url": "https://www.kalustyans.com", "reason": "..."}}
  ]
}}
"""


# ── JSON parsing ──────────────────────────────────────────────────────────────

def _parse_json_response(raw: str, expected_type: type) -> list | dict | None:
    """
    Parse LLM JSON response. Handles markdown fences and leading preamble text.
    Returns None on failure so callers can apply a safe fallback.
    """
    text = raw.strip()

    # Strip ```json ... ``` fences
    if "```" in text:
        match = re.search(r"```(?:json)?\s*([\s\S]+?)```", text)
        if match:
            text = match.group(1).strip()

    # Extract the first [...] or {...} block
    if expected_type is list:
        match = re.search(r"\[[\s\S]*\]", text)
    else:
        match = re.search(r"\{[\s\S]*\}", text)

    if match:
        text = match.group(0)

    try:
        result = json.loads(text)
        if isinstance(result, expected_type):
            return result
    except json.JSONDecodeError as exc:
        log.warning("online_stores: JSON parse failed — %s", exc)

    return None


def _fallback_stores(region: str) -> list[dict]:
    """
    Return 2 safe default stores when LLM call fails or returns bad JSON.
    Always includes Amazon as a universal fallback plus a region-matched store if available.
    """
    region_key = region.upper()
    region_match = next(
        (s for s in ONLINE_STORES if region_key in s["region_affinity"]),
        None,
    )
    amazon = next(s for s in ONLINE_STORES if s["name"] == "Amazon")

    results = []
    if region_match and region_match["name"] != "Amazon":
        results.append({
            "name":   region_match["name"],
            "url":    region_match["url"],
            "reason": f"Region-matched store for {region} cuisine (fallback — LLM unavailable)",
        })
    results.append({
        "name":   amazon["name"],
        "url":    amazon["url"],
        "reason": "Broad availability fallback",
    })
    return results[:2]


# ── Public API ────────────────────────────────────────────────────────────────

def match_generic(
    generic_ingredients: list[str],
    region: str,
) -> list[dict]:
    """
    Find the 2 best online stores for a recipe's generic (Tier 1) ingredients.

    Makes one LLM call for all generic ingredients together — the goal is to
    find stores where you can satisfy most items in a single order.

    Args:
        generic_ingredients: e.g. ["rice", "coconut milk", "mustard seeds"]
        region:              Cuisine region label, e.g. "SOUTH_INDIAN"

    Returns:
        List of 2 dicts: [{"name": ..., "url": ..., "reason": ...}, ...]
        Falls back to [region-match, Amazon] if LLM call fails.
    """
    if not generic_ingredients:
        return _fallback_stores(region)

    store_list  = _build_store_list_text(region)
    ingredients = "\n".join(f"- {i}" for i in generic_ingredients)
    prompt      = _GENERIC_PROMPT_TEMPLATE.format(
        region=region,
        ingredients=ingredients,
        store_list=store_list,
    )

    log.info(
        "online_stores.match_generic: region=%r  %d ingredients → LLM call",
        region, len(generic_ingredients),
    )

    try:
        raw    = llm_client.chat(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=512,
            temperature=0,
        )
        result = _parse_json_response(raw, list)
        if result and len(result) >= 1:
            # Ensure we always return exactly 2 — pad with fallback if LLM returned only 1
            while len(result) < 2:
                result.extend(_fallback_stores(region))
            log.info("online_stores.match_generic: matched %d stores", len(result[:2]))
            return result[:2]
    except Exception as exc:
        log.error("online_stores.match_generic: LLM call failed — %s", exc)

    log.warning("online_stores.match_generic: using fallback stores")
    return _fallback_stores(region)


def match_specialty(
    specialty_ingredients: list[str],
    region: str,
) -> dict[str, list[dict]]:
    """
    Find the 2 best online stores for each specialty (Tier 2) ingredient.

    Makes one LLM call covering all specialty ingredients at once.

    Args:
        specialty_ingredients: e.g. ["kasuri methi", "kalonji", "asafoetida"]
        region:                Cuisine region label, e.g. "SOUTH_INDIAN"

    Returns:
        Dict keyed by ingredient name:
        {
          "kasuri methi": [{"name": ..., "url": ..., "reason": ...}, ...],
          "kalonji":      [...],
        }
        Missing ingredients get the fallback [region-match, Amazon] pair.
    """
    if not specialty_ingredients:
        return {}

    store_list  = _build_store_list_text(region)
    ingredients = "\n".join(f"- {i}" for i in specialty_ingredients)
    prompt      = _SPECIALTY_PROMPT_TEMPLATE.format(
        region=region,
        ingredients=ingredients,
        store_list=store_list,
    )

    log.info(
        "online_stores.match_specialty: region=%r  %d ingredients → LLM call",
        region, len(specialty_ingredients),
    )

    result: dict[str, list[dict]] = {}

    try:
        raw    = llm_client.chat(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1024,
            temperature=0,
        )
        parsed = _parse_json_response(raw, dict)
        if parsed:
            for ing in specialty_ingredients:
                stores = parsed.get(ing) or []
                if stores and isinstance(stores, list):
                    # Pad to 2 if LLM returned only 1
                    while len(stores) < 2:
                        stores.extend(_fallback_stores(region))
                    result[ing] = stores[:2]
                else:
                    log.warning("online_stores: no match for ingredient=%r — using fallback", ing)
                    result[ing] = _fallback_stores(region)
            log.info("online_stores.match_specialty: matched %d ingredients", len(result))
            return result
    except Exception as exc:
        log.error("online_stores.match_specialty: LLM call failed — %s", exc)

    # Full fallback — apply same 2 stores to all ingredients
    fallback = _fallback_stores(region)
    return {ing: fallback for ing in specialty_ingredients}


def list_stores_for_region(region: str) -> list[dict]:
    """
    Return the ordered store list for a region (for debugging / display).
    Region-affinity stores first, then universal, then others.
    """
    region_key       = region.upper()
    affinity_stores  = [s for s in ONLINE_STORES if region_key in s["region_affinity"]]
    universal_stores = [s for s in ONLINE_STORES if not s["region_affinity"]]
    return affinity_stores + universal_stores
