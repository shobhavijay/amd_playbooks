"""
Google Places New API client.

Uses the Places API (New) — NOT the legacy Places API.
Endpoint: https://places.googleapis.com/v1/places:searchText

Required Google Cloud setup:
  1. Enable "Places API (New)" in your GCP project
  2. Enable "Geocoding API" (used by geocoder.py for address → lat/lng)
  3. Set GOOGLE_PLACES_API_KEY in .env

Field mask controls billing — we only request what we use:
  displayName, rating, userRatingCount, formattedAddress,
  location, websiteUri, regularOpeningHours, priceLevel

Pricing (as of 2025):
  searchText:  $0.032 / call
  Details are included in the searchText response via field mask —
  no separate details call needed.

Three public functions:
  search(query, lat, lng, radius_m, limit)
  search_generic_stores(region_label, lat, lng, radius_m, limit)
  search_specialty_stores(ingredient, region_label, lat, lng, radius_m, limit)
"""
from __future__ import annotations

import logging
import math

import requests

from culinary_archivist import config
from culinary_archivist.tools._places_utils import (
    PlaceResult,
    REGION_STORE_TERMS,
    deduplicate,
    haversine_mi,
)

log = logging.getLogger(__name__)

_SEARCH_URL = "https://places.googleapis.com/v1/places:searchText"

# Fields we request — keep minimal to control billing tier.
# regularOpeningHours.openNow gives current open/closed status.
_FIELD_MASK = ",".join([
    "places.displayName",
    "places.rating",
    "places.userRatingCount",
    "places.formattedAddress",
    "places.location",
    "places.websiteUri",
    "places.regularOpeningHours",
    "places.priceLevel",
])


# ── Internal helpers ──────────────────────────────────────────────────────────

def _price_label(level: str | None) -> str:
    mapping = {
        "PRICE_LEVEL_INEXPENSIVE":    "$",
        "PRICE_LEVEL_MODERATE":       "$$",
        "PRICE_LEVEL_EXPENSIVE":      "$$$",
        "PRICE_LEVEL_VERY_EXPENSIVE": "$$$$",
    }
    return mapping.get(level or "", "")


def _parse_place(raw: dict, center_lat: float, center_lng: float) -> PlaceResult:
    loc   = raw.get("location", {})
    lat   = loc.get("latitude",  0.0)
    lng   = loc.get("longitude", 0.0)
    hours = raw.get("regularOpeningHours") or {}

    return PlaceResult(
        name         = raw.get("displayName", {}).get("text", "Unknown"),
        address      = raw.get("formattedAddress", ""),
        rating       = float(raw.get("rating", 0.0)),
        review_count = int(raw.get("userRatingCount", 0)),
        distance_mi  = round(haversine_mi(center_lat, center_lng, lat, lng), 2),
        website      = raw.get("websiteUri", ""),
        open_now     = hours.get("openNow"),   # None if key absent
        price_level  = _price_label(raw.get("priceLevel")),
        source       = "google",
        lat          = lat,
        lng          = lng,
    )


def _call_search_text(
    query: str,
    lat: float,
    lng: float,
    radius_m: int,
    limit: int,
) -> list[PlaceResult]:
    """Single POST to places:searchText. Returns parsed PlaceResult list."""
    if not config.GOOGLE_PLACES_API_KEY:
        log.warning("Google Places: GOOGLE_PLACES_API_KEY not set — skipping")
        return []

    body: dict = {
        "textQuery":      query,
        "maxResultCount": min(limit, 20),   # API maximum is 20
        "languageCode":   "en",
    }

    # locationBias nudges results toward the area but does not hard-restrict them.
    # Skip when coordinates are (0, 0) — geocoder failure fallback.
    if lat != 0.0 or lng != 0.0:
        body["locationBias"] = {
            "circle": {
                "center": {"latitude": lat, "longitude": lng},
                "radius": float(radius_m),
            }
        }

    headers = {
        "Content-Type":     "application/json",
        "X-Goog-Api-Key":   config.GOOGLE_PLACES_API_KEY,
        "X-Goog-FieldMask": _FIELD_MASK,
    }

    try:
        resp = requests.post(_SEARCH_URL, json=body, headers=headers, timeout=15)
        resp.raise_for_status()
        places  = resp.json().get("places", [])
        results = [_parse_place(p, lat, lng) for p in places]
        log.info(
            "Google Places: query=%r → %d results (lat=%.4f lng=%.4f radius=%dm)",
            query, len(results), lat, lng, radius_m,
        )
        return results
    except requests.HTTPError as exc:
        log.error(
            "Google Places HTTP %s for query=%r — %s",
            exc.response.status_code, query, exc.response.text[:300],
        )
        return []
    except Exception as exc:
        log.error("Google Places error for query=%r: %s", query, exc)
        return []


def _rank_by_quality(results: list[PlaceResult]) -> list[PlaceResult]:
    """Sort by rating × log10(review_count + 1) — balances quality with credibility."""
    return sorted(results, key=lambda r: r["rating"] * math.log10(r["review_count"] + 1), reverse=True)


# ── Public API ────────────────────────────────────────────────────────────────

def search(
    query: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 5,
) -> list[PlaceResult]:
    """
    Free-text store search near the given coordinates.

    Args:
        query:    e.g. "kasuri methi store near Austin TX"
        lat/lng:  Centre point (use geocoder.geocode() to convert an address)
        radius_m: Search radius in metres (defaults to config.SOURCER_RADIUS_METERS)
        limit:    Max results (capped at 20 by the API)

    Returns:
        List of PlaceResult dicts sorted by distance ascending.
    """
    radius_m = radius_m or config.SOURCER_RADIUS_METERS
    results  = _call_search_text(query, lat, lng, radius_m, limit)
    results.sort(key=lambda r: r["distance_mi"])
    return results[:limit]


def search_generic_stores(
    region_label: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 5,
) -> list[PlaceResult]:
    """
    Find Tier 1 (generic) grocery stores appropriate for a cuisine region.

    Runs all region-matched generic search terms, deduplicates, and returns
    the top `limit` results ranked by quality score.

    Args:
        region_label: e.g. "SOUTH_INDIAN" (case-insensitive)
        lat/lng:      Centre point
        radius_m:     Search radius in metres
        limit:        Results to return
    """
    radius_m   = radius_m or config.SOURCER_RADIUS_METERS
    region_key = region_label.upper()
    terms      = REGION_STORE_TERMS.get(region_key, REGION_STORE_TERMS["UNKNOWN"])

    all_results: list[PlaceResult] = []
    for term in terms["generic"]:
        all_results.extend(_call_search_text(term, lat, lng, radius_m, limit))

    ranked = _rank_by_quality(deduplicate(all_results))
    log.info("Google Places generic stores: region=%r → %d unique", region_label, len(ranked))
    return ranked[:limit]


def search_specialty_stores(
    ingredient: str,
    region_label: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 3,
) -> list[PlaceResult]:
    """
    Find Tier 2 (specialty) stores stocking a specific ingredient.

    Combines a direct ingredient query with region specialty store terms
    for broader coverage. Results sorted by distance-band then rating.

    Args:
        ingredient:   e.g. "kasuri methi"
        region_label: Cuisine region for fallback store terms
        lat/lng:      Centre point
        radius_m:     Search radius in metres
        limit:        Results to return
    """
    radius_m   = radius_m or config.SOURCER_RADIUS_METERS
    region_key = region_label.upper()
    terms      = REGION_STORE_TERMS.get(region_key, REGION_STORE_TERMS["UNKNOWN"])

    queries = [
        f"{ingredient} store",
        f"where to buy {ingredient}",
    ] + terms["specialty"][:2]

    all_results: list[PlaceResult] = []
    for query in queries:
        all_results.extend(_call_search_text(query, lat, lng, radius_m, limit + 2))

    deduped = deduplicate(all_results)
    # Sort: 2-mile distance bands first, then best rating within each band
    deduped.sort(key=lambda r: (round(r["distance_mi"] / 2), -r["rating"]))
    log.info(
        "Google Places specialty: ingredient=%r region=%r → %d unique",
        ingredient, region_label, len(deduped),
    )
    return deduped[:limit]
