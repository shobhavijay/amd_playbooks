"""
Geocoder — address string → (latitude, longitude).

Uses the Google Geocoding API (same key as Google Places New API).
Results are cached in-process so repeated lookups within one pipeline
run do not consume extra quota.

Typical usage:
    from culinary_archivist.tools.geocoder import geocode
    lat, lng = geocode("Austin, TX")
"""
from __future__ import annotations

import logging
from functools import lru_cache

import requests

from culinary_archivist import config

log = logging.getLogger(__name__)

_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"

# ── Region label → city string fallback ───────────────────────────────────────
# Used when SOURCER_LOCATION is blank and we only have a cuisine region from state.
# These are populous representative cities — good enough for store search defaults.
_REGION_CITY_DEFAULTS: dict[str, str] = {
    "SOUTH_INDIAN":   "Chennai, India",
    "NORTH_INDIAN":   "New Delhi, India",
    "PUNJABI":        "Amritsar, India",
    "BENGALI":        "Kolkata, India",
    "GUJARATI":       "Ahmedabad, India",
    "MAHARASHTRIAN":  "Mumbai, India",
    "RAJASTHANI":     "Jaipur, India",
    "KERALA":         "Thiruvananthapuram, India",
    "MEXICAN":        "Mexico City, Mexico",
    "THAI":           "Bangkok, Thailand",
    "CHINESE":        "Shanghai, China",
    "JAPANESE":       "Tokyo, Japan",
    "KOREAN":         "Seoul, South Korea",
    "VIETNAMESE":     "Ho Chi Minh City, Vietnam",
    "MEDITERRANEAN":  "Athens, Greece",
    "TURKISH":        "Istanbul, Turkey",
    "LEBANESE":       "Beirut, Lebanon",
    "MOROCCAN":       "Casablanca, Morocco",
    "FRENCH":         "Paris, France",
    "ITALIAN":        "Rome, Italy",
    "SPANISH":        "Madrid, Spain",
    "GREEK":          "Athens, Greece",
    "AMERICAN":       "New York, NY",
    "CAJUN":          "New Orleans, LA",
    "CARIBBEAN":      "Kingston, Jamaica",
    "ETHIOPIAN":      "Addis Ababa, Ethiopia",
    "WEST_AFRICAN":   "Lagos, Nigeria",
    "PERSIAN":        "Tehran, Iran",
    "UNKNOWN":        "New York, NY",
}


@lru_cache(maxsize=64)
def geocode(address: str) -> tuple[float, float]:
    """
    Convert an address string to (latitude, longitude).

    Returns (0.0, 0.0) on failure so callers can still attempt a text-only
    store search without crashing the pipeline.

    Results are cached — repeated calls with the same address are free.
    """
    if not config.GOOGLE_PLACES_API_KEY:
        log.warning("Geocoder: GOOGLE_PLACES_API_KEY not set — returning (0, 0)")
        return (0.0, 0.0)

    try:
        resp = requests.get(
            _GEOCODE_URL,
            params={"address": address, "key": config.GOOGLE_PLACES_API_KEY},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        if data.get("status") != "OK" or not data.get("results"):
            log.warning("Geocoder: status=%s for address=%r", data.get("status"), address)
            return (0.0, 0.0)

        loc = data["results"][0]["geometry"]["location"]
        lat, lng = loc["lat"], loc["lng"]
        log.info("Geocoder: %r → (%.5f, %.5f)", address, lat, lng)
        return (lat, lng)

    except Exception as exc:
        log.error("Geocoder: failed for address=%r — %s", address, exc)
        return (0.0, 0.0)


def location_for_state(state: dict) -> str:
    """
    Derive a human-readable location string from pipeline state.

    Priority:
      1. SOURCER_LOCATION env var (explicit override)
      2. state["sourcer_location"]  (set by a previous node)
      3. state["user_region_hint"]  (CLI --region flag)
      4. state["origin_consensus"]  (cross-verifier output)
      5. state["final_origin"]      (resolved origin)
      6. Region→city default table
      7. Fallback: "New York, NY"
    """
    if config.SOURCER_LOCATION:
        return config.SOURCER_LOCATION

    for key in ("sourcer_location", "user_region_hint", "origin_consensus", "final_origin"):
        val = state.get(key, "")
        if val and val.upper() not in ("UNKNOWN", ""):
            return val

    # Try region→city table
    region = (
        state.get("best_match_region", "")
        or state.get("user_region_hint", "")
        or ""
    ).upper()
    if region in _REGION_CITY_DEFAULTS:
        city = _REGION_CITY_DEFAULTS[region]
        log.info("Geocoder: derived location %r from region %r", city, region)
        return city

    log.warning("Geocoder: could not derive location from state — using default")
    return "New York, NY"
