"""
Food image extractor — detects and extracts food photos from recipe cards.

Uses vision model to:
1. Detect if recipe card contains a food/dish photo
2. Identify the bounding box region
3. Crop and return the extracted image
"""
from __future__ import annotations

import base64
import io
import json
import logging

from PIL import Image

from culinary_archivist import llm_client

log = logging.getLogger(__name__)


def extract_food_image(image_b64: str) -> str | None:
    """
    Detect if a food/dish image is present in the recipe card.
    If found, return it (cropped if necessary, or full image if entire image is food).
    Returns None if no food image detected.

    Args:
        image_b64: Base64-encoded recipe JPEG (no data: URI prefix)

    Returns:
        Base64-encoded food image, or None if not found
    """
    try:
        # Ask vision model to find the food image
        detection_prompt = """Look at this image. Does it contain a photo of a prepared dish or food?

Answer with ONLY this JSON (no markdown, no explanation):
{
  "has_food_image": true or false,
  "description": "one sentence describing the food if present",
  "location": "where is the food photo? e.g. top, center, bottom, fills entire image, right side, etc",
  "is_entire_image": true if the entire image is a food photo, false if it's part of a larger layout,
  "crop_left_percent": left edge as % of image width (0-100),
  "crop_top_percent": top edge as % of image height (0-100),
  "crop_right_percent": right edge as % of image width (0-100),
  "crop_bottom_percent": bottom edge as % of image height (0-100)
}"""

        response = llm_client.vision_chat(
            prompt=detection_prompt,
            image_b64=image_b64,
            max_tokens=300,
            temperature=0,
        )

        # Clean response (remove markdown if present)
        response = response.strip()
        if response.startswith("```"):
            response = response.split("```")[1].strip()
            if response.startswith("json"):
                response = response[4:].strip()

        log.debug("Food extractor response: %s", response)
        detection = json.loads(response)

        if not detection.get("has_food_image"):
            log.info("Food image extractor: no food image detected")
            return None

        log.info(
            "Food image extractor: found food image — %s (location: %s)",
            detection.get("description", ""),
            detection.get("location", "unknown"),
        )

        # If entire image is food, return as-is
        if detection.get("is_entire_image"):
            log.info("Food image extractor: entire image is food photo, using full image")
            return image_b64

        # Otherwise, crop the image based on provided coordinates
        left = detection.get("crop_left_percent", 0)
        top = detection.get("crop_top_percent", 0)
        right = detection.get("crop_right_percent", 100)
        bottom = detection.get("crop_bottom_percent", 100)

        width_percent = right - left
        height_percent = bottom - top

        cropped_b64 = _crop_image(
            image_b64,
            x_percent=left,
            y_percent=top,
            width_percent=width_percent,
            height_percent=height_percent,
        )

        return cropped_b64

    except Exception as e:
        log.warning("Food image extractor failed: %s", e)
        return None


def _crop_image(
    image_b64: str,
    x_percent: float,
    y_percent: float,
    width_percent: float,
    height_percent: float,
) -> str:
    """
    Crop a base64 image and return cropped result as base64.

    Args:
        image_b64: Base64-encoded image
        x_percent: Left edge as % of width (0-100)
        y_percent: Top edge as % of height (0-100)
        width_percent: Crop width as % of image width (0-100)
        height_percent: Crop height as % of image height (0-100)

    Returns:
        Base64-encoded cropped image
    """
    # Decode base64 to image
    image_bytes = base64.b64decode(image_b64)
    img = Image.open(io.BytesIO(image_bytes))

    # Convert percentages to pixel coordinates
    img_width, img_height = img.size
    x = int(img_width * x_percent / 100)
    y = int(img_height * y_percent / 100)
    right = x + int(img_width * width_percent / 100)
    bottom = y + int(img_height * height_percent / 100)

    # Clamp to image bounds
    x = max(0, min(x, img_width - 1))
    y = max(0, min(y, img_height - 1))
    right = max(x + 1, min(right, img_width))
    bottom = max(y + 1, min(bottom, img_height))

    # Crop
    cropped = img.crop((x, y, right, bottom))

    # Encode back to base64
    buffer = io.BytesIO()
    cropped.save(buffer, format="JPEG", quality=95)
    cropped_b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")

    log.info(
        "Food image extractor: cropped to (%d,%d) %dx%d px",
        x, y, right - x, bottom - y,
    )
    return cropped_b64
