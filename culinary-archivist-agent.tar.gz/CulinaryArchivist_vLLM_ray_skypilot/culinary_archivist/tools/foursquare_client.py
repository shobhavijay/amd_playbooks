"""
Foursquare Places API v3 client.

Endpoint: GET https://api.foursquare.com/v3/places/search

Free tier: 1,000 API calls/day — sufficient for 5-ingredient recipes.
Sign up: https://developer.foursquare.com/

Foursquare complements Google Places well:
  - Stronger coverage for small ethnic/specialty stores
  - Often indexes community-recommended shops that Google misses
  - Different ranking signals → reduces overlap with Google results

Three public functions mirror google_places_client.py:
  search(query, lat, lng, radius_m, limit)
  search_generic_stores(region_label, lat, lng, radius_m, limit)
  search_specialty_stores(ingredient, region_label, lat, lng, radius_m, limit)

Popularity normalisation:
  Foursquare v3 returns `popularity` as a float 0–1 (not 0–10).
  We multiply by 5 to normalise to the 0–5 rating scale used by PlaceResult.

Category IDs:
  We use only two confirmed FSQ v3 taxonomy IDs to avoid filtering out valid
  results with unverified IDs:
    17069 = Grocery Store
    17070 = Specialty Food Store
  Text query is the primary signal; category is a soft filter only.
"""
from __future__ import annotations

import logging
import math

import requests

from culinary_archivist import config
from culinary_archivist.tools._places_utils import (
    PlaceResult,
    REGION_STORE_TERMS,
    deduplicate,
    haversine_mi,
)

log = logging.getLogger(__name__)

_SEARCH_URL = "https://api.foursquare.com/v3/places/search"

# Only confirmed FSQ v3 taxonomy IDs — avoids silently dropping results
# from fabricated/unverified category numbers.
_GROCERY_CATEGORIES = "17069,17070"


# ── Internal helpers ──────────────────────────────────────────────────────────

def _parse_venue(raw: dict, center_lat: float, center_lng: float) -> PlaceResult:
    geo = raw.get("geocodes", {}).get("main", {})
    lat = geo.get("latitude",  0.0)
    lng = geo.get("longitude", 0.0)

    loc = raw.get("location", {})
    address_parts = [
        loc.get("address", ""),
        loc.get("locality", ""),
        loc.get("region", ""),
        loc.get("postcode", ""),
        loc.get("country", ""),
    ]
    address = ", ".join(p for p in address_parts if p)

    # FSQ v3 popularity is 0–1; multiply by 5 to match Google's 0–5 rating scale.
    popularity = float(raw.get("popularity") or 0.0)
    rating     = round(popularity * 5.0, 1)

    # FSQ stats block: total_ratings is the review-equivalent count
    stats        = raw.get("stats") or {}
    review_count = int(stats.get("total_ratings") or stats.get("total_tips") or 0)

    # FSQ price is an integer 1–4; repeat "$" that many times
    price_int   = raw.get("price") or 0
    price_level = "$" * int(price_int) if price_int else ""

    return PlaceResult(
        name         = raw.get("name", "Unknown"),
        address      = address,
        rating       = rating,
        review_count = review_count,
        distance_mi  = round(haversine_mi(center_lat, center_lng, lat, lng), 2),
        website      = raw.get("website", ""),
        open_now     = (raw.get("hours") or {}).get("open_now"),
        price_level  = price_level,
        source       = "foursquare",
        lat          = lat,
        lng          = lng,
    )


def _call_search(
    query: str,
    lat: float,
    lng: float,
    radius_m: int,
    limit: int,
    use_category_filter: bool = True,
) -> list[PlaceResult]:
    """Single GET to Foursquare /v3/places/search. Returns parsed PlaceResult list."""
    if not config.FOURSQUARE_API_KEY:
        log.warning("Foursquare: FOURSQUARE_API_KEY not set — skipping")
        return []

    params: dict = {
        "query":  query,
        "limit":  min(limit, 50),
        "fields": "name,geocodes,location,popularity,stats,website,hours,price",
        "sort":   "DISTANCE",
    }

    if lat != 0.0 or lng != 0.0:
        params["ll"]     = f"{lat},{lng}"
        params["radius"] = radius_m

    if use_category_filter:
        params["categories"] = _GROCERY_CATEGORIES

    headers = {
        "Accept":        "application/json",
        "Authorization": config.FOURSQUARE_API_KEY,
    }

    try:
        resp = requests.get(_SEARCH_URL, params=params, headers=headers, timeout=15)
        resp.raise_for_status()
        venues  = resp.json().get("results", [])
        results = [_parse_venue(v, lat, lng) for v in venues]
        log.info(
            "Foursquare: query=%r → %d results (lat=%.4f lng=%.4f radius=%dm)",
            query, len(results), lat, lng, radius_m,
        )
        return results
    except requests.HTTPError as exc:
        log.error(
            "Foursquare HTTP %s for query=%r — %s",
            exc.response.status_code, query,
            getattr(exc.response, "text", "")[:300],
        )
        return []
    except Exception as exc:
        log.error("Foursquare error for query=%r: %s", query, exc)
        return []


def _rank_by_quality(results: list[PlaceResult]) -> list[PlaceResult]:
    return sorted(results, key=lambda r: r["rating"] * math.log10(r["review_count"] + 1), reverse=True)


# ── Public API ────────────────────────────────────────────────────────────────

def search(
    query: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 5,
) -> list[PlaceResult]:
    """
    Free-text venue search near the given coordinates.

    Args:
        query:    e.g. "kasuri methi store"
        lat/lng:  Centre point
        radius_m: Search radius in metres
        limit:    Max results
    """
    radius_m = radius_m or config.SOURCER_RADIUS_METERS
    results  = _call_search(query, lat, lng, radius_m, limit)
    results.sort(key=lambda r: r["distance_mi"])
    return results[:limit]


def search_generic_stores(
    region_label: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 5,
) -> list[PlaceResult]:
    """
    Find Tier 1 (generic) grocery stores appropriate for a cuisine region.

    Uses the category filter (Grocery Store + Specialty Food Store) to reduce
    noise, combined with region-matched text terms.

    Args:
        region_label: e.g. "SOUTH_INDIAN" (case-insensitive)
        lat/lng:      Centre point
        radius_m:     Search radius in metres
        limit:        Results to return
    """
    radius_m   = radius_m or config.SOURCER_RADIUS_METERS
    region_key = region_label.upper()
    terms      = REGION_STORE_TERMS.get(region_key, REGION_STORE_TERMS["UNKNOWN"])

    all_results: list[PlaceResult] = []
    for term in terms["generic"]:
        all_results.extend(_call_search(term, lat, lng, radius_m, limit, use_category_filter=True))

    ranked = _rank_by_quality(deduplicate(all_results))
    log.info("Foursquare generic stores: region=%r → %d unique", region_label, len(ranked))
    return ranked[:limit]


def search_specialty_stores(
    ingredient: str,
    region_label: str,
    lat: float,
    lng: float,
    radius_m: int | None = None,
    limit: int = 3,
) -> list[PlaceResult]:
    """
    Find Tier 2 (specialty) stores stocking a specific ingredient.

    Category filter is disabled for specialty searches — small ethnic shops
    often lack FSQ category tags and would be incorrectly filtered out.

    Args:
        ingredient:   e.g. "kasuri methi"
        region_label: Cuisine region for fallback store terms
        lat/lng:      Centre point
        radius_m:     Search radius in metres
        limit:        Results to return
    """
    radius_m   = radius_m or config.SOURCER_RADIUS_METERS
    region_key = region_label.upper()
    terms      = REGION_STORE_TERMS.get(region_key, REGION_STORE_TERMS["UNKNOWN"])

    queries = [ingredient] + terms["specialty"][:2]

    all_results: list[PlaceResult] = []
    for query in queries:
        # No category filter — small specialty shops are often uncategorised in FSQ
        all_results.extend(_call_search(query, lat, lng, radius_m, limit + 2, use_category_filter=False))

    deduped = deduplicate(all_results)
    deduped.sort(key=lambda r: (round(r["distance_mi"] / 2), -r["rating"]))
    log.info(
        "Foursquare specialty: ingredient=%r region=%r → %d unique",
        ingredient, region_label, len(deduped),
    )
    return deduped[:limit]
