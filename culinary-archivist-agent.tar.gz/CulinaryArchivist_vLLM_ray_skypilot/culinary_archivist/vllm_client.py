"""
vLLM client — OpenAI-compatible endpoint for AMD MI350X / GPU inference.
Called by llm_client.py when LLM_BACKEND=vllm.

Text, vision, and embedding models each run as a separate vllm serve process:
  Text      : VLLM_TEXT_BASE_URL   (default port 8000)
  Vision    : VLLM_VISION_BASE_URL (default port 8001)
  Embeddings: VLLM_EMBED_BASE_URL  (default port 8002)

All three endpoints are OpenAI-compatible — the openai SDK handles the REST calls.
"""
import logging
import threading
import time

from openai import OpenAI

from culinary_archivist import config

log = logging.getLogger(__name__)

# ── Per-call metrics store ────────────────────────────────────────────────────
# Thread-local so each Ray worker accumulates its own metrics independently.
# Call get_call_metrics() after a pipeline run to retrieve and reset.

_metrics_store = threading.local()


def _record_metrics(model: str, e2e_latency_s: float, prompt_tokens: int, completion_tokens: int) -> None:
    """Record one chat/vision LLM call — e2e latency, token counts, TPS."""
    if not hasattr(_metrics_store, "calls"):
        _metrics_store.calls = []
    tps = round(completion_tokens / e2e_latency_s, 2) if e2e_latency_s > 0 else 0
    _metrics_store.calls.append({
        "model":              model,
        "e2e_latency_ms":    round(e2e_latency_s * 1000, 1),
        "prompt_tokens":     prompt_tokens,
        "completion_tokens": completion_tokens,
        "tps":               tps,
    })


def _record_embed_metrics(model: str, e2e_latency_s: float, n_texts: int) -> None:
    """Record one embed call — e2e latency and vectors per second."""
    if not hasattr(_metrics_store, "embed_calls"):
        _metrics_store.embed_calls = []
    vec_s = round(n_texts / e2e_latency_s, 2) if e2e_latency_s > 0 else 0
    _metrics_store.embed_calls.append({
        "model":          model,
        "e2e_latency_ms": round(e2e_latency_s * 1000, 1),
        "n_texts":        n_texts,
        "vec_s":          vec_s,
    })


def get_call_metrics() -> dict:
    """
    Return and reset all accumulated metrics for this thread.
    Returns {"llm": [...], "embed": [...]}
    """
    llm_calls   = getattr(_metrics_store, "calls",       [])
    embed_calls = getattr(_metrics_store, "embed_calls", [])
    _metrics_store.calls       = []
    _metrics_store.embed_calls = []
    return {"llm": llm_calls, "embed": embed_calls}


def reset_call_metrics() -> None:
    """Clear all accumulated metrics without returning them."""
    _metrics_store.calls       = []
    _metrics_store.embed_calls = []

# ── Singleton clients (one per endpoint) ─────────────────────────────────────

_text_client:   OpenAI | None = None
_vision_client: OpenAI | None = None
_embed_client:  OpenAI | None = None
_ocr_client:    OpenAI | None = None


def _get_text_client() -> OpenAI:
    global _text_client
    if _text_client is None:
        _text_client = OpenAI(
            base_url=config.VLLM_TEXT_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
    return _text_client


def _get_vision_client() -> OpenAI:
    global _vision_client
    if _vision_client is None:
        _vision_client = OpenAI(
            base_url=config.VLLM_VISION_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
    return _vision_client


def _get_embed_client() -> OpenAI:
    global _embed_client
    if _embed_client is None:
        _embed_client = OpenAI(
            base_url=config.VLLM_EMBED_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
    return _embed_client


def _get_ocr_client() -> OpenAI:
    global _ocr_client
    if _ocr_client is None:
        _ocr_client = OpenAI(
            base_url=config.VLLM_OCR_BASE_URL,
            api_key=config.VLLM_API_KEY,
            timeout=config.VLLM_TIMEOUT,
        )
    return _ocr_client


# ── Text chat ─────────────────────────────────────────────────────────────────

def chat(
    messages:    list[dict],
    max_tokens:  int   = 2048,
    temperature: float = 0.0,
) -> str:
    """
    Text generation via vLLM's /v1/chat/completions endpoint.
    System messages are passed as-is — vLLM forwards them to the model.
    """
    log.debug("vllm_client.chat: model=%s  max_tokens=%d", config.VLLM_TEXT_MODEL, max_tokens)
    t0   = time.perf_counter()
    resp = _get_text_client().chat.completions.create(
        model=config.VLLM_TEXT_MODEL,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    e2e = time.perf_counter() - t0
    prompt_tokens     = resp.usage.prompt_tokens     if resp.usage else 0
    completion_tokens = resp.usage.completion_tokens if resp.usage else 0
    _record_metrics(config.VLLM_TEXT_MODEL, e2e, prompt_tokens, completion_tokens)
    return resp.choices[0].message.content


# ── Vision chat ───────────────────────────────────────────────────────────────

def vision_chat(
    prompt:      str,
    image_b64:   str,
    max_tokens:  int   = 1024,
    temperature: float = 0.0,
) -> str:
    """
    Multimodal generation via vLLM's /v1/chat/completions endpoint.
    Image is sent as a base64 data URI in the OpenAI image_url content block.
    vLLM determines the actual media type from the data URI prefix.
    """
    log.debug("vllm_client.vision_chat: model=%s  max_tokens=%d", config.VLLM_VISION_MODEL, max_tokens)
    t0   = time.perf_counter()
    resp = _get_vision_client().chat.completions.create(
        model=config.VLLM_VISION_MODEL,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
                },
                {
                    "type": "text",
                    "text": prompt,
                },
            ],
        }],
        max_tokens=max_tokens,
        temperature=temperature,
    )
    e2e = time.perf_counter() - t0
    prompt_tokens     = resp.usage.prompt_tokens     if resp.usage else 0
    completion_tokens = resp.usage.completion_tokens if resp.usage else 0
    _record_metrics(config.VLLM_VISION_MODEL, e2e, prompt_tokens, completion_tokens)
    return resp.choices[0].message.content


# ── GOT-OCR 2.0 ──────────────────────────────────────────────────────────────

def ocr_image(image_b64: str) -> str:
    """
    Extract text from an image using GOT-OCR 2.0 (port 8003).
    Purpose-built for OCR — handles handwriting, printed text, and mixed layouts.

    Prompt format: image + "OCR:" triggers plain text extraction.
    Use "OCR with format:" for markdown-formatted output (tables, headers).
    """
    log.debug("vllm_client.ocr_image: model=%s", config.VLLM_OCR_MODEL)
    resp = _get_ocr_client().chat.completions.create(
        model=config.VLLM_OCR_MODEL,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
                },
                {
                    "type": "text",
                    "text": "OCR:",
                },
            ],
        }],
        max_tokens=2048,
        temperature=0,
    )
    return resp.choices[0].message.content


# ── Embeddings ────────────────────────────────────────────────────────────────

def embed(texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings via vLLM's /v1/embeddings endpoint.
    Used by chroma_store.py when LLM_BACKEND=vllm.
    """
    log.debug("vllm_client.embed: model=%s  n=%d", config.VLLM_EMBED_MODEL, len(texts))
    t0   = time.perf_counter()
    resp = _get_embed_client().embeddings.create(
        model=config.VLLM_EMBED_MODEL,
        input=texts,
    )
    e2e = time.perf_counter() - t0
    _record_embed_metrics(config.VLLM_EMBED_MODEL, e2e, len(texts))
    return [item.embedding for item in resp.data]
