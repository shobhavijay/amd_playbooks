"""
Runtime identity banner — proves *where* this agent process is running.

The whole point of the vcluster failover demo is a single, unambiguous line of
output showing the agent came up in a different tenant than it started in.
This module collects that evidence and prints it at startup.

Nothing here touches a GPU: the archivist is an HTTP client of `vllm serve`,
so the interesting facts are the tenant, the pod, and which vLLM it resolved.

Env vars (injected per-vcluster by archivist.sky.yaml / the k8s manifests):
    TENANT_NAME     logical tenant, e.g. "team-a" / "team-b"   (default "local")
    NODE_NAME       k8s node          (downward API)
    POD_NAME        k8s pod           (downward API)
    POD_IP          k8s pod IP        (downward API)
    ARCHIVIST_RUN_ID  stable id for one logical run across restarts
"""
import logging
import os
import platform
import socket
import subprocess
import time
import uuid

log = logging.getLogger(__name__)

_BOOT_TS = time.time()


def tenant() -> str:
    return os.getenv("TENANT_NAME", "local")


def run_id() -> str:
    """
    Stable across a failover, unique per logical run.

    SkyPilot relaunches the task with the same `envs`, so ARCHIVIST_RUN_ID
    survives the move — that is what lets you line up the pre- and post-failover
    log segments as one run.
    """
    rid = os.getenv("ARCHIVIST_RUN_ID", "").strip()
    return rid or f"local-{uuid.uuid4().hex[:8]}"


def _gpu_unique_ids() -> list[str]:
    """
    Best-effort `rocm-smi --showuniqueid`.

    Expected to find nothing in the agent pod — it requests zero GPUs. Present
    so the same banner is useful when run directly on the MI300X host, and so
    the demo can *show* that the failover unit holds no device.
    """
    try:
        out = subprocess.run(
            ["rocm-smi", "--showuniqueid"],
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.SubprocessError, OSError):
        return []
    if out.returncode != 0:
        return []
    ids = []
    for line in out.stdout.splitlines():
        if "Unique ID" in line and ":" in line:
            ids.append(line.rsplit(":", 1)[1].strip())
    return ids


def snapshot() -> dict:
    """Collect the identity facts as a dict (also handy for structured logs)."""
    from culinary_archivist import config

    gpus = _gpu_unique_ids()
    return {
        "tenant":       tenant(),
        "run_id":       run_id(),
        "pod":          os.getenv("POD_NAME", "—"),
        "node":         os.getenv("NODE_NAME", "—"),
        "pod_ip":       os.getenv("POD_IP", "—"),
        "hostname":     socket.gethostname(),
        "platform":     f"{platform.system()} {platform.machine()}",
        "pid":          os.getpid(),
        "vllm_text":    config.VLLM_TEXT_BASE_URL,
        "vllm_vision":  config.VLLM_VISION_BASE_URL,
        "vllm_embed":   config.VLLM_EMBED_BASE_URL,
        "state_dir":    str(config.STATE_DIR),
        "checkpoint_db": str(config.CHECKPOINT_DB_PATH),
        "gpu_unique_ids": gpus,
        # Where state ACTUALLY lives, per INSTALL.md Part 7b. Host/port/db only —
        # never the DSN itself, because this dict is handed to log.info() below
        # and `sky jobs logs` ships that off the box.
        "state_store":  _describe_state_store(),
        "vector_store": _describe_vector_store(),
        "blob_store":   _describe_blob_store(),
    }


def _describe_state_store() -> str:
    from urllib.parse import urlsplit
    from culinary_archivist import config
    if not config.USE_POSTGRES:
        return f"sqlite  {config.CHECKPOINT_DB_PATH}"
    u = urlsplit(config.PG_DSN)
    if u.scheme:
        return f"postgres  {u.hostname}:{u.port or 5432}{u.path}"
    return "postgres  (keyword DSN)"


def _describe_vector_store() -> str:
    from culinary_archivist import config
    if config.USE_CHROMA_SERVER:
        return f"chroma server  {config.CHROMA_HOST}:{config.CHROMA_PORT}"
    return f"chroma local  {config.CHROMA_DIR}"


def _describe_blob_store() -> str:
    from culinary_archivist import config
    if config.USE_S3:
        return f"s3  {config.S3_ENDPOINT}/{config.S3_BUCKET}"
    return f"local  {config.OUTPUT_DIR}"


def check_state_plane() -> list[str]:
    """
    Config errors and tenant-hostile settings for the Part 7b state plane.

    Same spirit as the vLLM localhost guard: catch at startup what would
    otherwise surface as a connection error deep inside the first recipe.
    """
    from culinary_archivist import config

    problems = list(config.validate_state_config())
    if tenant() == "local":
        return problems
    local_hosts = ("localhost", "127.0.0.1", "")
    if config.USE_POSTGRES and config.PG_HOST in local_hosts \
       and not os.getenv("ARCHIVIST_PG_DSN", "").strip():
        problems.append(
            f"ARCHIVIST_PG_HOST={config.PG_HOST!r} while running in tenant "
            f"{tenant()!r} — there is no Postgres on this pod's localhost")
    if config.USE_CHROMA_SERVER and config.CHROMA_HOST in local_hosts:
        problems.append(
            f"ARCHIVIST_CHROMA_HOST={config.CHROMA_HOST!r} while running in tenant "
            f"{tenant()!r} — there is no Chroma on this pod's localhost")
    if config.USE_S3 and any(h in config.S3_ENDPOINT for h in ("localhost", "127.0.0.1")):
        problems.append(
            f"ARCHIVIST_S3_ENDPOINT={config.S3_ENDPOINT!r} while running in tenant "
            f"{tenant()!r} — there is no MinIO on this pod's localhost")
    return problems


def check_endpoints_are_reachable_from_here(s: dict) -> list[str]:
    """
    Catch the one misconfiguration that looks like a mystery bug mid-demo.

    A stray .env inside the image re-pins the vLLM URLs to localhost (dotenv
    beats the VLLM_HOST default). In team-a that accidentally *works*, because
    everything historically shared one host. In team-b the pod then dials its
    own empty localhost and every recipe dies deep in the pipeline. Warn at
    startup instead, while the cause is still obvious.
    """
    if tenant() == "local":
        return []
    bad = [
        f"{name}={url}"
        for name, url in (
            ("VLLM_TEXT_BASE_URL",   s["vllm_text"]),
            ("VLLM_VISION_BASE_URL", s["vllm_vision"]),
            ("VLLM_EMBED_BASE_URL",  s["vllm_embed"]),
        )
        if "localhost" in url or "127.0.0.1" in url
    ]
    return bad


def print_banner(role: str = "agent") -> dict:
    """
    Print the identity banner. Returns the snapshot so callers can log it too.

    Read this twice — once before the failover, once after — and the tenant /
    pod / node lines are the proof that the agent moved.
    """
    s = snapshot()

    W = 68            # inner width
    LABEL = 12        # label column
    VAL = W - LABEL - 4

    def row(label, value):
        v = str(value)
        # Middle-truncate: for a path, the tail is the informative half.
        if len(v) > VAL:
            v = "..." + v[-(VAL - 3):]
        return "║  " + f"{label:<{LABEL}}" + ": " + f"{v:<{VAL}}" + "║"

    top = "╔" + "═" * W + "╗"
    mid = "╠" + "═" * W + "╣"
    sep = "╟" + "─" * W + "╢"
    bot = "╚" + "═" * W + "╝"
    title = "CulinaryArchivist — " + role

    print()
    print(top)
    print("║  " + f"{title:<{W - 2}}" + "║")
    print(mid)
    print(row("TENANT",     s["tenant"]))
    print(row("RUN ID",     s["run_id"]))
    print(row("POD / NODE", str(s["pod"]) + " / " + str(s["node"])))
    print(row("HOSTNAME",   str(s["hostname"]) + " (" + str(s["pod_ip"]) + ")"))
    print(row("PID",        s["pid"]))
    print(sep)
    print(row("vLLM text",   s["vllm_text"]))
    print(row("vLLM vision", s["vllm_vision"]))
    print(row("vLLM embed",  s["vllm_embed"]))
    print(sep)
    print(row("state dir",   s["state_dir"]))
    print(row("checkpoints", s["state_store"]))
    print(row("vectors",     s["vector_store"]))
    print(row("blobs",       s["blob_store"]))
    if s["gpu_unique_ids"]:
        print(row("GPUs held", ", ".join(s["gpu_unique_ids"])))
    else:
        print(row("GPUs held", "none — this process is a vLLM *client*"))
    print(bot)
    print()

    for problem in check_endpoints_are_reachable_from_here(s):
        msg = (f"vLLM endpoint points at localhost while running in tenant "
               f"'{s['tenant']}': {problem}. There is no vLLM on this pod's "
               f"localhost — a stray .env in the image is the usual cause.")
        print(f"  ⚠ WARNING: {msg}")
        log.warning(msg)

    for problem in check_state_plane():
        print(f"  ⚠ STATE PLANE: {problem}")
        log.warning("state plane: %s", problem)

    log.info("identity %s", s)
    return s
