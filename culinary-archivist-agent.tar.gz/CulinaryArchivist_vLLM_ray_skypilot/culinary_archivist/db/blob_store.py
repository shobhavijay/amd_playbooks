"""
Where generated PDFs live (INSTALL.md Part 7b).

`local`  — a directory under ARCHIVIST_STATE_DIR, exactly as before.
`s3`     — MinIO (or any S3-compatible endpoint) on the state plane.

Chosen by ARCHIVIST_BLOB_STORE. Callers deal in an opaque `uri` string: a
filesystem path on the local backend, `s3://bucket/key` on the other. Anything
that needs a real file on disk — the Chainlit UI, for instance — calls fetch().

Why blobs are the last thing to move: they need no locking and no transactions,
so on a single node a hostPath directory is genuinely fine. This only earns its
keep when the two vclusters stop sharing a disk.
"""
from __future__ import annotations

import logging
import shutil
import tempfile
from pathlib import Path

from culinary_archivist import config

log = logging.getLogger(__name__)

BACKEND = "s3" if config.USE_S3 else "local"
_S3_PREFIX = "s3://"
_client = None


def _s3():
    global _client
    if _client is not None:
        return _client
    import boto3
    from botocore.config import Config as BotoConfig

    _client = boto3.client(
        "s3",
        endpoint_url=config.S3_ENDPOINT,
        aws_access_key_id=config.S3_ACCESS_KEY,
        aws_secret_access_key=config.S3_SECRET_KEY,
        region_name=config.S3_REGION,
        # MinIO wants path-style addressing; virtual-host style would resolve
        # bucket.minio.archivist-state.svc, which does not exist.
        config=BotoConfig(s3={"addressing_style": "path"},
                          retries={"max_attempts": 3, "mode": "standard"}),
    )
    return _client


def ensure_bucket() -> None:
    """Idempotent. The gate script also creates it; this covers a fresh bucket
    name set by hand."""
    if BACKEND != "s3":
        return
    import botocore.exceptions

    try:
        _s3().head_bucket(Bucket=config.S3_BUCKET)
    except botocore.exceptions.ClientError:
        _s3().create_bucket(Bucket=config.S3_BUCKET)
        log.info("S3: created bucket %s", config.S3_BUCKET)


def staging_path(filename: str) -> Path:
    """
    Somewhere to render into before commit().

    On the local backend this IS the destination, so nothing is copied. On s3 it
    is a temp file — deliberately NOT OUTPUT_DIR, which config.py stops creating
    once blobs are meant to be remote.
    """
    if BACKEND == "s3":
        tmp = Path(tempfile.mkdtemp(prefix="archivist-pdf-")) / filename
        return tmp
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return config.OUTPUT_DIR / filename


def commit(path: Path, key: str) -> str:
    """Publish a staged file. Returns the uri to record as `pdf_path`."""
    path = Path(path)
    if BACKEND != "s3":
        return str(path)

    ensure_bucket()
    _s3().upload_file(str(path), config.S3_BUCKET, key,
                      ExtraArgs={"ContentType": "application/pdf"})
    uri = f"{_S3_PREFIX}{config.S3_BUCKET}/{key}"
    try:
        shutil.rmtree(path.parent, ignore_errors=True)
    except OSError:
        pass
    log.info("S3: uploaded %s", uri)
    return uri


def is_remote(uri: str) -> bool:
    return str(uri or "").startswith(_S3_PREFIX)


def fetch(uri: str) -> Path | None:
    """
    A real file on this machine, for anything that must open one.

    Local uris are returned untouched. Remote ones are downloaded to a temp
    file, so the caller gets a path either way.
    """
    if not uri:
        return None
    if not is_remote(uri):
        p = Path(uri)
        return p if p.exists() else None

    bucket, _, key = uri[len(_S3_PREFIX):].partition("/")
    dest = Path(tempfile.mkdtemp(prefix="archivist-fetch-")) / Path(key).name
    try:
        _s3().download_file(bucket, key, str(dest))
        return dest
    except Exception as exc:                                    # noqa: BLE001
        log.error("S3: could not fetch %s — %s", uri, exc)
        return None
