"""
SQLite store — structured recipe metadata.

Schema (single table):
  recipes — one row per archived recipe, all fields nullable except id/archived_at.

JSON fields (tags, vibe_keywords, registry_scores, ingredients, steps) are stored
as JSON text and round-tripped transparently by the helper functions here.

Thread safety: sqlite3 connections are created per-call (not shared across threads).
This matches LangGraph's default async-executor model where each node runs in its
own thread context.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from culinary_archivist import config

log = logging.getLogger(__name__)

_DB_PATH: Path = config.DB_DIR / "archivist.db"

# ── DDL ───────────────────────────────────────────────────────────────────────

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS recipes (
    -- identity
    id              TEXT PRIMARY KEY,
    archived_at     TEXT NOT NULL,
    media_path      TEXT,
    pdf_path        TEXT,
    mode            TEXT,           -- 'express' | 'full'

    -- core recipe fields
    title           TEXT,
    ingredients     TEXT,           -- JSON array
    steps           TEXT,           -- JSON array
    source_text     TEXT,

    -- provenance
    region          TEXT,           -- best_match_region / user-supplied origin
    sub_region      TEXT,
    era             TEXT,
    origin_consensus TEXT,
    final_origin    TEXT,

    -- classification
    meal_type       TEXT,           -- 'breakfast'|'dessert'|'dinner'|'snack'|'unknown'
    is_hybrid       INTEGER,        -- 0 | 1
    unknown_region  INTEGER,        -- 0 | 1

    -- scorer signals
    signal_density  REAL,
    orphan_ratio    REAL,
    score_margin    REAL,
    registry_scores TEXT,           -- JSON {region_id: score}

    -- enrichment
    tags            TEXT,           -- JSON array
    notes           TEXT,
    vibe_keywords   TEXT,           -- JSON array
    geo_tag         TEXT
);
"""

_INDEX_REGION = """
CREATE INDEX IF NOT EXISTS idx_recipes_region ON recipes (region);
"""
_INDEX_MEAL   = """
CREATE INDEX IF NOT EXISTS idx_recipes_meal_type ON recipes (meal_type);
"""
_INDEX_ERA    = """
CREATE INDEX IF NOT EXISTS idx_recipes_era ON recipes (era);
"""


# ── Connection helper ─────────────────────────────────────────────────────────

def _connect() -> sqlite3.Connection:
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(_DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


# ── Init ──────────────────────────────────────────────────────────────────────

def init_db() -> None:
    """Create the recipes table and indexes if they don't exist."""
    with _connect() as conn:
        conn.execute(_CREATE_TABLE)
        conn.execute(_INDEX_REGION)
        conn.execute(_INDEX_MEAL)
        conn.execute(_INDEX_ERA)
    log.info("SQLite: database ready at %s", _DB_PATH)


# ── JSON helpers ──────────────────────────────────────────────────────────────

def _j(val: Any) -> str | None:
    """Serialize list/dict to JSON string, pass None through."""
    if val is None:
        return None
    if isinstance(val, (list, dict)):
        return json.dumps(val, ensure_ascii=False)
    return val  # already a primitive


def _uj(val: str | None) -> Any:
    """Deserialize JSON string back to list/dict, pass None through."""
    if val is None:
        return None
    try:
        return json.loads(val)
    except (json.JSONDecodeError, TypeError):
        return val


# ── Write ─────────────────────────────────────────────────────────────────────

def upsert_recipe(record: dict) -> None:
    """
    Insert or replace a recipe record.
    `record` must contain 'id' and 'archived_at'; all other fields are optional.
    """
    row = (
        record.get("id"),
        record.get("archived_at"),
        record.get("media_path"),
        record.get("pdf_path"),
        record.get("mode"),
        record.get("title"),
        _j(record.get("ingredients")),
        _j(record.get("steps")),
        record.get("source_text"),
        record.get("region"),
        record.get("sub_region"),
        record.get("era"),
        record.get("origin_consensus"),
        record.get("final_origin"),
        record.get("meal_type"),
        int(bool(record.get("is_hybrid")))    if record.get("is_hybrid")    is not None else None,
        int(bool(record.get("unknown_region"))) if record.get("unknown_region") is not None else None,
        record.get("signal_density"),
        record.get("orphan_ratio"),
        record.get("score_margin"),
        _j(record.get("registry_scores")),
        _j(record.get("tags")),
        record.get("notes"),
        _j(record.get("vibe_keywords")),
        record.get("geo_tag"),
    )

    sql = """
    INSERT OR REPLACE INTO recipes (
        id, archived_at, media_path, pdf_path, mode,
        title, ingredients, steps, source_text,
        region, sub_region, era, origin_consensus, final_origin,
        meal_type, is_hybrid, unknown_region,
        signal_density, orphan_ratio, score_margin, registry_scores,
        tags, notes, vibe_keywords, geo_tag
    ) VALUES (
        ?,?,?,?,?, ?,?,?,?,  ?,?,?,?,?,  ?,?,?,  ?,?,?,?,  ?,?,?,?
    )
    """
    with _connect() as conn:
        conn.execute(sql, row)
    log.info("SQLite: upserted recipe id=%s title=%r", record.get("id"), record.get("title"))


# ── Read helpers (for future query layer) ─────────────────────────────────────

def get_recipe(recipe_id: str) -> dict | None:
    """Fetch a single recipe by UUID. Returns None if not found."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM recipes WHERE id = ?", (recipe_id,)
        ).fetchone()
    if row is None:
        return None
    d = dict(row)
    for field in ("ingredients", "steps", "registry_scores", "tags", "vibe_keywords"):
        d[field] = _uj(d.get(field))
    return d


def delete_recipe(recipe_id: str) -> bool:
    """Delete a recipe by UUID. Returns True if a row was deleted."""
    with _connect() as conn:
        cur = conn.execute("DELETE FROM recipes WHERE id = ?", (recipe_id,))
    deleted = cur.rowcount > 0
    if deleted:
        log.info("SQLite: deleted recipe id=%s", recipe_id)
    else:
        log.warning("SQLite: delete — id=%s not found", recipe_id)
    return deleted


def list_recipes(
    region: str | None = None,
    meal_type: str | None = None,
    limit: int = 50,
) -> list[dict]:
    """
    Simple listing with optional filters.
    Full-text / semantic search is handled by ChromaDB (Living Cookbook phase).
    """
    clauses, params = [], []
    if region:
        clauses.append("region = ?")
        params.append(region)
    if meal_type:
        clauses.append("meal_type = ?")
        params.append(meal_type)

    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    sql = f"SELECT * FROM recipes {where} ORDER BY archived_at DESC LIMIT ?"
    params.append(limit)

    with _connect() as conn:
        rows = conn.execute(sql, params).fetchall()

    result = []
    for row in rows:
        d = dict(row)
        for field in ("ingredients", "steps", "registry_scores", "tags", "vibe_keywords"):
            d[field] = _uj(d.get(field))
        result.append(d)
    return result
