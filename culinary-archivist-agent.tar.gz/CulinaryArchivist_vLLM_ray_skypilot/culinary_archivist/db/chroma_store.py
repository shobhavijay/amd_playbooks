"""
ChromaDB store — recipe text embeddings.

Collection: "recipes"
  document  : title + ingredients + steps (plain text, one doc per recipe)
  metadata  : region, meal_type, era, is_hybrid, tags, pdf_path, mode, archived_at
  id        : same UUID as SQLite recipes.id

Embedding function:
  Uses OpenAIEmbeddingFunction pointed at vLLM's /v1/embeddings endpoint.
  Model: BAAI/bge-m3 (multilingual, 1024-dim, served via vllm serve on port 8002)

LlamaParse migration path:
  When switching to LlamaParse + LlamaIndex, point llama-index-vector-stores-chroma
  at the same CHROMA_DIR path.  The collection can be rebuilt via
  llama_index.vector_stores.ChromaVectorStore(chroma_collection=collection).
"""
from __future__ import annotations

import logging
import os
from typing import Any

import chromadb

from culinary_archivist import config

log = logging.getLogger(__name__)

_COLLECTION_NAME = "recipes"

# ── Client + collection (module-level singleton) ──────────────────────────────

_client: chromadb.ClientAPI | None = None
_collection: chromadb.Collection | None = None


def _make_embedding_function():
    if config.USE_LOCAL_EMBEDDINGS:
        # Chroma's bundled ONNX MiniLM, CPU only. See config.EMBED_BACKEND for
        # why this exists: bge-m3 is an encoder model and vLLM's ROCm backend
        # has no encoder self-attention.
        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
        log.info("ChromaDB: embeddings = local ONNX MiniLM (CPU, 384-dim)")
        return DefaultEmbeddingFunction()

    from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction

    # Chroma 1.x persists the collection's embedding-function config and warns
    # that a directly-passed api_key is NOT persisted. In server mode that config
    # lives in the Chroma deployment rather than a local directory, so route the
    # key through the environment variable Chroma expects instead of inline.
    # vLLM accepts the literal "EMPTY"; this is not a real credential.
    os.environ.setdefault("CHROMA_OPENAI_API_KEY", config.VLLM_API_KEY or "EMPTY")
    return OpenAIEmbeddingFunction(
        api_key_env_var="CHROMA_OPENAI_API_KEY",
        api_base=config.VLLM_EMBED_BASE_URL,
        model_name=config.VLLM_EMBED_MODEL,
    )
    # ── Disabled: Ollama embedding ────────────────────────────────────────────
    # from chromadb.utils.embedding_functions import OllamaEmbeddingFunction
    # return OllamaEmbeddingFunction(
    #     url=f"{config.OLLAMA_BASE_URL}/api/embeddings",
    #     model_name=config.EMBED_MODEL,
    # )


def _get_collection() -> chromadb.Collection:
    global _client, _collection
    if _collection is not None:
        return _collection

    embed_fn = _make_embedding_function()

    if config.USE_CHROMA_SERVER:
        # Vectors live in the Chroma deployment on the host cluster (INSTALL.md
        # Part 7b), reachable over HTTP from either vcluster. This is what takes
        # the last SQLite writer off the shared volume.
        _client = chromadb.HttpClient(
            host=config.CHROMA_HOST,
            port=config.CHROMA_PORT,
            ssl=config.CHROMA_SSL,
        )
        where = f"{config.CHROMA_HOST}:{config.CHROMA_PORT}"
    else:
        config.CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        _client = chromadb.PersistentClient(path=str(config.CHROMA_DIR))
        where = str(config.CHROMA_DIR)

    # `metadata={"hnsw:space": ...}` is still honoured in 1.x — Chroma translates
    # it into the collection configuration (verified against 1.5.9).
    _collection = _client.get_or_create_collection(
        name=_COLLECTION_NAME,
        embedding_function=embed_fn,
        metadata={"hnsw:space": "cosine"},  # cosine similarity for semantic search
    )
    log.info(
        "ChromaDB: collection '%s' ready at %s  (mode=%s, embed_model=%s)",
        _COLLECTION_NAME, where, config.CHROMA_MODE, config.VLLM_EMBED_MODEL,
    )
    return _collection


# ── Document builder ──────────────────────────────────────────────────────────

def _build_document(record: dict) -> str:
    """
    Concatenate recipe fields into a single searchable document string.
    This is what gets embedded — the richer it is, the better semantic search works.
    """
    parts: list[str] = []

    if record.get("title"):
        parts.append(f"Title: {record['title']}")
    if record.get("region"):
        parts.append(f"Region: {record['region']}")
    if record.get("era"):
        parts.append(f"Era: {record['era']}")
    if record.get("meal_type"):
        parts.append(f"Meal type: {record['meal_type']}")

    ingredients = record.get("ingredients") or []
    if ingredients:
        parts.append("Ingredients: " + ", ".join(ingredients))

    steps = record.get("steps") or []
    if steps:
        parts.append("Steps: " + " ".join(steps))

    vibe = record.get("vibe_keywords") or []
    if vibe:
        parts.append("Vibe: " + ", ".join(vibe))

    if record.get("notes"):
        parts.append(f"Notes: {record['notes']}")

    return "\n".join(parts)


def _build_metadata(record: dict) -> dict[str, Any]:
    """
    ChromaDB metadata must be flat (str | int | float | bool values only).
    Lists are JSON-serialised to strings.
    """
    import json

    tags = record.get("tags") or []
    vibe = record.get("vibe_keywords") or []

    return {
        "title":          record.get("title") or "",
        "region":         record.get("region") or "",
        "sub_region":     record.get("sub_region") or "",
        "era":            record.get("era") or "",
        "meal_type":      record.get("meal_type") or "unknown",
        "mode":           record.get("mode") or "",
        "is_hybrid":      bool(record.get("is_hybrid")),
        "unknown_region": bool(record.get("unknown_region")),
        "signal_density": float(record.get("signal_density") or 0.0),
        "orphan_ratio":   float(record.get("orphan_ratio") or 0.0),
        "tags":           json.dumps(tags),
        "vibe_keywords":  json.dumps(vibe),
        "pdf_path":       record.get("pdf_path") or "",
        "archived_at":    record.get("archived_at") or "",
    }


# ── Write ─────────────────────────────────────────────────────────────────────

def upsert_recipe(record: dict) -> None:
    """
    Embed and store a recipe in ChromaDB.
    Uses upsert so re-indexing an existing recipe updates it rather than duplicating.
    """
    recipe_id = record.get("id")
    if not recipe_id:
        log.warning("ChromaDB: skipping upsert — record has no 'id'")
        return

    document = _build_document(record)
    if not document.strip():
        log.warning("ChromaDB: skipping upsert for id=%s — empty document", recipe_id)
        return

    metadata = _build_metadata(record)

    try:
        coll = _get_collection()
        coll.upsert(
            ids=[recipe_id],
            documents=[document],
            metadatas=[metadata],
        )
        log.info("ChromaDB: upserted recipe id=%s title=%r", recipe_id, record.get("title"))
    except Exception as exc:
        # ChromaDB failure (e.g. nomic-embed-text not pulled) must not crash the pipeline.
        # The recipe is already safe in SQLite; ChromaDB is additive.
        log.error(
            "ChromaDB: upsert failed for id=%s — %s. "
            "Recipe is saved in SQLite. "
            "Check vLLM embed server is running: curl http://localhost:8002/v1/models",
            recipe_id, exc,
        )


# ── Read helpers (for Living Cookbook phase) ──────────────────────────────────

def delete_recipe(recipe_id: str) -> bool:
    """Remove a recipe embedding from ChromaDB. Returns True on success."""
    try:
        coll = _get_collection()
        coll.delete(ids=[recipe_id])
        log.info("ChromaDB: deleted recipe id=%s", recipe_id)
        return True
    except Exception as exc:
        log.error("ChromaDB: delete failed for id=%s — %s", recipe_id, exc)
        return False


def query_similar(text: str, n_results: int = 5) -> list[dict]:
    """
    Semantic similarity search — returns n_results closest recipe records.
    Metadata only (no raw embeddings). Used by the Living Cookbook query layer.
    """
    try:
        results = _get_collection().query(
            query_texts=[text],
            n_results=n_results,
            include=["metadatas", "distances", "documents"],
        )
        out = []
        for i, meta in enumerate(results["metadatas"][0]):
            out.append({
                **meta,
                "id":       results["ids"][0][i],
                "distance": results["distances"][0][i],
                "document": results["documents"][0][i],
            })
        return out
    except Exception as exc:
        log.error("ChromaDB: query failed — %s", exc)
        return []
