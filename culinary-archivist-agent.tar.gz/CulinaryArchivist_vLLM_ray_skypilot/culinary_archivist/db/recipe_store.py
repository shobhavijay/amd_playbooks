"""
Backend-agnostic recipe store.

Import from here, not from sqlite_store / postgres_store directly — the choice
is made once, by ARCHIVIST_STATE_BACKEND, and both modules present identical
signatures and return shapes.
"""
from __future__ import annotations

from culinary_archivist import config

if config.USE_POSTGRES:
    from culinary_archivist.db import postgres_store as _impl
else:
    from culinary_archivist.db import sqlite_store as _impl

BACKEND = "postgres" if config.USE_POSTGRES else "sqlite"

init_db      = _impl.init_db
upsert_recipe = _impl.upsert_recipe
get_recipe   = _impl.get_recipe
delete_recipe = _impl.delete_recipe
list_recipes = _impl.list_recipes

__all__ = ["BACKEND", "init_db", "upsert_recipe", "get_recipe",
           "delete_recipe", "list_recipes"]
