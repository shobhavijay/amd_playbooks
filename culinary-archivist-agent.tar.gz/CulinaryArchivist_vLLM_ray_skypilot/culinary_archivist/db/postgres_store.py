"""
Postgres recipe store — the state-plane twin of sqlite_store (INSTALL.md Part 7b).

Same five public functions, same argument and return shapes, so
db/recipe_store.py can pick either at import time and nothing upstream changes.

Two deliberate differences from a naive port:

* JSON columns are real `jsonb`, not text. psycopg returns them already parsed,
  which is exactly the shape sqlite_store produces after its `_uj()` pass.
* The 0/1 flag columns are real `boolean`, but reads normalise them back to
  `int | None`. SQLite hands back `1`; Postgres would hand back `True`. Nothing
  today depends on the difference (both consumers call `bool()`), and keeping
  them identical means swapping backends can never quietly change behaviour.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from culinary_archivist import config

log = logging.getLogger(__name__)

_JSON_FIELDS = ("ingredients", "steps", "registry_scores", "tags", "vibe_keywords")
_BOOL_FIELDS = ("is_hybrid", "unknown_region")

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS recipes (
    id               text PRIMARY KEY,
    archived_at      text NOT NULL,
    media_path       text,
    pdf_path         text,
    mode             text,

    title            text,
    ingredients      jsonb,
    steps            jsonb,
    source_text      text,

    region           text,
    sub_region       text,
    era              text,
    origin_consensus text,
    final_origin     text,

    meal_type        text,
    is_hybrid        boolean,
    unknown_region   boolean,

    signal_density   double precision,
    orphan_ratio     double precision,
    score_margin     double precision,
    registry_scores  jsonb,

    tags             jsonb,
    notes            text,
    vibe_keywords    jsonb,
    geo_tag          text
);
"""
_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_recipes_region    ON recipes (region);",
    "CREATE INDEX IF NOT EXISTS idx_recipes_meal_type ON recipes (meal_type);",
    "CREATE INDEX IF NOT EXISTS idx_recipes_era       ON recipes (era);",
)

_COLUMNS = (
    "id", "archived_at", "media_path", "pdf_path", "mode",
    "title", "ingredients", "steps", "source_text",
    "region", "sub_region", "era", "origin_consensus", "final_origin",
    "meal_type", "is_hybrid", "unknown_region",
    "signal_density", "orphan_ratio", "score_margin", "registry_scores",
    "tags", "notes", "vibe_keywords", "geo_tag",
)

_conn = None


def _connect():
    """One module-level connection, opened lazily. autocommit mirrors the
    sqlite module's `with conn:` commit-per-statement behaviour."""
    global _conn
    import psycopg
    from psycopg.rows import dict_row

    if _conn is not None and not _conn.closed:
        return _conn
    _conn = psycopg.connect(config.PG_DSN, autocommit=True, row_factory=dict_row)
    return _conn


def _jb(val: Any):
    """Wrap for a jsonb column. Accepts an object, or a JSON string from a
    caller that already serialised it."""
    from psycopg.types.json import Jsonb

    if val is None:
        return None
    if isinstance(val, str):
        try:
            val = json.loads(val)
        except (ValueError, TypeError):
            pass
    return Jsonb(val)


def _flag(val: Any):
    return None if val is None else bool(val)


def _normalise(d: dict) -> dict:
    """Match sqlite_store's return shape exactly."""
    out = dict(d)
    for f in _BOOL_FIELDS:
        if out.get(f) is not None:
            out[f] = int(out[f])
    return out


def init_db() -> None:
    conn = _connect()
    with conn.cursor() as cur:
        cur.execute(_CREATE_TABLE)
        for stmt in _INDEXES:
            cur.execute(stmt)
    log.info("Postgres: recipes table ready at %s", config.PG_DSN_SAFE)


def upsert_recipe(record: dict) -> None:
    row = [
        record.get("id"), record.get("archived_at"), record.get("media_path"),
        record.get("pdf_path"), record.get("mode"),
        record.get("title"), _jb(record.get("ingredients")), _jb(record.get("steps")),
        record.get("source_text"),
        record.get("region"), record.get("sub_region"), record.get("era"),
        record.get("origin_consensus"), record.get("final_origin"),
        record.get("meal_type"), _flag(record.get("is_hybrid")),
        _flag(record.get("unknown_region")),
        record.get("signal_density"), record.get("orphan_ratio"),
        record.get("score_margin"), _jb(record.get("registry_scores")),
        _jb(record.get("tags")), record.get("notes"),
        _jb(record.get("vibe_keywords")), record.get("geo_tag"),
    ]
    cols = ", ".join(_COLUMNS)
    ph = ", ".join(["%s"] * len(_COLUMNS))
    updates = ", ".join(f"{c} = EXCLUDED.{c}" for c in _COLUMNS if c != "id")
    sql = (f"INSERT INTO recipes ({cols}) VALUES ({ph}) "
           f"ON CONFLICT (id) DO UPDATE SET {updates}")
    with _connect().cursor() as cur:
        cur.execute(sql, row)
    log.info("Postgres: upserted recipe id=%s title=%r",
             record.get("id"), record.get("title"))


def get_recipe(recipe_id: str) -> dict | None:
    with _connect().cursor() as cur:
        cur.execute("SELECT * FROM recipes WHERE id = %s", (recipe_id,))
        row = cur.fetchone()
    return _normalise(row) if row else None


def delete_recipe(recipe_id: str) -> bool:
    with _connect().cursor() as cur:
        cur.execute("DELETE FROM recipes WHERE id = %s", (recipe_id,))
        deleted = cur.rowcount > 0
    if deleted:
        log.info("Postgres: deleted recipe id=%s", recipe_id)
    else:
        log.warning("Postgres: delete — id=%s not found", recipe_id)
    return deleted


def list_recipes(region: str | None = None, meal_type: str | None = None,
                 limit: int = 50) -> list[dict]:
    clauses, params = [], []
    if region:
        clauses.append("region = %s")
        params.append(region)
    if meal_type:
        clauses.append("meal_type = %s")
        params.append(meal_type)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params.append(limit)
    with _connect().cursor() as cur:
        cur.execute(f"SELECT * FROM recipes {where} "
                    f"ORDER BY archived_at DESC LIMIT %s", params)
        rows = cur.fetchall()
    return [_normalise(r) for r in rows]
