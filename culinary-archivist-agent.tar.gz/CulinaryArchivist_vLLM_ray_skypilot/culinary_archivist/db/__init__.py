"""
Phase 7 — Dual-store persistence layer.

SQLite  : structured recipe metadata (title, region, era, meal_type, tags …)
ChromaDB: recipe text embeddings for future semantic search (Living Cookbook)

Both stores share the same recipe UUID as primary key.
"""
