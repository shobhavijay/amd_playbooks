"""
Ray Serve client — HTTP client for the LLM gateway deployed by ray_serve/serve_app.py.

Called by llm_client.py when LLM_BACKEND=ray_serve.
The interface is identical to vllm_client.py so no other code changes.

.env:
    LLM_BACKEND=ray_serve
    RAY_SERVE_BASE_URL=http://localhost:8080
"""
import logging

import requests

from culinary_archivist import config

log = logging.getLogger(__name__)


def _post(path: str, payload: dict) -> dict:
    url = config.RAY_SERVE_BASE_URL.rstrip("/") + path
    log.debug("ray_serve_client → POST %s", url)
    try:
        resp = requests.post(url, json=payload, timeout=config.VLLM_TIMEOUT)
        resp.raise_for_status()
        return resp.json()
    except requests.ConnectionError:
        raise RuntimeError(
            f"Cannot reach Ray Serve gateway at {url}. "
            "Run 'python -m ray_serve.serve_app' first."
        )
    except requests.HTTPError as e:
        raise RuntimeError(f"Ray Serve gateway error ({e.response.status_code}): {e.response.text[:200]}")


def chat(
    messages:    list[dict],
    max_tokens:  int   = 2048,
    temperature: float = 0.0,
) -> str:
    data = _post("/chat", {
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": temperature,
    })
    return data["content"]


def vision_chat(
    prompt:      str,
    image_b64:   str,
    max_tokens:  int   = 1024,
    temperature: float = 0.0,
) -> str:
    data = _post("/vision", {
        "prompt":      prompt,
        "image_b64":   image_b64,
        "max_tokens":  max_tokens,
        "temperature": temperature,
    })
    return data["content"]


def embed(texts: list[str]) -> list[list[float]]:
    data = _post("/embed", {"texts": texts})
    return data["embeddings"]


def ocr_image(image_b64: str) -> str:
    data = _post("/ocr", {"image_b64": image_b64})
    return data["text"]
