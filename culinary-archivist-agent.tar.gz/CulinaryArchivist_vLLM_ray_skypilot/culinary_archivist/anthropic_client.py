"""
Anthropic client — Claude models via Anthropic API.
Mirrors vllm_client.py interface for drop-in compatibility.

Models:
  Text   : claude-opus-4-1 (default)
  Vision : claude-3-5-sonnet (has vision)
  Embed  : Not supported by Anthropic (fallback to None)
"""
import base64
import logging
import threading
import time

import anthropic

from culinary_archivist import config

log = logging.getLogger(__name__)

# ── Per-call metrics store ────────────────────────────────────────────────────
_metrics_store = threading.local()


def _record_metrics(model: str, e2e_latency_s: float, prompt_tokens: int, completion_tokens: int) -> None:
    """Record one chat/vision LLM call — e2e latency, token counts, TPS."""
    if not hasattr(_metrics_store, "calls"):
        _metrics_store.calls = []
    tps = round(completion_tokens / e2e_latency_s, 2) if e2e_latency_s > 0 else 0
    _metrics_store.calls.append({
        "model":              model,
        "e2e_latency_ms":    round(e2e_latency_s * 1000, 1),
        "prompt_tokens":     prompt_tokens,
        "completion_tokens": completion_tokens,
        "tps":               tps,
    })


def _record_embed_metrics(model: str, e2e_latency_s: float, n_texts: int) -> None:
    """Record one embed call — e2e latency and vectors per second."""
    if not hasattr(_metrics_store, "embed_calls"):
        _metrics_store.embed_calls = []
    vec_s = round(n_texts / e2e_latency_s, 2) if e2e_latency_s > 0 else 0
    _metrics_store.embed_calls.append({
        "model":          model,
        "e2e_latency_ms": round(e2e_latency_s * 1000, 1),
        "n_texts":        n_texts,
        "vec_s":          vec_s,
    })


def get_call_metrics() -> dict:
    """Return and reset all accumulated metrics for this thread."""
    llm_calls   = getattr(_metrics_store, "calls",       [])
    embed_calls = getattr(_metrics_store, "embed_calls", [])
    _metrics_store.calls       = []
    _metrics_store.embed_calls = []
    return {"llm": llm_calls, "embed": embed_calls}


def reset_call_metrics() -> None:
    """Clear all accumulated metrics without returning them."""
    _metrics_store.calls       = []
    _metrics_store.embed_calls = []


# ── Singleton client ──────────────────────────────────────────────────────────

_client: anthropic.Anthropic | None = None


def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
    return _client


# ── Text chat ─────────────────────────────────────────────────────────────────

def chat(
    messages:    list[dict],
    max_tokens:  int   = 2048,
    temperature: float = 0.0,
) -> str:
    """
    Text generation via Claude API.
    Supports system messages in the standard format.
    """
    model = config.CLAUDE_TEXT_MODEL
    log.debug("anthropic_client.chat: model=%s  max_tokens=%d", model, max_tokens)
    t0 = time.perf_counter()

    # Extract system message if present
    system_msg = None
    filtered_messages = []
    for msg in messages:
        if msg.get("role") == "system":
            system_msg = msg.get("content")
        else:
            filtered_messages.append(msg)

    # Build kwargs dict, only including system if present
    kwargs = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": filtered_messages,
        "temperature": temperature,
    }
    if system_msg:
        kwargs["system"] = system_msg

    resp = _get_client().messages.create(**kwargs)

    e2e = time.perf_counter() - t0
    prompt_tokens = resp.usage.input_tokens if resp.usage else 0
    completion_tokens = resp.usage.output_tokens if resp.usage else 0
    _record_metrics(model, e2e, prompt_tokens, completion_tokens)

    return resp.content[0].text if resp.content else ""


# ── Vision chat ───────────────────────────────────────────────────────────────

def vision_chat(
    prompt:      str,
    image_b64:   str,
    max_tokens:  int   = 1024,
    temperature: float = 0.0,
) -> str:
    """
    Multimodal generation via Claude API.
    Image is passed as base64 data URI.
    """
    model = config.CLAUDE_VISION_MODEL
    log.debug("anthropic_client.vision_chat: model=%s  max_tokens=%d", model, max_tokens)
    t0 = time.perf_counter()

    resp = _get_client().messages.create(
        model=model,
        max_tokens=max_tokens,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": image_b64,
                    },
                },
                {
                    "type": "text",
                    "text": prompt,
                },
            ],
        }],
        temperature=temperature,
    )

    e2e = time.perf_counter() - t0
    prompt_tokens = resp.usage.input_tokens if resp.usage else 0
    completion_tokens = resp.usage.output_tokens if resp.usage else 0
    _record_metrics(model, e2e, prompt_tokens, completion_tokens)

    return resp.content[0].text if resp.content else ""


# ── OCR image ─────────────────────────────────────────────────────────────────

def ocr_image(image_b64: str) -> str:
    """
    Extract text from image using Claude Vision.
    Uses the same vision model as vision_chat.
    """
    model = config.CLAUDE_VISION_MODEL
    log.debug("anthropic_client.ocr_image: model=%s", model)

    resp = _get_client().messages.create(
        model=model,
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": image_b64,
                    },
                },
                {
                    "type": "text",
                    "text": "Extract all text from this image. Return only the text, no explanations.",
                },
            ],
        }],
        temperature=0,
    )

    return resp.content[0].text if resp.content else ""


# ── Embeddings ────────────────────────────────────────────────────────────────

def embed(texts: list[str]) -> list[list[float]]:
    """
    Anthropic doesn't support embeddings.
    This is a stub that returns None — the pipeline should handle this gracefully
    or fall back to a dedicated embedding model (e.g., via vLLM or OpenAI).
    """
    log.warning("anthropic_client.embed: not supported by Anthropic API. Returning None.")
    return None
