"""
LLM client — routes to vLLM or Ray Serve gateway based on LLM_BACKEND.

Usage:

    from culinary_archivist import llm_client

    # Text call
    text = llm_client.chat(
        messages=[{"role": "user", "content": "..."}],
        max_tokens=2048,
    )

    # Vision call (image + text)
    text = llm_client.vision_chat(
        prompt="Read this recipe image...",
        image_b64="<base64 string>",
        max_tokens=1024,
    )

.env switching:

    # Direct vLLM (default)
    LLM_BACKEND=vllm

    # Ray Serve gateway (run ray_serve/serve_app.py first)
    LLM_BACKEND=ray_serve
    RAY_SERVE_BASE_URL=http://localhost:8080

PyMuPDF path:
    PDF → Tesseract OCR → text → chat()   (no vision_chat needed)
    Only the structuring call goes through chat().
"""
import logging

from culinary_archivist import config

log = logging.getLogger(__name__)


# ── Disabled: Ollama backend ──────────────────────────────────────────────────
# def _ollama_chat(messages, max_tokens, temperature):
#     from culinary_archivist import ollama_client
#     response = ollama_client.chat(
#         model=config.TEXT_MODEL,
#         messages=messages,
#         options={"num_predict": max_tokens, "temperature": temperature},
#     )
#     return response["message"]["content"]
#
# def _ollama_vision_chat(prompt, image_b64, max_tokens, temperature):
#     from culinary_archivist import ollama_client
#     response = ollama_client.chat(
#         model=config.VISION_MODEL,
#         messages=[{"role": "user", "content": prompt, "images": [image_b64]}],
#         options={"num_predict": max_tokens, "temperature": temperature},
#     )
#     return response["message"]["content"]


# ── Disabled: Anthropic Claude backend ───────────────────────────────────────
# def _claude_chat(messages, max_tokens, temperature):
#     from culinary_archivist import claude_client
#     system_msg = ""
#     user_messages = []
#     for m in messages:
#         if m["role"] == "system":
#             system_msg = m["content"]
#         else:
#             user_messages.append({"role": m["role"], "content": m["content"]})
#     response = claude_client.chat(
#         model=config.CLAUDE_TEXT_MODEL,
#         messages=user_messages,
#         max_tokens=max_tokens,
#         system=system_msg,
#     )
#     return response.content[0].text
#
# def _claude_vision_chat(prompt, image_b64, max_tokens, temperature):
#     from culinary_archivist import claude_client
#     response = claude_client.chat(
#         model=config.CLAUDE_VISION_MODEL,
#         max_tokens=max_tokens,
#         messages=[{"role": "user", "content": [
#             {"type": "image", "source": {"type": "base64",
#              "media_type": "image/jpeg", "data": image_b64}},
#             {"type": "text", "text": prompt},
#         ]}],
#     )
#     return response.content[0].text


# ── Public API ────────────────────────────────────────────────────────────────

def chat(
    messages:    list[dict],
    max_tokens:  int   = 2048,
    temperature: float = 0.0,
) -> str:
    """
    Text LLM call — routed to vLLM, Ray Serve, or Anthropic based on LLM_BACKEND.

    Args:
        messages:    List of {"role": "user"|"assistant"|"system", "content": str}
        max_tokens:  Maximum tokens to generate
        temperature: Sampling temperature (0 = deterministic)

    Returns:
        Response text as a plain string.
    """
    backend = config.LLM_BACKEND.lower()
    log.debug("llm_client.chat: backend=%s  max_tokens=%d", backend, max_tokens)
    if backend == "anthropic":
        from culinary_archivist import anthropic_client
        return anthropic_client.chat(messages, max_tokens, temperature)
    if backend == "ray_serve":
        from culinary_archivist import ray_serve_client
        return ray_serve_client.chat(messages, max_tokens, temperature)
    from culinary_archivist import vllm_client
    return vllm_client.chat(messages, max_tokens, temperature)


def ocr_image(image_b64: str) -> str:
    """
    OCR call — routed to vLLM, Ray Serve, or Anthropic based on LLM_BACKEND.
    Optimised for handwritten and printed document text extraction.

    Args:
        image_b64: Base64-encoded image string (no data: URI prefix)

    Returns:
        Extracted text as a plain string.
    """
    backend = config.LLM_BACKEND.lower()
    log.debug("llm_client.ocr_image: backend=%s", backend)
    if backend == "anthropic":
        from culinary_archivist import anthropic_client
        return anthropic_client.ocr_image(image_b64)
    if backend == "ray_serve":
        from culinary_archivist import ray_serve_client
        return ray_serve_client.ocr_image(image_b64)
    from culinary_archivist import vllm_client
    return vllm_client.ocr_image(image_b64)


def vision_chat(
    prompt:      str,
    image_b64:   str,
    max_tokens:  int   = 1024,
    temperature: float = 0.0,
) -> str:
    """
    Vision LLM call — text prompt + one image, routed to vLLM, Ray Serve, or Anthropic.

    Args:
        prompt:      Text instruction (e.g. "Read every word in this recipe image")
        image_b64:   Base64-encoded image string (no data: URI prefix)
        max_tokens:  Maximum tokens to generate
        temperature: Sampling temperature (0 = deterministic)

    Returns:
        Response text as a plain string.
    """
    backend = config.LLM_BACKEND.lower()
    log.debug("llm_client.vision_chat: backend=%s  max_tokens=%d", backend, max_tokens)
    if backend == "anthropic":
        from culinary_archivist import anthropic_client
        return anthropic_client.vision_chat(prompt, image_b64, max_tokens, temperature)
    if backend == "ray_serve":
        from culinary_archivist import ray_serve_client
        return ray_serve_client.vision_chat(prompt, image_b64, max_tokens, temperature)
    from culinary_archivist import vllm_client
    return vllm_client.vision_chat(prompt, image_b64, max_tokens, temperature)
