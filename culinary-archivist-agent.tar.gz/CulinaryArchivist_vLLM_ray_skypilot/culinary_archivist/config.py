import os
import re
from pathlib import Path
from urllib.parse import quote, urlsplit, urlunsplit

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent

# ── Identity (vcluster failover demo) ─────────────────────────────────────────
# TENANT_NAME is injected per-vcluster; RUN_ID is injected by archivist.sky.yaml
# and SURVIVES a failover, which is what lets you stitch the pre- and post-move
# log segments into one run. See culinary_archivist/identity.py.
TENANT_NAME = os.getenv("TENANT_NAME", "local")
RUN_ID      = os.getenv("ARCHIVIST_RUN_ID", "local")

# ── State root ────────────────────────────────────────────────────────────────
# On Kubernetes every one of these must live on the SHARED volume, not in the
# container filesystem — the pod is destroyed on failover and takes its local
# disk with it. Set ARCHIVIST_STATE_DIR (the k8s path, e.g. /state) and the four
# sub-paths follow automatically; leave it unset and you get the original
# laptop-relative layout, so local runs are unchanged.
_STATE_ROOT = os.getenv("ARCHIVIST_STATE_DIR", "").strip()
STATE_DIR   = Path(_STATE_ROOT) if _STATE_ROOT else Path.cwd()


def _state_path(env_var: str, default_name: str) -> Path:
    """
    Resolve a stateful path against STATE_DIR.

    An ABSOLUTE override is honoured as-is. A RELATIVE one (the .env in this
    repo ships "./output", "./data") resolves under STATE_DIR — NOT the process
    CWD. That distinction is the whole ballgame on Kubernetes: CWD-relative
    paths land in the container filesystem, which is destroyed along with the
    pod, so every PDF and every Chroma row written before a failover would be
    lost. On a laptop STATE_DIR *is* the CWD, so behaviour is unchanged.
    """
    raw = os.getenv(env_var, "").strip()
    if not raw:
        return STATE_DIR / default_name
    candidate = Path(raw).expanduser()
    return candidate if candidate.is_absolute() else STATE_DIR / candidate


REGISTRY_DIR = Path(os.getenv("ARCHIVIST_REGISTRY_DIR", BASE_DIR / "registry"))
DATA_DIR     = _state_path("ARCHIVIST_DATA_DIR",   "data")
OUTPUT_DIR   = _state_path("ARCHIVIST_OUTPUT_DIR", "output")

# Phase 7 — Dual-store persistence
DB_DIR     = _state_path("ARCHIVIST_DB_DIR",     "db")
CHROMA_DIR = _state_path("ARCHIVIST_CHROMA_DIR", "chroma")

# ── Durable checkpointing (required for resume-after-failover) ────────────────
# MemorySaver dies with the pod. SqliteSaver on the shared volume lets the
# replacement pod in the other vcluster pick up the same LangGraph thread.
DURABLE_CHECKPOINTS = os.getenv("ARCHIVIST_DURABLE_CHECKPOINTS", "true").lower() == "true"
CHECKPOINT_DB_PATH  = _state_path("ARCHIVIST_CHECKPOINT_DB", "checkpoints/langgraph.sqlite")
# LangGraph 1.x defaults stream(durability=...) to "async": checkpoint writes are
# handed to a background thread, so a pod killed mid-recipe loses the steps it had
# already finished and the replacement replays them from node 0. "sync" commits
# each superstep before the next one starts — that is what makes resume real.
CHECKPOINT_DURABILITY = os.getenv("ARCHIVIST_CHECKPOINT_DURABILITY", "sync")
# Deterministic thread ids: hash the file's basename (true) or its full path
# (false). Basename is right when the same corpus is mounted at different paths
# in the two tenants.
THREAD_ID_FROM_BASENAME = os.getenv("ARCHIVIST_THREAD_ID_FROM_BASENAME", "true").lower() == "true"

# Append-only record of completed recipes, so a batch resumes rather than
# restarting after the agent moves tenants.
MANIFEST_PATH = _state_path("ARCHIVIST_MANIFEST", "output/manifest.jsonl")

# ── State plane (INSTALL.md Part 7b) ──────────────────────────────────────────
# Three INDEPENDENT switches, one per backing service, each defaulting to the
# single-node behaviour so laptop runs and the SQLite demo are unchanged:
#
#   ARCHIVIST_STATE_BACKEND   sqlite | postgres      checkpoints, manifest, recipes
#   ARCHIVIST_CHROMA_MODE     persistent | server    vector store
#   ARCHIVIST_BLOB_STORE      local | s3             generated PDFs
#
# Separate on purpose. On a single node only Postgres actually buys anything —
# real fencing, replacing an ordering discipline nothing enforces — so you can
# adopt it without also standing up MinIO. On two nodes you need all three.
STATE_BACKEND = os.getenv("ARCHIVIST_STATE_BACKEND", "sqlite").strip().lower()
CHROMA_MODE   = os.getenv("ARCHIVIST_CHROMA_MODE",   "persistent").strip().lower()
BLOB_STORE    = os.getenv("ARCHIVIST_BLOB_STORE",    "local").strip().lower()

USE_POSTGRES      = STATE_BACKEND == "postgres"
USE_CHROMA_SERVER = CHROMA_MODE   == "server"
USE_S3            = BLOB_STORE    == "s3"

# ── Postgres ──────────────────────────────────────────────────────────────────
# Same precedence idiom as the vLLM endpoints below: an explicit whole DSN wins,
# otherwise one is assembled from parts. Parts are friendlier with Kubernetes
# Secrets, which inject one key at a time.
PG_HOST     = os.getenv("ARCHIVIST_PG_HOST", "localhost")
PG_PORT     = int(os.getenv("ARCHIVIST_PG_PORT", "5432"))
PG_USER     = os.getenv("ARCHIVIST_PG_USER", "archivist")
PG_PASSWORD = os.getenv("ARCHIVIST_PG_PASSWORD", "")
PG_DB       = os.getenv("ARCHIVIST_PG_DB", "archivist")
# Bounds how long a partitioned pod's advisory lock survives; pairs with the
# tcp_keepalives_* settings on the server (k8s/state-plane.yaml).
PG_POOL_MAX = int(os.getenv("ARCHIVIST_PG_POOL_MAX", "10"))

# ── Fencing ───────────────────────────────────────────────────────────────────
# How long a starting agent waits for a predecessor's advisory lock to be
# released before giving up.
#
# This exists because of how the demo actually kills the old pod. `kubectl delete
# pod --force` severs the TCP connection without a FIN, so Postgres only reaps
# the dead session via keepalives — idle 30s + 3x10s in k8s/state-plane.yaml, so
# up to ~60s. SkyPilot can relaunch into the other tenant faster than that. A
# replacement that refused the lock on first try would exit 1, and exit 1 is not
# in `job_recovery.recover_on_exit_codes`, so the job would go FAILED mid-demo.
#
# 120s is double the keepalive window. Shortening the keepalives instead would
# be worse: it makes false-positive lock steals more likely, and stealing a lease
# from a live agent is the one failure this is here to prevent.
LEASE_WAIT_SECONDS = int(os.getenv("ARCHIVIST_LEASE_WAIT_SECONDS", "120"))
LEASE_POLL_SECONDS = int(os.getenv("ARCHIVIST_LEASE_POLL_SECONDS", "5"))

# A recipe claimed but never finished is reclaimable after this long — the pod
# that claimed it died. Must exceed the slowest single recipe, or a live agent's
# work gets stolen from under it.
CLAIM_STALE_MINUTES = int(os.getenv("ARCHIVIST_CLAIM_STALE_MINUTES", "10"))


def _build_pg_dsn() -> str:
    explicit = os.getenv("ARCHIVIST_PG_DSN", "").strip()
    if explicit:
        return explicit
    # Percent-encode: the gate script generates alphanumeric passwords, but a
    # hand-set one containing @ / : would otherwise corrupt the URI.
    auth = quote(PG_USER, safe="")
    if PG_PASSWORD:
        auth += ":" + quote(PG_PASSWORD, safe="")
    return f"postgresql://{auth}@{PG_HOST}:{PG_PORT}/{PG_DB}"


PG_DSN = _build_pg_dsn()


def redact_dsn(dsn: str) -> str:
    """
    Strip the password out of a DSN for logging.

    identity.print_banner() logs its whole snapshot, and `sky jobs logs` ships
    that off the box — so the raw DSN must never reach it.
    """
    if not dsn:
        return ""
    if "://" in dsn:
        parts = urlsplit(dsn)
        if parts.password:
            host = parts.hostname or ""
            if parts.port:
                host = f"{host}:{parts.port}"
            netloc = f"{parts.username or ''}:***@{host}"
            return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))
        return dsn
    # libpq keyword form: host=... password=...
    return re.sub(r"(password\s*=\s*)(\S+)", r"\1***", dsn)


PG_DSN_SAFE = redact_dsn(PG_DSN)

# ── Chroma (server mode) ──────────────────────────────────────────────────────
# ⚠️ The chromadb CLIENT pin in requirements.txt and the chromadb/chroma SERVER
#    image tag in k8s/state-plane.yaml must move together — a 1.x client cannot
#    talk to a 0.5.x server.
CHROMA_HOST = os.getenv("ARCHIVIST_CHROMA_HOST", "localhost")
CHROMA_PORT = int(os.getenv("ARCHIVIST_CHROMA_PORT", "8000"))
CHROMA_SSL  = os.getenv("ARCHIVIST_CHROMA_SSL", "false").lower() == "true"

# Where embeddings come from: "vllm" (the embed server) or "local" (Chroma's
# built-in ONNX all-MiniLM-L6-v2, on CPU).
#
# "local" exists because BAAI/bge-m3 is an ENCODER model and vLLM's V1 ROCm
# attention backend raises:
#     NotImplementedError: Encoder self-attention is not implemented for
#     RocmAttentionImpl
# No flag on that pod fixes it — the model family is unsupported on this
# backend. CPU embeddings cost nothing here (160 vCPU, a handful of recipes)
# and free one GPU per tenant.
#
# ⚠️ The two produce different dimensions (bge-m3 1024, MiniLM 384). Do not
# switch against a collection that already holds vectors — reindex instead.
EMBED_BACKEND = os.getenv("ARCHIVIST_EMBED_BACKEND", "vllm").strip().lower()
USE_LOCAL_EMBEDDINGS = EMBED_BACKEND == "local"

# ── S3 / MinIO (generated PDFs) ───────────────────────────────────────────────
S3_ENDPOINT   = os.getenv("ARCHIVIST_S3_ENDPOINT", "")
S3_BUCKET     = os.getenv("ARCHIVIST_S3_BUCKET", "archivist")
S3_ACCESS_KEY = os.getenv("ARCHIVIST_S3_ACCESS_KEY", "")
S3_SECRET_KEY = os.getenv("ARCHIVIST_S3_SECRET_KEY", "")
# MinIO ignores the region, but boto3 refuses to build a client without one.
S3_REGION     = os.getenv("ARCHIVIST_S3_REGION", "us-east-1")

_VALID = {"ARCHIVIST_STATE_BACKEND": ("sqlite", "postgres"),
          "ARCHIVIST_CHROMA_MODE":   ("persistent", "server"),
          "ARCHIVIST_BLOB_STORE":    ("local", "s3")}


def validate_state_config() -> list[str]:
    """
    Hard configuration errors, returned rather than raised so the caller decides.

    Fail fast and loudly: a half-configured backend otherwise surfaces as a
    connection error deep inside the first recipe, which during a demo looks
    like a bug in the agent.
    """
    problems = []
    for var, allowed in _VALID.items():
        got = {"ARCHIVIST_STATE_BACKEND": STATE_BACKEND,
               "ARCHIVIST_CHROMA_MODE":   CHROMA_MODE,
               "ARCHIVIST_BLOB_STORE":    BLOB_STORE}[var]
        if got not in allowed:
            problems.append(f"{var}={got!r} — expected one of {' | '.join(allowed)}")

    if USE_POSTGRES and not os.getenv("ARCHIVIST_PG_DSN", "").strip() and not PG_PASSWORD:
        problems.append(
            "ARCHIVIST_STATE_BACKEND=postgres but neither ARCHIVIST_PG_DSN nor "
            "ARCHIVIST_PG_PASSWORD is set — run ./k8s/state-plane-gate.sh and use "
            "the settings it prints")

    if USE_S3:
        missing = [n for n, v in (("ARCHIVIST_S3_ENDPOINT",   S3_ENDPOINT),
                                  ("ARCHIVIST_S3_ACCESS_KEY", S3_ACCESS_KEY),
                                  ("ARCHIVIST_S3_SECRET_KEY", S3_SECRET_KEY)) if not v]
        if missing:
            problems.append(f"ARCHIVIST_BLOB_STORE=s3 but unset: {', '.join(missing)}")

    return problems


# ── Headless operation ────────────────────────────────────────────────────────
# There is no stdin in a pod. The stock CLI called input() and relied on the
# EOFError handler silently picking the first option — accidental behaviour.
# Set this true to make auto-accept explicit and intentional.
NONINTERACTIVE = os.getenv("ARCHIVIST_NONINTERACTIVE", "false").lower() == "true"

# ── Demo failover trigger ─────────────────────────────────────────────────────
# Exit with FAILOVER_EXIT_CODE after N completed recipes. Paired with
# `job_recovery.recover_on_exit_codes` in archivist.sky.yaml, this gives a
# deterministic, repeatable A->B move that never touches GPU teardown — the
# path implicated in the MI300X VF host crashes.
_fail_after         = os.getenv("ARCHIVIST_FAIL_AFTER", "").strip()
FAIL_AFTER          = int(_fail_after) if _fail_after.isdigit() else 0
FAILOVER_EXIT_CODE  = int(os.getenv("ARCHIVIST_FAILOVER_EXIT_CODE", "42"))

# Duplicate detection — cosine distance below this triggers a human review prompt.
DUPLICATE_SIMILARITY_THRESHOLD = float(os.getenv("DUPLICATE_SIMILARITY_THRESHOLD", "0.40"))

# LLM backend — "vllm" (direct) or "ray_serve" (via gateway)
LLM_BACKEND = os.getenv("LLM_BACKEND", "vllm")

# ── Ray Serve gateway ─────────────────────────────────────────────────────────
# Used when LLM_BACKEND=ray_serve.  Start the gateway with:
#   python -m ray_serve.serve_app
RAY_SERVE_BASE_URL   = os.getenv("RAY_SERVE_BASE_URL", "http://localhost:8080")
RAY_SERVE_PORT       = int(os.getenv("RAY_SERVE_PORT",       "8080"))
RAY_SERVE_HOST       = os.getenv("RAY_SERVE_HOST",           "0.0.0.0")
RAY_DASHBOARD_PORT   = int(os.getenv("RAY_DASHBOARD_PORT",   "8265"))
RAY_METRICS_PORT     = int(os.getenv("RAY_METRICS_PORT",     "9090"))

# ── vLLM settings (AMD MI350X) ────────────────────────────────────────────────
# Text, vision, and embedding models each run on their own vllm serve process / port.
# A pod in team-b has no localhost vLLM, so these default to in-cluster service
# DNS. VLLM_HOST is the one knob to turn: each vcluster injects its own value,
# and the agent repoints itself when it lands there. Override any single URL
# outright if a model lives somewhere else.
VLLM_HOST = os.getenv("VLLM_HOST", "localhost")

VLLM_TEXT_BASE_URL   = os.getenv("VLLM_TEXT_BASE_URL",   f"http://{VLLM_HOST}:8000/v1")
VLLM_VISION_BASE_URL = os.getenv("VLLM_VISION_BASE_URL", f"http://{VLLM_HOST}:8001/v1")
VLLM_EMBED_BASE_URL  = os.getenv("VLLM_EMBED_BASE_URL",  f"http://{VLLM_HOST}:8002/v1")
VLLM_OCR_BASE_URL    = os.getenv("VLLM_OCR_BASE_URL",    f"http://{VLLM_HOST}:8003/v1")

# Prometheus scrape base for the benchmark harness (vLLM /metrics lives on the
# model servers, which do NOT move with the agent).
VLLM_METRICS_HOST = os.getenv("VLLM_METRICS_HOST", VLLM_HOST)
VLLM_API_KEY         = os.getenv("VLLM_API_KEY",         "EMPTY")

#VLLM_TEXT_MODEL      = os.getenv("VLLM_TEXT_MODEL",      "Qwen/Qwen2.5-32B-Instruct")
VLLM_TEXT_MODEL      = os.getenv("VLLM_TEXT_MODEL",      "Qwen/Qwen2.5-72B-Instruct")    # FP8  ~72 GB  util 0.67
VLLM_VISION_MODEL    = os.getenv("VLLM_VISION_MODEL",    "Qwen/Qwen2.5-VL-7B-Instruct")  # BF16 ~14 GB  util 0.12
# Only used when ARCHIVIST_EMBED_BACKEND=vllm. On ROCm that server cannot start
# (encoder self-attention unimplemented), so the default path is "local":
# Chroma's bundled all-MiniLM-L6-v2 ONNX on CPU, 384-dim.
VLLM_EMBED_MODEL     = os.getenv("VLLM_EMBED_MODEL",     "BAAI/bge-m3")
VLLM_OCR_MODEL       = os.getenv("VLLM_OCR_MODEL",       "stepfun-ai/GOT-OCR2_0")         # BF16 ~1.2 GB util 0.01
VLLM_TIMEOUT         = int(os.getenv("VLLM_TIMEOUT",     "120"))

# Set true to use GOT-OCR 2.0 (port 8003) for Step 1 of image transcription.
# Recommended for handwritten recipes — outperforms the general vision model on text extraction.
# Falls back to VLLM_VISION_MODEL if GOT-OCR server is unreachable.
USE_GOT_OCR = os.getenv("USE_GOT_OCR", "false").lower() == "true"

# Extract food image from recipe if present and include in PDF output
EXTRACT_FOOD_IMAGE = os.getenv("EXTRACT_FOOD_IMAGE", "false").lower() == "true"

# ── Disabled backends (kept for reference only) ───────────────────────────────
# Ollama (local)
# OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
# VISION_MODEL    = os.getenv("VISION_MODEL", "llama3.2-vision:11b")
# TEXT_MODEL      = os.getenv("TEXT_MODEL", "mistral:7b-instruct")
# EMBED_MODEL     = os.getenv("EMBED_MODEL", "nomic-embed-text")
# _timeout_env    = os.getenv("OLLAMA_TIMEOUT", "")
# OLLAMA_TIMEOUT  = int(_timeout_env) if _timeout_env.strip() else None

# Anthropic Claude (cloud)
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_TEXT_MODEL   = os.getenv("CLAUDE_TEXT_MODEL", "claude-opus-4-1")
CLAUDE_VISION_MODEL = os.getenv("CLAUDE_VISION_MODEL", "claude-3-5-sonnet-20241022")

# Pre-flight auto-detect thresholds
AUTO_EXPRESS_QUALITY_THRESHOLD = 0.85
AUTO_EXPRESS_MAX_AGE_YEARS = 2

# Express path
EXPRESS_HITL_TIMEOUT_SECONDS = 60

# Phase 4 — Full path thresholds
FULL_PATH_QUALITY_THRESHOLD   = 0.5
FULL_PATH_MAX_RESTORER_LOOPS  = 3
FULL_PATH_MAX_HISTORIAN_LOOPS = 2
HYBRID_SCORE_MARGIN           = 0.15

# Phase 5 — Historian ReAct loop
HISTORIAN_MAX_REACT_STEPS = int(os.getenv("HISTORIAN_MAX_REACT_STEPS", "4"))

# Phase 6 — Discovery Subagent
DISCOVERY_ENABLED = os.getenv("DISCOVERY_ENABLED", "false").lower() == "true"
DISCOVERY_UNKNOWN_SCORE_THRESHOLD = float(os.getenv("DISCOVERY_UNKNOWN_SCORE_THRESHOLD", "0.15"))
DISCOVERY_ORPHAN_RATIO_THRESHOLD  = float(os.getenv("DISCOVERY_ORPHAN_RATIO_THRESHOLD", "0.25"))

# OCR strategy: True = PyMuPDF + Tesseract (fast, local, default)
#               False = vision LLM via vLLM
USE_PYMUPDF = os.getenv("USE_PYMUPDF", "true").lower() == "true"
TESSDATA_PREFIX = os.getenv("TESSDATA_PREFIX", "/usr/share/tesseract-ocr/5/tessdata")

# ── Ingredient Sourcer ────────────────────────────────────────────────────────
# Google Places New API key (enable "Places API (New)" + "Geocoding API" in GCP)
GOOGLE_PLACES_API_KEY = os.getenv("GOOGLE_PLACES_API_KEY", "")

# Foursquare Places API key (free tier: 1000 calls/day)
FOURSQUARE_API_KEY = os.getenv("FOURSQUARE_API_KEY", "")

# Search radius for local store lookup (metres)
SOURCER_RADIUS_METERS = int(os.getenv("SOURCER_RADIUS_METERS", "8000"))

# Override city/region used for store searches.
# If empty, the node derives it from origin_consensus or user_region_hint.
# Example: "Austin, TX"  or  "London, UK"
SOURCER_LOCATION = os.getenv("SOURCER_LOCATION", "")

# Max specialty ingredients to run per-ingredient store searches for.
# Keeps API call count bounded (each adds ~2 searchText calls).
SOURCER_MAX_SPECIALTY_INGREDIENTS = int(os.getenv("SOURCER_MAX_SPECIALTY_INGREDIENTS", "5"))

# Set to "false" to skip the ingredient sourcer node entirely (e.g. offline runs)
SOURCER_ENABLED = os.getenv("SOURCER_ENABLED", "true").lower() == "true"

# Create only the directories the SELECTED backends actually use.
#
# In the full Part 7b layout the agent needs no shared filesystem at all — that
# is the point of it — so demanding a writable STATE_DIR at import time would
# break exactly the topology the state plane exists to enable.
#
# Failures warn instead of raising: an unwritable output directory should
# surface where something tries to write, not as an import error with no
# context attached.
_needed = []
if not USE_S3:
    _needed.append(OUTPUT_DIR)
if not USE_POSTGRES:
    _needed += [DB_DIR, CHECKPOINT_DB_PATH.parent, MANIFEST_PATH.parent]
if not USE_CHROMA_SERVER:
    _needed.append(CHROMA_DIR)

for _d in _needed:
    try:
        _d.mkdir(parents=True, exist_ok=True)
    except OSError as _e:                                   # noqa: PERF203
        import logging as _logging
        _logging.getLogger(__name__).warning("could not create %s: %s", _d, _e)
