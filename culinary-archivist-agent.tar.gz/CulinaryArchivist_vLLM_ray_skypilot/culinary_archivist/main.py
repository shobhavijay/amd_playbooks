"""
CLI entry point — runs the Culinary Archivist pipeline without Chainlit.

Usage:
    # Single file:
    python -m culinary_archivist.main --media /path/to/recipe.jpg
    python -m culinary_archivist.main --media /path/to/recipe.pdf --mode full
    python -m culinary_archivist.main --media /path/to/recipe.jpg --region SOUTH_INDIAN

    # Batch — process all JPEGs in a directory:
    python -m culinary_archivist.main --media /path/to/recipes/

    # via pyproject.toml script entry point:
    archivist --media /path/to/recipe.jpg
    archivist --media /path/to/recipes/

HITL nodes (express_hitl, full_hitl, indexer duplicate check) are
auto-accepted in CLI mode — the agent's suggestions are used verbatim.
All interrupt payloads are printed to stdout so you can see what the
Chainlit UI would have shown the human.
"""
import argparse
import json
import logging
import sys
from pathlib import Path

from langgraph.types import Command

from culinary_archivist import config as cfg
from culinary_archivist import identity
from culinary_archivist.checkpointer import get_checkpointer, thread_id_for
from culinary_archivist.graph import build_graph
from culinary_archivist.manifest import get_manifest

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s — %(message)s")
log = logging.getLogger(__name__)

_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}

# Upper bound on how many times we re-enter the graph for one recipe. A graph
# that keeps yielding without ever clearing `next` would otherwise spin forever
# inside a pod with no stdin and nobody watching.
_MAX_DRIVE_STEPS = 50


def _prompt_choice(prompt: str, options: list[str]) -> str:
    """
    Print a prompt and loop until the user enters a valid option.
    Case-insensitive. Returns the matched option string.
    """
    options_lower = [o.lower() for o in options]

    # No stdin in a pod. Auto-accepting is the right behaviour there, but it has
    # to be an explicit choice — the original code reached the same outcome by
    # catching EOFError, which hid the decision.
    if cfg.NONINTERACTIVE:
        print(f"{prompt}\n→ ARCHIVIST_NONINTERACTIVE=true — auto-selecting: {options[0]}")
        return options[0]

    while True:
        try:
            raw = input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n→ Interrupted — using default:", options[0])
            return options[0]
        if raw in options_lower:
            return raw
        print(f"  Please enter one of: {', '.join(options)}")


def _auto_resume(interrupt_payload: dict) -> dict:
    """
    Print the interrupt payload and prompt the user for input via CLI.
    Called for every interrupt() the graph raises — replaces Chainlit UI input.
    """
    itype = interrupt_payload.get("type", "unknown")
    print("\n" + "─" * 60)
    print(f"[HITL — {itype}]")

    # ── Duplicate detection ───────────────────────────────────────────────────
    if itype == "duplicate_check":
        new  = interrupt_payload.get("new_recipe", {})
        exist = interrupt_payload.get("existing_recipe", {})
        sim  = interrupt_payload.get("similarity", 0)

        print(f"\n  ⚠ Possible duplicate detected ({sim:.1f}% similar)\n")
        print(f"  NEW RECIPE:      {new.get('title', '?')}  |  {new.get('region', '?')}  |  {new.get('era', '?')}")
        print(f"  EXISTING RECIPE: {exist.get('title', '?')}  |  {exist.get('region', '?')}  |  archived {exist.get('archived_at', '?')[:10]}")
        print(f"\n  New ingredients (preview):      {new.get('ingredients', [])[:3]}")
        print(f"  Existing ingredients (preview): {exist.get('ingredients', [])[:3]}")
        print()
        choice = _prompt_choice(
            "  → Action [index=keep both / replace=overwrite existing / skip=discard new]: ",
            ["index", "replace", "skip"],
        )
        print("─" * 60)
        return {"action": choice}

    # ── Express HITL ──────────────────────────────────────────────────────────
    if itype == "express_hitl_form":
        suggestions = interrupt_payload.get("suggestions", {})
        print("\n  Agent suggestions:")
        print(json.dumps(suggestions, indent=4, default=str))
        print()
        choice = _prompt_choice(
            "  → Accept agent suggestions? [yes / no]: ",
            ["yes", "no"],
        )
        print("─" * 60)
        return {"accepted": choice == "yes"}

    # ── Full HITL ─────────────────────────────────────────────────────────────
    if itype == "full_hitl_form":
        output = interrupt_payload.get("historian_output", {})
        print("\n  Historian output:")
        for k, v in output.items():
            if v:
                print(f"    {k}: {v}")
        print()
        choice = _prompt_choice(
            "  → Accept historian output? [yes / no]: ",
            ["yes", "no"],
        )
        print("─" * 60)
        return {"accepted": choice == "yes"}

    # ── Unknown interrupt — show payload and auto-accept ──────────────────────
    print(json.dumps(interrupt_payload, indent=2, default=str))
    print("→ Unknown interrupt type — auto-accepting")
    print("─" * 60)
    return {"accepted": True}


def _run_single(media_path: str, mode: str, region: str, graph, index: int = 0, total: int = 1) -> dict:
    """
    Run the pipeline on one file. Returns the final state dict.

    The thread id is derived from the file, not random, so a pod relaunched in
    the other vcluster resumes this exact thread instead of starting a new one.
    """
    media_type = "image" if Path(media_path).suffix.lower() in _IMAGE_EXTENSIONS else "pdf"

    initial_state = {
        "media_path":            media_path,
        "media_type":            media_type,
        "mode":                  mode,
        "user_region_hint":      region,
        "media_quality_score":   0.0,
        "media_date_detected":   0,
        "llm_calls":             0,
        "tool_calls":            0,
        "total_loop_iterations": 0,
        "hitl_escalations":      0,
        "errors":                [],
    }

    tid    = thread_id_for(media_path)
    config = {"configurable": {"thread_id": tid}}
    prefix = f"[{index + 1}/{total}] " if total > 1 else ""

    print(f"\n{prefix}Running archivist on: {media_path}  (mode={mode or 'auto'})")
    print(f"{prefix}tenant={cfg.TENANT_NAME}  thread_id={tid}")
    print("=" * 60)

    # A checkpoint that already has `next` set means a previous pod — very
    # possibly in the other tenant — died mid-recipe. Resume it rather than
    # replaying nodes that already burned GPU time.
    existing = graph.get_state(config)
    resumed  = bool(existing.next)
    if resumed:
        print(f"{prefix}↻ RESUMING from checkpoint — next node(s): {list(existing.next)}")
    else:
        for event in graph.stream(initial_state, config=config, stream_mode="values",
                                  durability=cfg.CHECKPOINT_DURABILITY):
            _print_progress(event)

    # Drive the thread to completion. Two different things leave work pending:
    # an interrupt waiting on a human answer, which needs Command(resume=...),
    # and a pod killed mid-node, which needs None — LangGraph's idiom for "pick
    # up the pending tasks". Breaking out when there is no interrupt reported the
    # recipe DONE with nodes still unrun, and the batch loop then wrote
    # status="ok" for work that never happened.
    for _ in range(_MAX_DRIVE_STEPS):
        state = graph.get_state(config)
        if not state.next:
            break
        interrupts = []
        for task in state.tasks:
            interrupts.extend(task.interrupts)
        nxt = Command(resume=_auto_resume(interrupts[0].value)) if interrupts else None
        progressed = False
        for event in graph.stream(nxt, config=config, stream_mode="values",
                                  durability=cfg.CHECKPOINT_DURABILITY):
            _print_progress(event)
            progressed = True
        if not progressed:
            break   # nothing advanced — fall through to the guard rather than spin

    # A false "ok" is unrecoverable: the manifest IS the resume ledger, so a
    # recipe recorded as done is never retried by any later attempt. Raise
    # instead, and let the batch loop record status="error".
    pending = graph.get_state(config).next
    if pending:
        raise RuntimeError(
            f"pipeline did not complete on tenant={cfg.TENANT_NAME} — "
            f"still pending: {list(pending)}"
        )

    final = graph.get_state(config).values
    print("\n" + "=" * 60)
    print(f"{prefix}DONE on tenant={cfg.TENANT_NAME} — final state:")
    for key in ("mode", "pdf_path", "indexed", "duplicate_flag",
                "final_origin", "llm_calls", "tool_calls", "errors"):
        print(f"  {key}: {final.get(key)}")

    sources = final.get("ingredient_sources") or {}
    if sources:
        generic_count   = len((sources.get("generic") or {}).get("ingredients") or [])
        specialty_count = len(sources.get("specialty") or {})
        local_count     = len((sources.get("generic") or {}).get("local_stores") or [])
        print(f"  sourcer_location:  {sources.get('user_location', '—')}")
        print(f"  generic_ingredients:  {generic_count}  |  specialty_ingredients: {specialty_count}")
        print(f"  local_stores_found:   {local_count}")
    else:
        print("  ingredient_sourcer: disabled or no ingredients found")

    return final


class _FailoverRequested(Exception):
    """Raised by the --fail-after trigger; caught in main() to exit cleanly."""


def main():
    parser = argparse.ArgumentParser(description="Culinary Archivist — CLI runner")
    parser.add_argument("--media",   required=True,
                        help="Path to a recipe image/PDF, or a directory of JPEGs for batch mode")
    parser.add_argument("--mode",    choices=["express", "full"], default="",
                        help="Force express or full path (default: auto-detect)")
    parser.add_argument("--region",  default="",
                        help="Optional region hint (e.g. SOUTH_INDIAN)")
    parser.add_argument("--fail-after", type=int, default=None, metavar="N",
                        help=(f"Demo failover trigger: exit with code "
                              f"{cfg.FAILOVER_EXIT_CODE} after N recipes complete. "
                              "Overrides ARCHIVIST_FAIL_AFTER."))
    parser.add_argument("--no-resume", action="store_true",
                        help="Ignore the done-manifest and reprocess every file")
    args = parser.parse_args()

    # Print WHERE we are before doing anything. Read this banner before and
    # after the failover — the TENANT / POD / NODE lines are the proof.
    identity.print_banner(role="agent (CLI)")

    fail_after = args.fail_after if args.fail_after is not None else cfg.FAIL_AFTER

    # Durable checkpointer: survives the pod, so the replacement in the other
    # vcluster resumes instead of restarting. Falls back to MemorySaver loudly.
    checkpointer = get_checkpointer()
    graph = build_graph().compile(checkpointer=checkpointer)

    media_path = Path(args.media)

    if media_path.is_dir():
        # ── Batch mode ────────────────────────────────────────────
        files = sorted(
            p for p in media_path.iterdir()
            if p.is_file()
            and p.suffix.lower() in _IMAGE_EXTENSIONS
            and not p.name.startswith("._")  # skip macOS metadata files
        )
        if not files:
            print(f"No JPEG/PNG files found in: {media_path}")
            return

        manifest = get_manifest()

        # Fencing guard one: one agent per run_id. On the file backend this is a
        # no-op — it cannot fence — and safety rests on the block-then-kill
        # ordering instead. On Postgres it is an advisory lock, and the wait
        # exists because a force-deleted pod's session lingers until keepalives
        # reap it (config.LEASE_WAIT_SECONDS).
        if not manifest.acquire_run_lease():
            print("\n" + "!" * 60)
            print(f"  Another agent still owns run_id={cfg.RUN_ID}.")
            print("  Refusing to start: two agents on one run corrupt its state.")
            print("  Exiting 1 — deliberately NOT 42, so this is not mistaken")
            print("  for a failover and retried into the same collision.")
            print("!" * 60 + "\n", flush=True)
            sys.exit(1)

        pending = files if args.no_resume else [f for f in files if not manifest.is_done(f)]
        skipped = len(files) - len(pending)

        print(f"\nBatch mode: {len(files)} file(s) found in {media_path}")
        if skipped:
            print(f"  ↻ {skipped} already completed in a previous attempt — skipping "
                  f"(manifest: {cfg.MANIFEST_PATH})")
        print(f"  → {len(pending)} to process on tenant={cfg.TENANT_NAME}")

        failed = []
        completed_here = 0
        for i, f in enumerate(pending):
            # is_done() above produced the count for the banner; claim() is what
            # actually decides. It is atomic, so even inside the window where a
            # dead pod still holds the lease, two agents cannot take the same
            # recipe.
            if not manifest.claim(f, force=args.no_resume):
                print(f"  [{i + 1}/{len(pending)}] {f.name}: "
                      f"claimed by another agent — skipping")
                continue
            try:
                final = _run_single(str(f), args.mode, args.region, graph,
                                    index=i, total=len(pending))
                manifest.mark(f, status="ok", pdf_path=str(final.get("pdf_path") or ""))
                completed_here += 1
            except Exception as e:
                log.error("Failed to process %s: %s", f.name, e)
                manifest.mark(f, status="error", error=str(e))
                failed.append((f.name, str(e)))

            # ── Deterministic failover trigger ───────────────────────────────
            # Exits AFTER the manifest write, so the replacement pod in the
            # other tenant resumes at exactly the next unfinished recipe.
            if fail_after and completed_here >= fail_after:
                print("\n" + "!" * 60)
                print(f"  --fail-after {fail_after} reached on tenant={cfg.TENANT_NAME}")
                print(f"  {manifest.completed}/{len(files)} recipes done and checkpointed.")
                print(f"  Exiting {cfg.FAILOVER_EXIT_CODE} — SkyPilot should relaunch "
                      "this job in the other vcluster.")
                print("!" * 60 + "\n", flush=True)
                # Hand the lease back before exiting so the replacement in the
                # other tenant does not have to wait out the keepalive window.
                manifest.release_run_lease()
                sys.exit(cfg.FAILOVER_EXIT_CODE)

        manifest.release_run_lease()

        print("\n" + "=" * 60)
        print(f"Batch complete on tenant={cfg.TENANT_NAME}: "
              f"{len(pending) - len(failed)}/{len(pending)} succeeded this attempt "
              f"({manifest.completed}/{len(files)} overall)")
        if failed:
            print("Failed files:")
            for name, err in failed:
                print(f"  ✗ {name}: {err}")
    else:
        # ── Single file mode ──────────────────────────────────────
        _run_single(str(media_path), args.mode, args.region, graph)


def _print_progress(event: dict) -> None:
    """Print a one-line progress indicator as each node completes."""
    # event is the full state snapshot after each node — detect which
    # field was just written to infer which node just ran
    indicators = [
        ("express_transcription",  "✓ express_transcribe"),
        ("hitl_suggestions",       "✓ express_suggest"),
        ("express_hitl_metadata",  "✓ express_hitl"),
        ("repaired_transcription", "✓ restorer"),
        ("quality_score",          "✓ quality_evaluator"),
        ("historian_output",       "✓ historian"),
        ("origin_consensus",       "✓ cross_verifier"),
        ("full_hitl_metadata",     "✓ full_hitl"),
        ("ingredient_sources",     "✓ ingredient_sourcer"),
        ("pdf_path",               "✓ pdf_generator"),
        ("indexed",                "✓ indexer"),
    ]
    for key, label in indicators:
        if key in event and event[key] is not None:
            print(f"  {label}")
            break


if __name__ == "__main__":
    main()
