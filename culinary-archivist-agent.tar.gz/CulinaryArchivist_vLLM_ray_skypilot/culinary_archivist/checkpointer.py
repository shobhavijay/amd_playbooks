"""
Durable LangGraph checkpointer.

Why this exists
---------------
The stock code compiles the graph with `MemorySaver()`, which lives in the
process heap. When SkyPilot kills the agent pod in team-a and relaunches it in
team-b, that heap is gone — every in-flight recipe restarts from node 0. The
demo then shows a *restart*, not a *move*.

Pointing the checkpointer at a SQLite file on the shared volume makes the new
pod in team-b resume the exact LangGraph thread the old pod was executing, so
the recipe continues from the last completed node.

Safety note
-----------
SQLite on a shared volume tolerates exactly one writer. That holds here only
because the proven failover trigger blocks the victim namespace *before* the
replacement starts (see DEMO.md) — the old pod is dead before the new one
opens the file. Two live agent pods on one checkpoint DB will corrupt it.

Set ARCHIVIST_DURABLE_CHECKPOINTS=false to fall back to MemorySaver (useful for
laptop smoke-tests where you don't want a stateful file lying around).
"""
import logging
import sqlite3

from culinary_archivist import config

log = logging.getLogger(__name__)

_saver = None


def get_checkpointer():
    """
    Return a process-wide checkpointer.

    PostgresSaver when ARCHIVIST_STATE_BACKEND=postgres; SqliteSaver when durable
    checkpointing is on and the driver is importable; MemorySaver otherwise.
    Falls back loudly, never silently — and the Postgres path does not fall back
    at all, it raises.
    """
    global _saver
    if _saver is not None:
        return _saver

    if not config.DURABLE_CHECKPOINTS:
        from langgraph.checkpoint.memory import MemorySaver
        log.info("Checkpointer: MemorySaver (ARCHIVIST_DURABLE_CHECKPOINTS=false)")
        _saver = MemorySaver()
        return _saver

    if config.USE_POSTGRES:
        _saver = _postgres_saver()
        return _saver

    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
    except ImportError:
        from langgraph.checkpoint.memory import MemorySaver
        log.warning(
            "langgraph-checkpoint-sqlite is not installed — falling back to MemorySaver. "
            "Failover will RESTART in-flight recipes instead of resuming them. "
            "Fix with: pip install langgraph-checkpoint-sqlite"
        )
        _saver = MemorySaver()
        return _saver

    path = config.CHECKPOINT_DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    # check_same_thread=False: LangGraph and Ray both touch the saver from
    # worker threads. WAL keeps readers from blocking the single writer.
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")

    _saver = SqliteSaver(conn)
    _saver.setup()
    log.info("Checkpointer: SqliteSaver at %s", path)
    return _saver


def _postgres_saver():
    """
    PostgresSaver over a connection pool (INSTALL.md Part 7b).

    A pool, not `PostgresSaver.from_conn_string()`: that helper is a context
    manager which closes the connection on exit, so it cannot back a saver held
    for the life of the process.

    The three connection kwargs are NOT optional and NOT stylistic — they are
    lifted from from_conn_string's own body, which is the library telling you
    what PostgresSaver requires. Omitting `autocommit` in particular produces
    errors that point nowhere near the cause.

    Failure here RAISES rather than falling back to SQLite. A silent fallback
    would be the worst possible outcome: the demo would appear to run while each
    tenant kept private checkpoints, so the "failover" would quietly be a
    restart — exactly the illusion this whole state plane exists to prevent.
    """
    from psycopg.rows import dict_row
    from psycopg_pool import ConnectionPool
    from langgraph.checkpoint.postgres import PostgresSaver

    pool = ConnectionPool(
        conninfo=config.PG_DSN,
        min_size=1,
        max_size=config.PG_POOL_MAX,
        open=True,
        kwargs={"autocommit": True, "prepare_threshold": 0, "row_factory": dict_row},
    )
    pool.wait(timeout=30)          # fail at startup, not inside the first recipe
    saver = PostgresSaver(pool)
    saver.setup()                  # idempotent; safe on every attempt
    log.info("Checkpointer: PostgresSaver at %s", config.PG_DSN_SAFE)
    return saver


def thread_id_for(media_path: str) -> str:
    """
    Deterministic thread id derived from the input file.

    The stock code used `uuid.uuid4()`, so a relaunched pod could never find the
    checkpoint written by its predecessor. Hashing the path means the same
    recipe always maps to the same thread — which is precisely what makes
    resume-after-failover work.
    """
    import hashlib
    from pathlib import Path

    key = Path(media_path).name if config.THREAD_ID_FROM_BASENAME else str(media_path)
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:32]
    return f"{config.RUN_ID}:{digest}"
