import base64
import io
import logging
from datetime import datetime
from pathlib import Path

from fpdf import FPDF
from PIL import Image

from culinary_archivist import config
from culinary_archivist.db import blob_store
from culinary_archivist.state import ArchivistState

log = logging.getLogger(__name__)


class _RecipePDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(150, 150, 150)
        self.cell(0, 8, "Culinary Archivist", align="R")
        self.ln(6)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "", 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")


_UNICODE_FRACTIONS_PDF = {
    "\u00bd": "1/2", "\u00bc": "1/4", "\u00be": "3/4",
    "\u2153": "1/3", "\u2154": "2/3",
    "\u215b": "1/8", "\u215c": "3/8", "\u215d": "5/8", "\u215e": "7/8",
    "\u2155": "1/5", "\u2156": "2/5", "\u2157": "3/5", "\u2158": "4/5",
    "\u2159": "1/6", "\u215a": "5/6",
}


def _safe(text) -> str:
    """Convert text to latin-1 safe string for fpdf2, normalising fraction glyphs first."""
    if not text:
        return ""
    s = str(text)
    for glyph, ascii_frac in _UNICODE_FRACTIONS_PDF.items():
        s = s.replace(glyph, ascii_frac)
    return s.encode("latin-1", errors="replace").decode("latin-1")


def _build_basic_pdf(transcription: dict, metadata: dict, food_image_b64: str | None = None) -> FPDF:
    pdf = _RecipePDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # Insert food image at the very beginning if present
    if food_image_b64:
        try:
            _insert_image_inline(pdf, food_image_b64)
            pdf.ln(4)
        except Exception as e:
            log.warning("Failed to insert food image: %s", e)

    title = metadata.get("title") or transcription.get("title") or "Untitled Recipe"

    # Title
    pdf.set_font("Helvetica", "B", 18)
    pdf.set_text_color(40, 40, 40)
    pdf.multi_cell(0, 10, _safe(title), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    # Metadata line
    parts = []
    if metadata.get("origin"):
        parts.append(metadata["origin"])
    if metadata.get("era"):
        parts.append(metadata["era"])
    if metadata.get("tags"):
        tags = metadata["tags"] if isinstance(metadata["tags"], list) else [metadata["tags"]]
        parts.append(", ".join(tags))
    if parts:
        pdf.set_font("Helvetica", "I", 10)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 6, _safe("  -  ".join(parts)), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
    else:
        pdf.ln(4)

    # Divider
    pdf.set_draw_color(200, 200, 200)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(6)

    # Ingredients
    ingredients = transcription.get("ingredients") or []
    steps = transcription.get("steps") or []
    source_text = transcription.get("source_text") or ""

    if ingredients:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Ingredients", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        for item in ingredients:
            pdf.multi_cell(0, 6, _safe(f"  - {item}"), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

    # Steps
    if steps:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Method", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        for i, step in enumerate(steps, 1):
            pdf.multi_cell(0, 6, _safe(f"{i}.  {step}"), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

    # Fallback: if structured parse failed, show raw transcription text
    if not ingredients and not steps and source_text:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Transcribed Text", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(60, 60, 60)
        pdf.multi_cell(0, 5, _safe(source_text), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

    # Notes
    if metadata.get("notes"):
        pdf.ln(4)
        pdf.set_font("Helvetica", "I", 10)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 6, _safe(f"Notes: {metadata['notes']}"), new_x="LMARGIN", new_y="NEXT")

    # Archived timestamp
    pdf.ln(6)
    pdf.set_font("Helvetica", "I", 8)
    pdf.set_text_color(180, 180, 180)
    pdf.multi_cell(0, 6, _safe(f"Archived: {datetime.now().strftime('%Y-%m-%d %H:%M')}"), new_x="LMARGIN", new_y="NEXT")

    return pdf


def _build_annotated_pdf(historian_output: dict, state: dict, food_image_b64: str | None = None) -> FPDF:
    """
    Full-path PDF: recipe content (verbatim) + historian annotations block.
    Uses historian_output for everything — ingredients/steps are already
    preserved verbatim by the historian's normalise step.
    """
    pdf = _RecipePDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # Insert food image at the very beginning if present
    if food_image_b64:
        try:
            _insert_image_inline(pdf, food_image_b64)
            pdf.ln(4)
        except Exception as e:
            log.warning("Failed to insert food image: %s", e)

    title = historian_output.get("title") or "Untitled Recipe"

    # Title
    pdf.set_font("Helvetica", "B", 18)
    pdf.set_text_color(40, 40, 40)
    pdf.multi_cell(0, 10, _safe(title), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    # Origin / era / tags line
    parts = []
    origin = historian_output.get("origin") or state.get("origin_consensus")
    if origin:
        parts.append(origin)
    if historian_output.get("sub_region"):
        parts.append(historian_output["sub_region"])
    if historian_output.get("era"):
        parts.append(historian_output["era"])
    tags = historian_output.get("tags") or []
    if tags:
        parts.append(", ".join(tags))
    if parts:
        pdf.set_font("Helvetica", "I", 10)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 6, _safe("  |  ".join(parts)), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
    else:
        pdf.ln(4)

    # Divider
    pdf.set_draw_color(200, 200, 200)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(6)

    # Ingredients
    ingredients = historian_output.get("ingredients") or []
    steps       = historian_output.get("steps") or []
    source_text = historian_output.get("source_text") or ""

    if ingredients:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Ingredients", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        for item in ingredients:
            pdf.multi_cell(0, 6, _safe(f"  - {item}"), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

    # Steps
    if steps:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Method", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        for i, step in enumerate(steps, 1):
            pdf.multi_cell(0, 6, _safe(f"{i}.  {step}"), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

    # Fallback raw text
    if not ingredients and not steps and source_text:
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, "Transcribed Text", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(60, 60, 60)
        pdf.multi_cell(0, 5, _safe(source_text), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

    # ── Historian Annotations ─────────────────────────────────────────────
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(60, 60, 100)
    pdf.multi_cell(0, 9, "Archivist Annotations", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(180, 180, 220)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(5)

    def _annotation_block(heading: str, body: str):
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(60, 60, 60)
        pdf.multi_cell(0, 7, _safe(heading), new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(80, 80, 80)
        pdf.multi_cell(0, 6, _safe(body), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    if historian_output.get("provenance"):
        _annotation_block("Provenance", historian_output["provenance"])

    if historian_output.get("technique_notes"):
        _annotation_block("Technique Notes", historian_output["technique_notes"])

    archaic = historian_output.get("archaic_substitutions") or {}
    if archaic:
        lines = "\n".join(f"  {k}: {v}" for k, v in archaic.items())
        _annotation_block("Archaic Terms Found in This Recipe", lines)

    vibe = historian_output.get("vibe_keywords") or []
    if vibe:
        _annotation_block("Character Keywords", "  " + "  |  ".join(vibe))

    # Cross-verifier conflict note
    conflict = state.get("conflict_note")
    if conflict:
        pdf.set_font("Helvetica", "I", 9)
        pdf.set_text_color(140, 80, 80)
        pdf.multi_cell(0, 6, _safe(f"Origin Note: {conflict}"), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    if historian_output.get("notes"):
        _annotation_block("Notes", historian_output["notes"])

    # Archived timestamp
    pdf.ln(4)
    pdf.set_font("Helvetica", "I", 8)
    pdf.set_text_color(180, 180, 180)
    pdf.multi_cell(0, 6, _safe(f"Archived: {datetime.now().strftime('%Y-%m-%d %H:%M')}"), new_x="LMARGIN", new_y="NEXT")

    return pdf


def _insert_image_inline(pdf: FPDF, food_image_b64: str) -> None:
    """Insert food image inline in the PDF at current cursor position."""
    if not food_image_b64:
        return

    try:
        # Decode base64 to image
        image_bytes = base64.b64decode(food_image_b64)
        img = Image.open(io.BytesIO(image_bytes))

        # Calculate dimensions to fit page width (with margins)
        page_width = pdf.w - 40  # 20mm margins on each side
        aspect_ratio = img.height / img.width
        img_height = page_width * aspect_ratio

        # If image is too tall, scale it down to max 120mm
        max_height = 120
        if img_height > max_height:
            img_height = max_height
            page_width = img_height / aspect_ratio

        # Save image to temp file (fpdf2 needs a file path)
        temp_path = "/tmp/food_image_temp.jpg"
        img.save(temp_path, "JPEG", quality=95)

        # Insert image centered
        x_offset = (pdf.w - page_width) / 2
        pdf.image(temp_path, x=x_offset, w=page_width)
        pdf.ln(img_height / 2.5)
        log.info("Food image inserted into PDF (%.0f x %.0fmm)", page_width, img_height)

    except Exception as e:
        log.warning("Failed to insert food image: %s", e)
        raise


def _add_sourcing_section(pdf: FPDF, ingredient_sources: dict) -> None:
    """
    Append an Ingredient Sourcing Guide page to an existing PDF.

    Layout:
      Page header — "Ingredient Sourcing Guide | Region | Near: city"
      Section 1   — Generic ingredients: top-5 local stores + 2 online stores
      Section 2   — Specialty ingredients: per-ingredient local (top-3) + online (2)

    Skipped silently if ingredient_sources is empty or sourcer was disabled.
    """
    if not ingredient_sources:
        return

    region    = ingredient_sources.get("region", "")
    location  = ingredient_sources.get("user_location", "")
    generic   = ingredient_sources.get("generic") or {}
    specialty = ingredient_sources.get("specialty") or {}

    # Nothing useful to show
    if not generic.get("ingredients") and not specialty:
        return

    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # ── Section title ─────────────────────────────────────────────────────────
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(30, 90, 50)   # forest green
    region_label = region.replace("_", " ").title() if region and region != "UNKNOWN" else ""
    title_text   = "Ingredient Sourcing Guide"
    if region_label:
        title_text += f"  |  {region_label}"
    pdf.multi_cell(0, 9, _safe(title_text), new_x="LMARGIN", new_y="NEXT")

    if location:
        pdf.set_font("Helvetica", "I", 9)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 6, _safe(f"Stores near: {location}"), new_x="LMARGIN", new_y="NEXT")

    pdf.set_draw_color(150, 200, 150)
    pdf.line(10, pdf.get_y() + 1, 200, pdf.get_y() + 1)
    pdf.ln(6)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _section_heading(text: str) -> None:
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 8, _safe(text), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(1)

    def _subsection_heading(text: str) -> None:
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(80, 80, 80)
        pdf.multi_cell(0, 6, _safe(text), new_x="LMARGIN", new_y="NEXT")

    def _local_store_row(rank: int, store: dict) -> None:
        name     = store.get("name", "Unknown")
        rating   = store.get("rating", 0.0)
        reviews  = store.get("review_count", 0)
        dist     = store.get("distance_mi", 0.0)
        address  = store.get("address", "")
        source   = store.get("source", "")
        stars    = f"{rating:.1f}" + ("★" if rating else "")  # ★
        reviews_str = f"{reviews:,}" if reviews else "—"
        dist_str    = f"{dist:.1f} mi" if dist else "—"
        src_label   = f" [{source}]" if source else ""
        line = f"  {rank}.  {name}{src_label}"
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(40, 40, 40)
        pdf.multi_cell(0, 6, _safe(line), new_x="LMARGIN", new_y="NEXT")
        detail = f"      {stars}  {reviews_str} reviews  {dist_str}"
        if address:
            detail += f"  |  {address}"
        pdf.set_font("Helvetica", "", 9)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 5, _safe(detail), new_x="LMARGIN", new_y="NEXT")

    def _online_store_row(store: dict) -> None:
        name   = store.get("name", "Unknown")
        url    = store.get("url", "")
        reason = store.get("reason", "")
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(30, 60, 130)   # link blue
        pdf.multi_cell(0, 6, _safe(f"  •  {name}  ({url})"), new_x="LMARGIN", new_y="NEXT")
        if reason:
            pdf.set_font("Helvetica", "I", 9)
            pdf.set_text_color(100, 100, 100)
            pdf.multi_cell(0, 5, _safe(f"      {reason}"), new_x="LMARGIN", new_y="NEXT")

    # ── SECTION 1: Generic ingredients ───────────────────────────────────────
    generic_ings    = generic.get("ingredients") or []
    generic_local   = generic.get("local_stores") or []
    generic_online  = generic.get("online_stores") or []

    if generic_ings:
        ings_preview = ", ".join(generic_ings[:6])
        if len(generic_ings) > 6:
            ings_preview += f" (+{len(generic_ings) - 6} more)"
        _section_heading("Generic Ingredients")
        pdf.set_font("Helvetica", "I", 9)
        pdf.set_text_color(100, 100, 100)
        pdf.multi_cell(0, 5, _safe(ings_preview), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

        if generic_local:
            _subsection_heading("Local Stores")
            for i, store in enumerate(generic_local, 1):
                _local_store_row(i, store)
            pdf.ln(2)

        if generic_online:
            _subsection_heading("Online")
            for store in generic_online:
                _online_store_row(store)
            pdf.ln(4)

    # ── SECTION 2: Specialty ingredients ─────────────────────────────────────
    if specialty:
        pdf.set_draw_color(200, 200, 200)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(4)
        _section_heading("Specialty Ingredients")

        for ing, data in specialty.items():
            local_stores  = data.get("local") or []
            online_stores = data.get("online") or []

            # Ingredient name as sub-heading
            pdf.set_font("Helvetica", "B", 11)
            pdf.set_text_color(60, 40, 0)   # warm brown
            pdf.multi_cell(0, 7, _safe(ing.title()), new_x="LMARGIN", new_y="NEXT")

            if local_stores:
                _subsection_heading("  Local Stores")
                for i, store in enumerate(local_stores, 1):
                    _local_store_row(i, store)
                pdf.ln(1)
            else:
                pdf.set_font("Helvetica", "I", 9)
                pdf.set_text_color(140, 140, 140)
                pdf.multi_cell(0, 5, _safe("  No local stores found nearby."), new_x="LMARGIN", new_y="NEXT")

            if online_stores:
                _subsection_heading("  Online")
                for store in online_stores:
                    _online_store_row(store)

            pdf.ln(4)


def pdf_generator_node(state: ArchivistState) -> dict:
    mode = state.get("mode", "express")
    food_image_b64 = state.get("food_image_b64") if config.EXTRACT_FOOD_IMAGE else None

    if mode == "express":
        transcription = state.get("express_transcription") or {}
        metadata      = state.get("express_hitl_metadata") or {}
        title         = metadata.get("title") or transcription.get("title") or "recipe"
        pdf           = _build_basic_pdf(transcription, metadata, food_image_b64)
        variant       = "basic"
    else:
        # Full path — historian_output contains verbatim content + enrichment
        historian_output = state.get("historian_output") or {}
        title            = historian_output.get("title") or "recipe"
        pdf              = _build_annotated_pdf(historian_output, dict(state), food_image_b64)
        variant          = "annotated"

    # ingredient_sourcer always runs before pdf_generator in the graph.
    # If sourcer is disabled or found no ingredients, ingredient_sources is {}
    # and _add_sourcing_section silently skips.
    _add_sourcing_section(pdf, state.get("ingredient_sources") or {})

    safe_title = "".join(c if c.isalnum() or c in "-_ " else "_" for c in str(title))[:50]
    timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename   = f"{safe_title}_{timestamp}.pdf"
    # Render to wherever the blob backend wants it staged, then publish. On the
    # local backend staging IS the destination and commit() is a no-op, so this
    # is the same single write it always was.
    out_path = blob_store.staging_path(filename)
    pdf.output(str(out_path))
    uri = blob_store.commit(out_path, filename)

    log.info("PDF saved: %s (variant=%s, blobs=%s)", uri, variant, blob_store.BACKEND)
    return {"pdf_path": uri, "pdf_variant": variant}
