"""
Ingredient Sourcer node — runs after pdf_generator, before indexer.

Classifies the recipe's ingredients into two tiers relative to the recipe's
cuisine region, then finds where to buy them — both locally and online.

Tier 1 (generic):
  Ingredients that are standard and widely available for this cuisine.
  → One batch local search (Google Places + Foursquare) for the best 5 stores
    near the user's location that cover most of these items.
  → Two online stores that can fulfil a single order.

Tier 2 (specialty):
  Ingredients that require specialty/ethnic retailers.
  → Per-ingredient local search (Google Places + Foursquare), top 3 stores.
  → Two online stores per ingredient.

Pipeline integration:
  pdf_generator → ingredient_sourcer → indexer

State consumed:
  express_transcription / repaired_transcription → ingredients list
  mode, origin_consensus, final_origin, user_region_hint, best_match_region
  sourcer_location (optional override)

State produced:
  generic_ingredients   list[str]
  specialty_ingredients list[str]
  ingredient_sources    dict  (see _build_result() for schema)
  sourcer_location      str
  llm_calls             int  (incremented)
  tool_calls            int  (incremented)
"""
from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from culinary_archivist import config, llm_client
from culinary_archivist.state import ArchivistState
from culinary_archivist.tools._places_utils import PlaceResult, deduplicate
from culinary_archivist.tools.geocoder import geocode, location_for_state
from culinary_archivist.tools.google_places_client import (
    search_generic_stores  as google_generic,
    search_specialty_stores as google_specialty,
)
from culinary_archivist.tools.online_stores import match_generic, match_specialty
import math

log = logging.getLogger(__name__)


# ── Ingredient classification prompt ─────────────────────────────────────────

_CLASSIFY_PROMPT = """\
You are a culinary sourcing assistant.

RECIPE REGION: {region}

INGREDIENTS:
{ingredients}

Task: Classify each ingredient as Tier 1 (generic) or Tier 2 (specialty) \
relative to {region} cooking.

Tier 1 (generic): Standard ingredients widely available at any grocery store \
that specialises in {region} cuisine. Example for South Indian: rice, coconut \
milk, mustard seeds, curry leaves, turmeric, cumin, oil.

Tier 2 (specialty): Ingredients that are hard to find outside specialist \
ethnic/gourmet stores or online retailers. Example for South Indian: kasuri \
methi, kalonji, asafoetida (hing), kokum, raw mango powder (amchur), \
dried rose petals.

Rules:
- Classify relative to {region} cuisine, not to a general Western supermarket.
- If an ingredient is ambiguous, put it in Tier 1.
- Keep ingredient names exactly as given in the input list.

Return ONLY a JSON object with exactly two keys — no explanation, no markdown:
  "generic":   array of Tier 1 ingredient strings
  "specialty": array of Tier 2 ingredient strings

All input ingredients must appear in exactly one of the two arrays.

Example output:
{{"generic": ["rice", "coconut milk", "mustard seeds"], "specialty": ["kasuri methi", "kalonji"]}}
"""


# ── Internal helpers ──────────────────────────────────────────────────────────

def _get_ingredients(state: ArchivistState) -> list[str]:
    """
    Extract the ingredient list from state.

    Priority (most enriched first):
      1. historian_output.ingredients  — full path, LLM-cleaned
      2. repaired_transcription.ingredients — full path OCR
      3. express_transcription.ingredients  — express path
    """
    # 1. Historian output (richest — LLM may have normalised ingredient names)
    historian_ings = (state.get("historian_output") or {}).get("ingredients") or []
    if historian_ings:
        return historian_ings

    # 2. Full-path repaired transcription
    if state.get("mode", "express") != "express":
        repaired_ings = (state.get("repaired_transcription") or {}).get("ingredients") or []
        if repaired_ings:
            return repaired_ings

    # 3. Express path
    return (state.get("express_transcription") or {}).get("ingredients") or []


def _get_region(state: ArchivistState) -> str:
    """
    Derive the cuisine region label from state, in priority order.
    Falls back to 'UNKNOWN' so the LLM and store lookups can still proceed.
    """
    for key in ("final_origin", "origin_consensus", "best_match_region", "user_region_hint"):
        val = (state.get(key) or "").strip().upper()
        if val and val != "UNKNOWN":
            return val
    return "UNKNOWN"


def _classify_ingredients(
    ingredients: list[str],
    region: str,
) -> tuple[list[str], list[str]]:
    """
    Ask the LLM to split ingredients into generic (Tier 1) and specialty (Tier 2).
    Falls back to putting everything in generic on any failure.
    """
    prompt = _CLASSIFY_PROMPT.format(
        region=region,
        ingredients="\n".join(f"- {i}" for i in ingredients),
    )

    try:
        raw = llm_client.chat(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=512,
            temperature=0,
        )
        log.debug("Classify LLM raw output:\n%s", raw)

        # Strip markdown fences
        text = raw.strip()
        if "```" in text:
            match = re.search(r"```(?:json)?\s*([\s\S]+?)```", text)
            if match:
                text = match.group(1).strip()

        # Extract first {...} block
        brace = re.search(r"\{[\s\S]*\}", text)
        if brace:
            text = brace.group(0)

        parsed = json.loads(text)
        generic   = parsed.get("generic", [])
        specialty = parsed.get("specialty", [])

        # Validate: every input ingredient must appear somewhere
        all_classified = set(g.lower() for g in generic) | set(s.lower() for s in specialty)
        missing = [i for i in ingredients if i.lower() not in all_classified]
        if missing:
            log.warning(
                "Classify: %d ingredients not assigned — adding to generic: %s",
                len(missing), missing,
            )
            generic.extend(missing)

        log.info(
            "Classify: region=%r  generic=%d  specialty=%d",
            region, len(generic), len(specialty),
        )
        return generic, specialty

    except Exception as exc:
        log.error("Classify LLM failed (%s) — treating all as generic", exc)
        return ingredients, []




def _search_generic_local(
    region: str,
    lat: float,
    lng: float,
) -> list[PlaceResult]:
    """
    Search for generic grocery stores using Google Places.
    Returns top-5 by quality rating.
    """
    results = google_generic(region, lat, lng, limit=7)
    # Deduplicate and rank by quality (rating × log10(review_count + 1))
    deduped = deduplicate(results)
    deduped.sort(
        key=lambda r: r["rating"] * math.log10(r["review_count"] + 1),
        reverse=True,
    )
    top_5 = deduped[:5]
    log.info("Generic local: google=%d → top %d", len(results), len(top_5))
    return top_5


def _search_specialty_local(
    ingredients: list[str],
    region: str,
    lat: float,
    lng: float,
) -> dict[str, list[PlaceResult]]:
    """
    Search for specialty stores for each ingredient using Google Places.
    Runs searches in parallel. Returns {ingredient: [top-3 PlaceResult]}.
    """
    result: dict[str, list[PlaceResult]] = {}

    def _search_one(ing: str) -> tuple[str, list[PlaceResult]]:
        stores = google_specialty(ing, region, lat, lng, limit=4)
        # Rank by quality and take top 3
        deduped = deduplicate(stores)
        deduped.sort(
            key=lambda r: r["rating"] * math.log10(r["review_count"] + 1),
            reverse=True,
        )
        return (ing, deduped[:3])

    # Run all ingredients concurrently
    max_workers = min(len(ingredients), 8)
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_search_one, ing): ing for ing in ingredients}
        for fut in as_completed(futures):
            ing = futures[fut]
            try:
                name, stores = fut.result()
                result[name] = stores
                log.info("Specialty local: %r → %d stores", name, len(stores))
            except Exception as exc:
                log.error("Specialty local search failed for %r: %s", ing, exc)
                result[ing] = []

    return result


def _build_result(
    region:           str,
    location:         str,
    generic:          list[str],
    specialty:        list[str],
    generic_local:    list[PlaceResult],
    generic_online:   list[dict],
    specialty_local:  dict[str, list[PlaceResult]],
    specialty_online: dict[str, list[dict]],
) -> dict:
    """
    Assemble the final ingredient_sources dict written to state.

    Schema:
    {
      "region": str,
      "user_location": str,
      "generic": {
        "ingredients": list[str],
        "local_stores": list[PlaceResult],   # top 5
        "online_stores": list[dict]          # top 2
      },
      "specialty": {
        "<ingredient>": {
          "local":  list[PlaceResult],       # top 3
          "online": list[dict]               # top 2
        },
        ...
      }
    }
    """
    return {
        "region":        region,
        "user_location": location,
        "generic": {
            "ingredients":  generic,
            "local_stores": [dict(r) for r in generic_local],
            "online_stores": generic_online,
        },
        "specialty": {
            ing: {
                "local":  [dict(r) for r in specialty_local.get(ing, [])],
                "online": specialty_online.get(ing, []),
            }
            for ing in specialty
        },
    }


# ── Node ──────────────────────────────────────────────────────────────────────

def ingredient_sourcer_node(state: ArchivistState) -> dict:
    """
    LangGraph node: classify ingredients → search local stores → match online stores.

    Skipped entirely when SOURCER_ENABLED=false or there are no ingredients.
    All API failures are caught and logged — the node never crashes the pipeline.
    """
    if not config.SOURCER_ENABLED:
        log.info("Ingredient sourcer: disabled (SOURCER_ENABLED=false) — skipping")
        return {
            "generic_ingredients":  [],
            "specialty_ingredients": [],
            "ingredient_sources":   {},
            "sourcer_location":     "",
        }

    # ── 1. Get ingredients ────────────────────────────────────────────────────
    ingredients = _get_ingredients(state)
    if not ingredients:
        log.warning("Ingredient sourcer: no ingredients found in state — skipping")
        return {
            "generic_ingredients":  [],
            "specialty_ingredients": [],
            "ingredient_sources":   {},
            "sourcer_location":     "",
        }

    log.info("Ingredient sourcer: %d ingredients found", len(ingredients))

    # ── 2. Get region ─────────────────────────────────────────────────────────
    region = _get_region(state)
    log.info("Ingredient sourcer: region=%r", region)

    # ── 3. Classify into generic / specialty (1 LLM call) ────────────────────
    generic, specialty = _classify_ingredients(ingredients, region)
    llm_calls = 1

    # Cap specialty searches to avoid excessive API usage
    specialty_to_search = specialty[:config.SOURCER_MAX_SPECIALTY_INGREDIENTS]
    if len(specialty) > config.SOURCER_MAX_SPECIALTY_INGREDIENTS:
        log.info(
            "Ingredient sourcer: capping specialty search at %d (have %d)",
            config.SOURCER_MAX_SPECIALTY_INGREDIENTS, len(specialty),
        )

    # ── 4. Geocode location ───────────────────────────────────────────────────
    location = location_for_state(state)
    lat, lng = geocode(location)
    log.info("Ingredient sourcer: location=%r → (%.4f, %.4f)", location, lat, lng)

    # ── 5. Local store searches (parallel: Google + Foursquare) ───────────────
    api_calls = 0

    generic_local = _search_generic_local(region, lat, lng)
    # 2 API calls: 1 Google + 1 Foursquare (each may run multiple queries internally)
    api_calls += 2

    specialty_local: dict[str, list[PlaceResult]] = {}
    if specialty_to_search:
        specialty_local = _search_specialty_local(specialty_to_search, region, lat, lng)
        api_calls += len(specialty_to_search) * 2   # 2 calls per ingredient (G + FSQ)

    # ── 6. Online store matching (1 LLM call each) ────────────────────────────
    generic_online   = match_generic(generic, region)
    specialty_online = match_specialty(specialty_to_search, region)
    llm_calls       += 2

    # ── 7. Build result ───────────────────────────────────────────────────────
    ingredient_sources = _build_result(
        region           = region,
        location         = location,
        generic          = generic,
        specialty        = specialty_to_search,
        generic_local    = generic_local,
        generic_online   = generic_online,
        specialty_local  = specialty_local,
        specialty_online = specialty_online,
    )

    log.info(
        "Ingredient sourcer done: generic=%d  specialty=%d  "
        "generic_local=%d  llm_calls=%d  api_calls=%d",
        len(generic), len(specialty_to_search),
        len(generic_local), llm_calls, api_calls,
    )

    return {
        "generic_ingredients":  generic,
        "specialty_ingredients": specialty,
        "ingredient_sources":   ingredient_sources,
        "sourcer_location":     location,
        "llm_calls":  state.get("llm_calls",  0) + llm_calls,
        "tool_calls": state.get("tool_calls", 0) + api_calls,
    }
