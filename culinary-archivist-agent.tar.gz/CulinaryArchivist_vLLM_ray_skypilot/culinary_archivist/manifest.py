"""
Done-manifest for batch runs — idempotence across a failover.

Batch mode iterates a directory and keeps no record of what finished. If the
pod dies halfway through 40 recipes and SkyPilot relaunches it in team-b, the
replacement reprocesses everything from the top: wasted GPU time, duplicate
PDFs, and duplicate Chroma entries.

This appends one JSON line per completed recipe to a file on the shared volume.
On startup the batch loop reads it and skips what's already done — so the run
*continues* in team-b instead of starting over.

Format (one object per line, append-only so a torn write costs one record):
    {"file": "recipe_003.jpg", "status": "ok", "tenant": "team-a",
     "run_id": "...", "pdf_path": "...", "ts": "2026-08-23T21:40:00Z"}
"""
import json
import logging
import os
import tempfile
import time
from pathlib import Path

log = logging.getLogger(__name__)


class DoneManifest:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._done: set[str] = set()
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        bad = 0
        with self.path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    bad += 1          # torn final write from a killed pod — ignore
                    continue
                if rec.get("status") == "ok" and rec.get("file"):
                    self._done.add(rec["file"])
        log.info(
            "Manifest %s: %d completed, %d unreadable line(s)",
            self.path, len(self._done), bad,
        )

    def is_done(self, media_path) -> bool:
        return Path(media_path).name in self._done

    def mark(self, media_path, status: str = "ok", **extra) -> None:
        from culinary_archivist import config

        rec = {
            "file":    Path(media_path).name,
            "status":  status,
            "tenant":  os.getenv("TENANT_NAME", "local"),
            "run_id":  config.RUN_ID,
            "ts":      time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            **extra,
        }
        # Append + fsync: a pod that is about to be killed must not lose the
        # record of work it actually finished.
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, default=str) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        if status == "ok":
            self._done.add(rec["file"])

    @property
    def completed(self) -> int:
        return len(self._done)

    # ── parity with PostgresManifest, so main.py needs no branching ──────────
    def claim(self, media_path, force: bool = False) -> bool:
        """
        A file manifest cannot fence. It can only answer "is this already done".

        Safe on a single node ONLY because the failover trigger blocks the victim
        tenant before killing the pod, so two agents never run at once. That is
        an ordering discipline, not an enforced one — which is precisely what the
        Postgres backend replaces.
        """
        return True if force else not self.is_done(media_path)

    def acquire_run_lease(self, wait_seconds: int | None = None) -> bool:
        return True          # no fencing available; see claim()

    def release_run_lease(self) -> None:
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Postgres-backed manifest — claims instead of appends (INSTALL.md Part 7b)
# ─────────────────────────────────────────────────────────────────────────────

_DDL = """
CREATE TABLE IF NOT EXISTS run_manifest (
    run_id      text        NOT NULL,
    file        text        NOT NULL,
    status      text        NOT NULL DEFAULT 'claimed',   -- claimed | ok | error
    tenant      text,
    node        text,
    pod         text,
    attempt     int         NOT NULL DEFAULT 1,
    pdf_path    text,
    error       text,
    claimed_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, file)
);
"""

# Whoever inserts the row owns that recipe. A row already 'ok' matches neither
# WHERE branch, so nothing is returned and the caller skips it. A row left
# 'claimed' by a pod that died becomes reclaimable once it goes stale.
#
# This is the guard that does NOT depend on liveness detection, which is why it
# exists alongside the advisory lock rather than instead of it: even inside the
# window where a dead pod still holds the lease, two agents cannot both process
# the same recipe.
_CLAIM = """
INSERT INTO run_manifest (run_id, file, tenant, node, pod)
VALUES (%(run_id)s, %(file)s, %(tenant)s, %(node)s, %(pod)s)
ON CONFLICT (run_id, file) DO UPDATE
   SET tenant     = EXCLUDED.tenant,
       node       = EXCLUDED.node,
       pod        = EXCLUDED.pod,
       status     = 'claimed',
       attempt    = run_manifest.attempt + 1,
       claimed_at = now(),
       updated_at = now()
 WHERE run_manifest.status = 'error'
    OR (run_manifest.status = 'claimed'
        AND run_manifest.claimed_at < now() - make_interval(mins => %(stale)s))
RETURNING attempt;
"""

# --no-resume: take the recipe regardless of what any previous run recorded.
_CLAIM_FORCE = """
INSERT INTO run_manifest (run_id, file, tenant, node, pod)
VALUES (%(run_id)s, %(file)s, %(tenant)s, %(node)s, %(pod)s)
ON CONFLICT (run_id, file) DO UPDATE
   SET tenant = EXCLUDED.tenant, node = EXCLUDED.node, pod = EXCLUDED.pod,
       status = 'claimed', attempt = run_manifest.attempt + 1,
       claimed_at = now(), updated_at = now()
RETURNING attempt;
"""


class PostgresManifest:
    """
    Same surface as DoneManifest, plus claim() and a run-level lease.

    Uses ONE dedicated connection, not the checkpointer's pool. The advisory
    lock is session-scoped: it lives and dies with the connection holding it, so
    that connection must never be handed back to a pool and reused elsewhere.
    """

    def __init__(self, dsn: str | None = None):
        import psycopg
        from culinary_archivist import config

        self._cfg = config
        self._run_id = config.RUN_ID
        self._conn = psycopg.connect(dsn or config.PG_DSN, autocommit=True)
        with self._conn.cursor() as cur:
            cur.execute(_DDL)
        self._have_lease = False
        log.info("Manifest: Postgres run_manifest at %s (run_id=%s)",
                 config.PG_DSN_SAFE, self._run_id)

    # ── identity of this attempt ─────────────────────────────────────────────
    def _who(self) -> dict:
        return {"run_id": self._run_id,
                "tenant": os.getenv("TENANT_NAME", "local"),
                "node":   os.getenv("NODE_NAME", None),
                "pod":    os.getenv("POD_NAME", None)}

    # ── run lease (fencing guard one) ────────────────────────────────────────
    def acquire_run_lease(self, wait_seconds: int | None = None) -> bool:
        """
        Take a session-scoped advisory lock on this run_id.

        Retries rather than failing on the first refusal: a pod killed with
        --force leaves its session to be reaped by TCP keepalives, so the
        replacement routinely arrives while the corpse still holds the lock.
        See config.LEASE_WAIT_SECONDS for why that wait is what it is.
        """
        import time

        wait = self._cfg.LEASE_WAIT_SECONDS if wait_seconds is None else wait_seconds
        poll = max(1, self._cfg.LEASE_POLL_SECONDS)
        deadline = time.monotonic() + wait
        announced = False
        while True:
            with self._conn.cursor() as cur:
                cur.execute("SELECT pg_try_advisory_lock(hashtext(%s)::bigint)",
                            (self._run_id,))
                if cur.fetchone()[0]:
                    self._have_lease = True
                    log.info("Manifest: acquired run lease for %s", self._run_id)
                    return True
            if time.monotonic() >= deadline:
                log.error(
                    "Manifest: run %s is still held by another agent after %ss. "
                    "Refusing to start — two agents on one run corrupt it.",
                    self._run_id, wait)
                return False
            if not announced:
                print(f"  \u23f3 waiting for the previous agent's lease on "
                      f"{self._run_id} (up to {wait}s)...", flush=True)
                announced = True
            time.sleep(poll)

    def release_run_lease(self) -> None:
        if not self._have_lease:
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute("SELECT pg_advisory_unlock(hashtext(%s)::bigint)",
                            (self._run_id,))
            self._have_lease = False
        except Exception as exc:                                # noqa: BLE001
            log.warning("Manifest: lease release failed (harmless): %s", exc)

    # ── claims (fencing guard two) ───────────────────────────────────────────
    def claim(self, media_path, force: bool = False) -> bool:
        params = {**self._who(), "file": Path(media_path).name,
                  "stale": self._cfg.CLAIM_STALE_MINUTES}
        with self._conn.cursor() as cur:
            cur.execute(_CLAIM_FORCE if force else _CLAIM, params)
            return cur.fetchone() is not None

    # ── same surface as DoneManifest ─────────────────────────────────────────
    def is_done(self, media_path) -> bool:
        with self._conn.cursor() as cur:
            cur.execute("SELECT 1 FROM run_manifest "
                        "WHERE run_id=%s AND file=%s AND status='ok'",
                        (self._run_id, Path(media_path).name))
            return cur.fetchone() is not None

    def mark(self, media_path, status: str = "ok", **extra) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                "UPDATE run_manifest SET status=%s, pdf_path=%s, error=%s, "
                "updated_at=now() WHERE run_id=%s AND file=%s",
                (status, str(extra.get("pdf_path") or "") or None,
                 str(extra.get("error") or "") or None,
                 self._run_id, Path(media_path).name))

    @property
    def completed(self) -> int:
        with self._conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM run_manifest "
                        "WHERE run_id=%s AND status='ok'", (self._run_id,))
            return cur.fetchone()[0]


def get_manifest(path=None):
    """Pick the backend. Same object shape either way."""
    from culinary_archivist import config

    if config.USE_POSTGRES:
        return PostgresManifest()
    return DoneManifest(path if path is not None else config.MANIFEST_PATH)
