"""
benchmark_pipeline_ray.py
=========================
Runs the CulinaryArchivist LangGraph pipeline on every JPEG in data/
using Ray remote tasks for parallel execution.

Ray APIs used
-------------
  ray.util.metrics.Histogram  — per-node latency distribution (Prometheus-scrapeable)
  ray.util.metrics.Counter    — images completed, errors, LLM calls
  ray.util.metrics.Gauge      — in-flight task count
  ray.timeline()              — Chrome trace of all task scheduling/execution
  ray.experimental.state      — Ray task scheduling overhead stats post-run

The Histogram/Counter/Gauge metrics are emitted to Ray's metrics port (9090)
and can be scraped by Prometheus or viewed at the Ray Dashboard at port 8265.

Parallelism
-----------
  Hardcoded to p=1. Run separately for p=4, p=8, etc.
  Ray handles scheduling — batching is done by launching all N futures at once
  and calling ray.get() on the full list.

Output files (written to output/ alongside PDFs)
------------------------------------------------
  benchmark_<ts>_p1.txt           — full terminal report (parallelism level in filename)
  pipeline_trace_<ts>_p1.json     — Chrome trace (--timeline flag only)
  vllm_gauge_<ts>_p1.csv          — GPU cache + active requests, polled every N secs
  vllm_metrics_<ts>_p1.csv        — inference time histograms + TPS summary (once at end)

Command line arguments
----------------------
  --parallel N           Parallelism level (required: 1, 4, 8, 16, etc.)
  --images PATH          Directory of JPEG/PNG images (default: data/)
  --timeline             Write Chrome trace to output/ after run
  --gauge-interval S     Seconds between gauge metric polls, accepts sub-second (default: 0.5)

Usage
-----
  # Run with parallelism level (required)
  python benchmark_pipeline_ray.py --parallel 1
  python benchmark_pipeline_ray.py --parallel 4
  python benchmark_pipeline_ray.py --parallel 8

  # With Chrome trace
  python benchmark_pipeline_ray.py --parallel 1 --timeline

  # Custom gauge poll interval
  python benchmark_pipeline_ray.py --parallel 4 --gauge-interval 0.25

  # Custom image directory
  python benchmark_pipeline_ray.py --parallel 1 --images /path/to/jpegs

Prerequisites
-------------
  vLLM text model  running: vllm serve Qwen/Qwen2.5-32B-Instruct  --port 8000
  vLLM vision model running: vllm serve Qwen/Qwen2.5-VL-7B-Instruct --port 8001
  vLLM embed model  running: vllm serve BAAI/bge-m3 --port 8002 --task embed
  LLM_BACKEND=vllm in .env  (not ray_serve — token metrics require direct vLLM)
"""
from __future__ import annotations

import argparse
import csv
import logging
import statistics
import sys
import threading
import time
import uuid
from pathlib import Path

import ray
from ray.util.metrics import Counter, Gauge, Histogram

# Module-level so the /metrics scrape helpers can reach VLLM_METRICS_HOST
# regardless of which function they sit in.
from culinary_archivist import config

# ── Shared Ray metrics — defined at module level so all workers share them ────
#
# These are emitted to Ray's metrics export port (default 9090) automatically.
# No Prometheus config needed — Ray pushes them.  View in Ray Dashboard → Metrics.

node_latency_ms = Histogram(
    name="culinary_pipeline_node_latency_ms",
    description="Wall-clock time per LangGraph node (ms)",
    boundaries=[50, 200, 500, 1000, 2000, 5000, 10000, 20000, 40000],
    tag_keys=("node", "path"),         # path = "express" | "full"
)

pipeline_wall_ms = Histogram(
    name="culinary_pipeline_wall_ms",
    description="End-to-end wall time per image (ms)",
    boundaries=[1000, 3000, 5000, 10000, 20000, 40000, 60000, 120000],
    tag_keys=("path",),
)

images_completed = Counter(
    name="culinary_pipeline_images_completed_total",
    description="Images successfully processed",
    tag_keys=("path",),
)

images_failed = Counter(
    name="culinary_pipeline_images_failed_total",
    description="Images that errored during processing",
    tag_keys=(),
)

llm_calls_total = Counter(
    name="culinary_pipeline_llm_calls_total",
    description="Total LLM calls made across all pipeline runs",
    tag_keys=("node",),
)

tasks_in_flight = Gauge(
    name="culinary_pipeline_tasks_in_flight",
    description="Number of Ray pipeline tasks currently running",
    tag_keys=(),
)

# ── Constants ─────────────────────────────────────────────────────────────────

DATA_DIR         = Path(__file__).parent / "data"
OUTPUT_DIR       = Path(__file__).parent / "output"
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}


# ── Tee — write to terminal and file simultaneously ───────────────────────────

class _Tee:
    """Redirect sys.stdout so every print() goes to both terminal and a file."""

    def __init__(self, filepath: Path) -> None:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        self._file   = filepath.open("w", encoding="utf-8")
        self._stdout = sys.stdout
        sys.stdout   = self

    def write(self, data: str) -> None:
        self._stdout.write(data)
        self._file.write(data)

    def flush(self) -> None:
        self._stdout.flush()
        self._file.flush()

    def close(self) -> None:
        sys.stdout = self._stdout
        self._file.close()


# ══════════════════════════════════════════════════════════════════════════════
#  RAY REMOTE TASK
# ══════════════════════════════════════════════════════════════════════════════

@ray.remote
def run_pipeline_timed(image_path: str) -> dict:
    """
    Run one image through the full pipeline.

    Timing is collected from LangGraph stream_mode="updates", which emits
    {node_name: state_delta} after each node — exact node boundaries with
    no changes to agent code.

    Each node latency is recorded into the shared Ray Histogram so it appears
    in the Ray Dashboard and Prometheus scrape target automatically.
    """
    import time as _time
    from langgraph.types import Command
    from culinary_archivist.checkpointer import get_checkpointer, thread_id_for
    from culinary_archivist.graph import build_graph

    logging.basicConfig(level=logging.WARNING)

    # Durable + deterministic: a worker that dies mid-image (or a whole pod that
    # moves to the other vcluster) resumes this thread instead of replaying it.
    checkpointer = get_checkpointer()
    graph        = build_graph().compile(checkpointer=checkpointer)
    run_config   = {"configurable": {"thread_id": thread_id_for(image_path)}}
    image_name   = Path(image_path).name

    initial_state = {
        "media_path":            image_path,
        "media_type":            "image",
        "mode":                  "",
        "user_region_hint":      "",
        "media_quality_score":   0.0,
        "media_date_detected":   0,
        "llm_calls":             0,
        "tool_calls":            0,
        "total_loop_iterations": 0,
        "hitl_escalations":      0,
        "errors":                [],
    }

    node_timings: dict[str, float] = {}

    def _stream(resume_value=None) -> None:
        t_last = _time.perf_counter()
        stream = (
            graph.stream(initial_state, config=run_config, stream_mode="updates")
            if resume_value is None
            else graph.stream(Command(resume=resume_value), config=run_config, stream_mode="updates")
        )
        for event in stream:
            t_now = _time.perf_counter()
            for node_name in event:
                elapsed_ms = round((t_now - t_last) * 1000, 1)
                # Accumulate across retries (historian can loop)
                node_timings[node_name] = node_timings.get(node_name, 0.0) + elapsed_ms
                # ── Emit to Ray metrics (Histogram) ───────────────────────────
                # path tag is set after the run; we use "unknown" here and
                # re-emit the final path-tagged value in the summary block below.
            t_last = t_now

    wall_start = _time.perf_counter()
    errors: list[str] = []

    try:
        _stream()

        # Auto-accept HITL interrupts (benchmark mode)
        for _ in range(10):
            state = graph.get_state(run_config)
            if not state.next:
                break
            interrupts = [i for task in state.tasks for i in task.interrupts]
            if not interrupts:
                break
            itype = interrupts[0].value.get("type", "")
            _stream(resume_value={"action": "index"} if itype == "duplicate_check" else {"accepted": True})

        final = graph.get_state(run_config).values
        path  = (
            "full"    if (final.get("historian_output"))        else
            "express" if (final.get("express_transcription"))   else
            "unknown"
        )
        llm_n        = final.get("llm_calls",  0)
        tool_n       = final.get("tool_calls", 0)
        pdf_ok       = bool(final.get("pdf_path"))
        errs         = final.get("errors", [])
        # ── Collect e2e latency + TPS + embed metrics from vllm_client ──────
        from culinary_archivist import vllm_client as _vc
        _all_metrics  = _vc.get_call_metrics()
        token_metrics = _all_metrics["llm"]
        embed_metrics = _all_metrics["embed"]

    except Exception as e:
        errors.append(str(e))
        path          = "error"
        llm_n         = 0
        tool_n        = 0
        pdf_ok        = False
        token_metrics = []
        embed_metrics = []

    wall_ms = round((_time.perf_counter() - wall_start) * 1000, 1)

    # ── Emit all Ray metrics now that path is known ───────────────────────────

    if errors:
        images_failed.inc()
    else:
        images_completed.inc(tags={"path": path})
        pipeline_wall_ms.observe(wall_ms, tags={"path": path})

        for node_name, ms in node_timings.items():
            node_latency_ms.observe(ms, tags={"node": node_name, "path": path})

        # Attribute LLM calls to the historian node (majority owner)
        if llm_n > 0:
            llm_calls_total.inc(llm_n, tags={"node": "historian"})

    return {
        "image":         image_name,
        "wall_ms":       wall_ms,
        "path":          path,
        "llm_calls":     llm_n,
        "tool_calls":    tool_n,
        "pdf_ok":        pdf_ok,
        "node_ms":       node_timings,
        "token_metrics": token_metrics,
        "embed_metrics": embed_metrics,
        "errors":        errors,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  AGGREGATION
# ══════════════════════════════════════════════════════════════════════════════

def _pct(data: list[float]) -> dict:
    if not data:
        return {}
    s = sorted(data)
    n = len(s)
    return {
        "n":    n,
        "min":  round(s[0], 0),
        "p50":  round(statistics.median(s), 0),
        "p95":  round(s[min(int(n * 0.95), n - 1)], 0),
        "max":  round(s[-1], 0),
        "mean": round(statistics.mean(s), 0),
    }


def aggregate(results: list[dict]) -> dict:
    ok   = [r for r in results if not r["errors"]]
    fail = [r for r in results if r["errors"]]

    node_samples: dict[str, list[float]] = {}
    for r in ok:
        for node, ms in r["node_ms"].items():
            node_samples.setdefault(node, []).append(ms)

    # ── Token metrics aggregated per model ────────────────────────────────────
    token_by_model: dict[str, dict[str, list]] = {}
    for r in ok:
        for m in r.get("token_metrics", []):
            model = m["model"]
            if model not in token_by_model:
                token_by_model[model] = {"e2e_ms": [], "tps": [], "prompt": [], "completion": []}
            token_by_model[model]["e2e_ms"].append(m["e2e_latency_ms"])
            token_by_model[model]["tps"].append(m["tps"])
            token_by_model[model]["prompt"].append(m["prompt_tokens"])
            token_by_model[model]["completion"].append(m["completion_tokens"])

    token_agg = {
        model: {
            "e2e_ms":            _pct(v["e2e_ms"]),
            "tps":               _pct(v["tps"]),
            "prompt_tokens":     round(statistics.mean(v["prompt"]),     0) if v["prompt"]     else 0,
            "completion_tokens": round(statistics.mean(v["completion"]), 0) if v["completion"] else 0,
            "calls":             len(v["e2e_ms"]),
        }
        for model, v in token_by_model.items()
    }

    # ── Embed metrics aggregated ───────────────────────────────────────────────
    embed_by_model: dict[str, dict[str, list]] = {}
    for r in ok:
        for m in r.get("embed_metrics", []):
            model = m["model"]
            if model not in embed_by_model:
                embed_by_model[model] = {"e2e_ms": [], "vec_s": [], "n_texts": []}
            embed_by_model[model]["e2e_ms"].append(m["e2e_latency_ms"])
            embed_by_model[model]["vec_s"].append(m["vec_s"])
            embed_by_model[model]["n_texts"].append(m["n_texts"])

    embed_agg = {
        model: {
            "e2e_ms":      _pct(v["e2e_ms"]),
            "vec_s":       _pct(v["vec_s"]),
            "avg_n_texts": round(statistics.mean(v["n_texts"]), 0) if v["n_texts"] else 0,
            "calls":       len(v["e2e_ms"]),
        }
        for model, v in embed_by_model.items()
    }

    return {
        "total":         len(results),
        "ok":            len(ok),
        "failed":        len(fail),
        "wall_ms":       _pct([r["wall_ms"]   for r in ok]),
        "llm":           _pct([r["llm_calls"] for r in ok]),
        "paths":         {p: sum(1 for r in ok if r["path"] == p) for p in {r["path"] for r in ok}},
        "nodes":         {node: _pct(times) for node, times in node_samples.items()},
        "token_metrics": token_agg,
        "embed_metrics": embed_agg,
        "failures":      [{"image": r["image"], "error": r["errors"][0]} for r in fail],
    }


# ══════════════════════════════════════════════════════════════════════════════
#  RAY STATE — task-level timing from Ray's own bookkeeping
# ══════════════════════════════════════════════════════════════════════════════

def print_ray_task_stats() -> None:
    """
    Pull task timing from ray.experimental.state — Ray's own view of how long
    each remote task took to schedule and execute.

    This is separate from per-node timing: it shows Ray overhead
    (scheduling latency, object store transfer, worker startup).
    """
    try:
        from ray.experimental.state.api import list_tasks
        pipeline_tasks = list_tasks(
            filters=[("func_or_class_name", "=", "run_pipeline_timed")]
        )
        durations = []
        for t in pipeline_tasks:
            start = getattr(t, "start_time_ms", None)
            end   = getattr(t, "end_time_ms",   None)
            if start and end:
                durations.append(end - start)
        if durations:
            pcts = _pct(durations)
            print(f"\n  Ray task wall times (from ray.experimental.state):")
            print(f"    n={pcts['n']}  p50={pcts['p50']}ms  p95={pcts['p95']}ms  max={pcts['max']}ms")
            print(f"    (includes Ray scheduling overhead + worker startup)")
        else:
            print("  (ray.experimental.state: no task timing data available yet)")
    except Exception as e:
        print(f"  ray task stats unavailable: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  DISPLAY
# ══════════════════════════════════════════════════════════════════════════════

def _section(title: str) -> None:
    print(f"\n{'─' * 64}")
    print(f"  {title}")
    print(f"{'─' * 64}")


def print_run_report(agg: dict, parallelism: int, total_wall_s: float) -> None:
    n    = agg["ok"]
    tput = round(n / total_wall_s, 3) if total_wall_s and n else 0

    print(f"\n  Succeeded      : {n}/{agg['total']}")
    print(f"  Failed         : {agg['failed']}")
    print(f"  Total wall     : {round(total_wall_s, 1)}s")
    print(f"  Throughput     : {tput} img/s  (~{round(1/tput,1)}s per image)" if tput else "")
    print(f"  Path split     : {agg['paths']}")
    print(f"  LLM calls/img  : p50={agg['llm'].get('p50','?')}  max={agg['llm'].get('max','?')}")

    print(f"\n  {'node':<25}  {'p50 ms':>8}  {'p95 ms':>8}  {'max ms':>8}  n")
    print(f"  {'─'*25}  {'─'*8}  {'─'*8}  {'─'*8}  ─")
    ordered = sorted(agg["nodes"].items(), key=lambda x: x[1].get("p50", 0), reverse=True)
    for node_name, s in ordered:
        print(f"  {node_name:<25}  {str(s.get('p50','—')):>8}  "
              f"{str(s.get('p95','—')):>8}  {str(s.get('max','—')):>8}  {s.get('n','')}")

    if ordered:
        top, top_s = ordered[0]
        wall_p50   = agg["wall_ms"].get("p50", 1)
        pct        = round(top_s.get("p50", 0) / wall_p50 * 100) if wall_p50 else 0
        print(f"\n  ► {top} dominates: {top_s.get('p50')}ms p50 = {pct}% of wall time")

    # ── Token metrics ──────────────────────────────────────────────────────────
    token_agg = agg.get("token_metrics", {})
    if token_agg:
        print(f"\n  TOKEN METRICS  (e2e latency + tokens/s per model)")
        print(f"  {'model':<35}  {'e2e p50':>8}  {'e2e p95':>8}  {'tps p50':>8}  {'avg prompt':>10}  {'avg completion':>14}  calls")
        print(f"  {'─'*35}  {'─'*8}  {'─'*8}  {'─'*8}  {'─'*10}  {'─'*14}  ─────")
        for model, s in token_agg.items():
            short = model.split("/")[-1]   # e.g. Qwen2.5-72B-Instruct
            print(f"  {short:<35}  "
                  f"{str(s['e2e_ms'].get('p50','—')):>8}  "
                  f"{str(s['e2e_ms'].get('p95','—')):>8}  "
                  f"{str(s['tps'].get('p50','—')):>8}  "
                  f"{str(s['prompt_tokens']):>10}  "
                  f"{str(s['completion_tokens']):>14}  "
                  f"{s['calls']}")

    # ── Embed metrics ──────────────────────────────────────────────────────────
    embed_agg = agg.get("embed_metrics", {})
    if embed_agg:
        print(f"\n  EMBED METRICS  (e2e latency + vectors/s)")
        print(f"  {'model':<25}  {'e2e p50':>8}  {'e2e p95':>8}  {'vec/s p50':>10}  {'avg batch':>10}  calls")
        print(f"  {'─'*25}  {'─'*8}  {'─'*8}  {'─'*10}  {'─'*10}  ─────")
        for model, s in embed_agg.items():
            short = model.split("/")[-1]
            print(f"  {short:<25}  "
                  f"{str(s['e2e_ms'].get('p50','—')):>8}  "
                  f"{str(s['e2e_ms'].get('p95','—')):>8}  "
                  f"{str(s['vec_s'].get('p50','—')):>10}  "
                  f"{str(s['avg_n_texts']):>10}  "
                  f"{s['calls']}")

    print(f"\n  Ray Dashboard → http://localhost:8265  (Metrics tab shows histograms live)")
    print(f"  Prometheus    → http://localhost:9090/metrics | grep culinary_pipeline")

    if agg["failures"]:
        print(f"\n  Failures:")
        for f in agg["failures"]:
            print(f"    ✗ {f['image']}: {f['error'][:80]}")


# ══════════════════════════════════════════════════════════════════════════════
#  SWEEP
# ══════════════════════════════════════════════════════════════════════════════

def run_sweep(images: list[Path], levels: list[int], trace_path: Path | None) -> None:
    report = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "n_images":  len(images),
        "runs":      {},
    }

    for p in levels:
        _section(f"PARALLELISM = {p}  —  {len(images)} images, batches of {p}")
        print(f"  Launching {len(images)} Ray tasks ({p} in-flight at a time)...")

        batch_results: list[dict] = []
        wall_start = time.perf_counter()

        for batch_start in range(0, len(images), p):
            batch = images[batch_start : batch_start + p]

            # ── Update in-flight gauge ─────────────────────────────────────
            tasks_in_flight.set(len(batch))

            futures = [run_pipeline_timed.remote(str(img)) for img in batch]
            results = ray.get(futures)   # blocks until this batch completes
            batch_results.extend(results)

            tasks_in_flight.set(0)

            for r in results:
                status = "✓" if not r["errors"] else "✗"
                print(f"    {status} {r['image']:<35} {r['wall_ms']:>7.0f}ms  "
                      f"path={r['path']}  llm_calls={r['llm_calls']}")

        total_wall_s = time.perf_counter() - wall_start
        agg = aggregate(batch_results)
        print_run_report(agg, p, total_wall_s)

        # ── Ray task stats (Ray's own bookkeeping) ─────────────────────────
        print_ray_task_stats()

        report["runs"][str(p)] = {
            "parallelism":  p,
            "total_wall_s": round(total_wall_s, 2),
            "throughput":   round(len(images) / total_wall_s, 3) if total_wall_s else 0,
            "aggregate":    agg,
        }

    # ── Chrome trace ───────────────────────────────────────────────────────────
    if trace_path is not None:
        try:
            ray.timeline(filename=str(trace_path))
            print(f"\n  Chrome trace written → {trace_path}")
            print(f"  scp it to your laptop, then open in chrome://tracing or perfetto.html")
            print(f"  Shows: Ray task scheduling gaps, worker startup, object store transfers")
        except Exception as e:
            print(f"\n  ray.timeline() failed: {e}")

    # ── Throughput comparison ──────────────────────────────────────────────────
    if len(levels) > 1:
        _section("THROUGHPUT COMPARISON")
        print(f"  {'parallel':>8}  {'wall_s':>8}  {'img/s':>8}  {'speedup':>8}")
        base = None
        for p in levels:
            run  = report["runs"][str(p)]
            tput = run["throughput"]
            if base is None:
                base = tput
            speedup = round(tput / base, 2) if base else 1.0
            print(f"  {p:>8}  {run['total_wall_s']:>8.1f}  {tput:>8.3f}  {speedup:>7.2f}×")
        print("\n  Sub-linear speedup = vLLM memory bandwidth saturating.")
        print("  Near-linear speedup = GPU has headroom; increase parallelism further.")


# ── vLLM gauge collector — background thread ─────────────────────────────────

class _VllmGaugeCollector(threading.Thread):
    """
    Background daemon thread that polls vLLM /metrics endpoints every
    `interval_s` seconds and writes gauge values to a CSV file.

    Metrics collected per vLLM endpoint (ports 8000-8002):
      vllm:num_requests_running          — Currently active parallel requests
      vllm:num_requests_waiting          — Queued requests awaiting GPU
      vllm:kv_cache_usage_perc           — KV cache saturation (0.0–1.0)
      vllm:prefix_cache_hits_total       — Prefix cache hit counter

    DCGM metric (port 9400, best-effort — may not be available on ROCm):
      dcgm_gpu_utilization               — GPU compute utilisation (0–100)

    CSV columns: timestamp, model, port, metric, value
    """

    @staticmethod
    def _get_endpoints() -> list[tuple[int, str]]:
        from culinary_archivist import config
        return [
            (8000, config.VLLM_TEXT_MODEL.split("/")[-1]),
            (8001, config.VLLM_VISION_MODEL.split("/")[-1]),
            (8002, config.VLLM_EMBED_MODEL.split("/")[-1]),
        ]
    _GAUGE_METRICS = [
        "vllm:num_requests_running",
        "vllm:num_requests_waiting",
        "vllm:kv_cache_usage_perc",
        "vllm:prefix_cache_hits_total",
    ]
    _DCGM_PORT = 9400   # DCGM exporter default — best-effort

    def __init__(self, csv_path: Path, interval_s: float = 0.5) -> None:
        super().__init__(daemon=True, name="VllmGaugeCollector")
        self._csv_path   = csv_path
        self._interval   = interval_s
        self._should_stop = threading.Event()
        csv_path.parent.mkdir(parents=True, exist_ok=True)

    def stop(self) -> None:
        """Signal the thread to stop after the current sleep interval."""
        self._should_stop.set()

    def run(self) -> None:
        import requests

        with self._csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "model", "port", "metric", "value"])
            f.flush()

            # Fire immediately on start, then every interval_s seconds
            while True:
                ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

                # ── vLLM gauge metrics ─────────────────────────────────────
                for port, model in self._get_endpoints():
                    try:
                        resp = requests.get(
                            f"http://{config.VLLM_METRICS_HOST}:{port}/metrics", timeout=3
                        )
                        for line in resp.text.splitlines():
                            if line.startswith("#"):
                                continue
                            for metric in self._GAUGE_METRICS:
                                if line.startswith(metric):
                                    value = line.rsplit(" ", 1)[-1].strip()
                                    writer.writerow([ts, model, port, metric, value])
                    except Exception:
                        pass  # server not yet ready or temporarily unreachable

                # ── DCGM GPU utilisation (best-effort) ────────────────────
                try:
                    resp = requests.get(
                        f"http://{config.VLLM_METRICS_HOST}:{self._DCGM_PORT}/metrics", timeout=3
                    )
                    for line in resp.text.splitlines():
                        if line.startswith("#"):
                            continue
                        if "dcgm_gpu_utilization" in line:
                            value = line.rsplit(" ", 1)[-1].strip()
                            writer.writerow([ts, "GPU", self._DCGM_PORT,
                                             "dcgm_gpu_utilization", value])
                except Exception:
                    pass  # DCGM not available on this host

                f.flush()

                # Wait for next interval or stop signal
                if self._should_stop.wait(timeout=self._interval):
                    break   # stop() was called


# ── vLLM metrics scrape ───────────────────────────────────────────────────────

def _scrape_vllm_metrics(csv_path: Path, total_wall_s: float, n_parallelism_levels: int,
                         n_images: int) -> None:
    """
    One-time snapshot of histogram + counter metrics from all three vLLM endpoints,
    taken after the benchmark completes (cumulative from server start).

    Writes CSV with columns: model, port, metric, bucket_le, value
      bucket_le — le= value for histogram buckets; empty for count/sum/counter lines

    Also appends TPS summary rows per model:
      overall_tps = (prompt_tokens_total + generation_tokens_total) / total_wall_s
      images_per_second = total_images_run / total_wall_s
      avg_tok_per_image = total_tokens / (n_images * n_parallelism_levels)

    Args:
      csv_path: output CSV file path
      total_wall_s: total wall clock time for this benchmark run
      n_parallelism_levels: number of parallelism levels in this run (1, 2, or 3)

    Excludes gauge metrics (gpu_cache_usage_factor, num_requests_running,
    dcgm_gpu_utilization) — those are captured continuously by _VllmGaugeCollector.
    """
    import re
    import requests as _req

    from culinary_archivist import config
    endpoints = [
        (8000, config.VLLM_TEXT_MODEL.split("/")[-1]),
        (8001, config.VLLM_VISION_MODEL.split("/")[-1]),
        (8002, config.VLLM_EMBED_MODEL.split("/")[-1]),
    ]
    # Histogram + counter patterns — gauges excluded (already in vllm_gauge_*.csv)
    histogram_patterns = [
        "request_inference_time_seconds",
        "request_queue_time_seconds",
        "num_requests_waiting",          # final state snapshot only
        "vllm:prompt_tokens_total",      # total input token mass
        "vllm:generation_tokens_total",  # total output token mass
        "vllm:num_preemptions_total",    # KV cache eviction count
    ]

    _section("vLLM HISTOGRAM SNAPSHOT  (cumulative from server start)")
    print(f"  Scraping vLLM /metrics endpoints...")

    # Track token totals per model for TPS calculation
    token_totals: dict[str, dict[str, float]] = {}

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "port", "metric", "bucket_le", "value"])

        for port, model in endpoints:
            print(f"  → port {port} ({model})")
            token_totals[model] = {"prompt": 0.0, "generation": 0.0}
            try:
                resp  = _req.get(f"http://{config.VLLM_METRICS_HOST}:{port}/metrics", timeout=5)
                count = 0
                for line in resp.text.splitlines():
                    if line.startswith("#"):
                        continue
                    if not any(p in line for p in histogram_patterns):
                        continue

                    le_match     = re.search(r'le="([^"]+)"', line)
                    bucket_le    = le_match.group(1) if le_match else ""
                    metric_match = re.match(r'([a-zA-Z_:][a-zA-Z0-9_:]*)', line)
                    metric_name  = metric_match.group(1) if metric_match else line
                    value        = line.rsplit(" ", 1)[-1].strip()

                    writer.writerow([model, port, metric_name, bucket_le, value])
                    count += 1

                    # Collect token totals for TPS
                    try:
                        if "prompt_tokens_total" in metric_name and not bucket_le:
                            token_totals[model]["prompt"] = float(value)
                        elif "generation_tokens_total" in metric_name and not bucket_le:
                            token_totals[model]["generation"] = float(value)
                    except ValueError:
                        pass

                print(f"    {count} rows written")
            except Exception as e:
                print(f"    ERROR: {e}")

        # ── TPS summary rows ──────────────────────────────────────────────────
        # n_images is the authoritative count of images actually processed,
        # passed in from main() (excludes macOS ._ AppleDouble files).
        writer.writerow([])
        writer.writerow(["# TPS SUMMARY", "", "", "", ""])
        writer.writerow(["# total_wall_s", "", "", "", round(total_wall_s, 2)])
        writer.writerow(["# n_images_per_level", "", "", "", n_images])
        writer.writerow(["model", "port", "metric", "bucket_le", "value"])

        # images_per_second — pipeline-level throughput (same across models), written once below
        total_images_run  = n_images * n_parallelism_levels
        images_per_second = round(total_images_run / total_wall_s, 2) if total_wall_s > 0 else 0

        print(f"\n  TPS SUMMARY  (total_wall_s={round(total_wall_s,1)}s  images={n_images}  images/s={images_per_second})")
        print(f"  {'model':<35}  {'prompt_tok':>10}  {'gen_tok':>8}  {'total_tok':>10}  {'overall_tps':>12}  {'avg_tok/img':>14}")
        print(f"  {'─'*35}  {'─'*10}  {'─'*8}  {'─'*10}  {'─'*12}  {'─'*14}")

        for model, totals in token_totals.items():
            prompt_tok  = totals["prompt"]
            gen_tok     = totals["generation"]
            total_tok   = prompt_tok + gen_tok
            # overall_tps — total tokens across entire benchmark / total wall time
            overall_tps = round(total_tok / total_wall_s, 2) if total_wall_s > 0 else 0

            # avg_tokens_per_image — how many tokens each image consumed on average
            avg_tok_per_image = round(total_tok / total_images_run, 1) if total_images_run else 0

            writer.writerow([model, "", "overall_tps",       "", overall_tps])
            writer.writerow([model, "", "avg_tok_per_image", "", avg_tok_per_image])
            writer.writerow([model, "", "prompt_tokens",     "", prompt_tok])
            writer.writerow([model, "", "gen_tokens",        "", gen_tok])
            writer.writerow([model, "", "total_tokens",      "", total_tok])

            short = model.split("/")[-1] if "/" in model else model
            print(f"  {short:<35}  {prompt_tok:>10.0f}  {gen_tok:>8.0f}  "
                  f"{total_tok:>10.0f}  {overall_tps:>12.2f}  {avg_tok_per_image:>14.1f}")

        # Single pipeline-level throughput row (not per-model)
        writer.writerow(["ALL", "", "images_per_second", "", images_per_second])

    print(f"\n  vLLM histogram + TPS CSV → {csv_path}")


def _capture_counter_metrics() -> dict:
    """Capture prefix cache hits counter from vLLM endpoints."""
    import requests

    counters = {
        "prefix_cache_hits": 0,
    }

    ports = [8000, 8001, 8002]
    counter_metrics = [
        "vllm:prefix_cache_hits_total",
    ]

    for port in ports:
        try:
            resp = requests.get(f"http://{config.VLLM_METRICS_HOST}:{port}/metrics", timeout=3)
            for line in resp.text.splitlines():
                if line.startswith("#"):
                    continue
                for metric in counter_metrics:
                    if line.startswith(metric):
                        value = float(line.rsplit(" ", 1)[-1].strip())
                        if "prefix_cache_hits" in metric:
                            counters["prefix_cache_hits"] += value
        except Exception:
            pass

    return counters


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="CulinaryArchivist Ray pipeline benchmark")
    parser.add_argument("--images",   default=str(DATA_DIR))
    parser.add_argument("--parallel", type=int, required=True, metavar="N",
                        help="Parallelism level (required: 1, 4, 8, etc.)")
    parser.add_argument("--timeline", action="store_true",
                        help="Write Chrome trace to output/ after run (open offline in chrome://tracing)")
    parser.add_argument("--gauge-interval", type=float, default=0.5, metavar="S",
                        help="Seconds between gauge metric polls — accepts sub-second "
                             "values, e.g. 0.5 or 0.25 (default 0.5)")
    args = parser.parse_args()

    parallel_levels = [args.parallel]

    images = sorted(
        p for p in Path(args.images).iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
        and not p.name.startswith("._")
    )
    if not images:
        print(f"No images found in {args.images}")
        return

    # ── Build output filenames with timestamp + parallelism level ─────────────
    ts      = time.strftime("%Y%m%d_%H%M%S")
    p_str   = f"p{parallel_levels[0]}"
    txt_path   = OUTPUT_DIR / f"benchmark_{ts}_{p_str}.txt"
    trace_path = OUTPUT_DIR / f"pipeline_trace_{ts}_{p_str}.json" if args.timeline else None

    # ── Tee: everything printed below also lands in txt_path ──────────────────
    tee = _Tee(txt_path)

    print("\n╔══════════════════════════════════════════════════════════════╗")
    print("║  CulinaryArchivist — Ray Pipeline Benchmark (AMD MI350X)     ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(f"  Images         : {len(images)}   Parallelism: {parallel_levels[0]}")
    print(f"  Text report    → {txt_path}")
    if trace_path:
        print(f"  Chrome trace   → {trace_path}")

    # Connect to existing Ray cluster if running, else start local.
    # runtime_env propagates explicit paths to every worker process so
    # config.py path resolution is independent of Ray worker CWD.
    ray.init(
        ignore_reinit_error=True,
        dashboard_host="0.0.0.0",
        dashboard_port=8265,
        _metrics_export_port=9090,
        runtime_env={
            "env_vars": {
                "ARCHIVIST_OUTPUT_DIR":   "/app/CulinaryArchivist_vLLM_ray/output",
                "ARCHIVIST_DATA_DIR":     "/app/CulinaryArchivist_vLLM_ray/data",
                "ARCHIVIST_DB_DIR":       "/app/CulinaryArchivist_vLLM_ray/db",
                "ARCHIVIST_CHROMA_DIR":   "/app/CulinaryArchivist_vLLM_ray/chroma",
                "ARCHIVIST_REGISTRY_DIR": "/app/CulinaryArchivist_vLLM_ray/culinary_archivist/registry",
            }
        },
    )
    print(f"  Ray resources  : {ray.cluster_resources()}")
    print(f"  Metrics port   : http://localhost:9090/metrics")

    metrics_csv = OUTPUT_DIR / f"vllm_metrics_{ts}_{p_str}.csv"
    gauge_csv   = OUTPUT_DIR / f"vllm_gauge_{ts}_{p_str}.csv"
    print(f"  vLLM histogram → {metrics_csv}  (snapshot after run)")
    print(f"  vLLM gauge CSV → {gauge_csv}  (every {args.gauge_interval}s)")

    # Start background gauge collector before sweep begins
    collector = _VllmGaugeCollector(gauge_csv, interval_s=args.gauge_interval)
    collector.start()

    try:
        # Capture start state of prefix cache counter
        print("\n" + "─" * 70)
        print("PREFIX CACHE BASELINE (before sweep)")
        print("─" * 70)
        counters_start = _capture_counter_metrics()
        print(f"  Prefix cache hits:       {counters_start['prefix_cache_hits']:>15.0f}")

        sweep_start  = time.perf_counter()
        run_sweep(images, parallel_levels, trace_path)
        total_wall_s = time.perf_counter() - sweep_start

        # Capture end state and report deltas
        counters_end = _capture_counter_metrics()
        print("\n" + "─" * 70)
        print("PREFIX CACHE AFTER SWEEP (delta)")
        print("─" * 70)
        delta_hits = counters_end["prefix_cache_hits"] - counters_start["prefix_cache_hits"]
        print(f"  Prefix cache hits:       {delta_hits:>15.0f}")

        _scrape_vllm_metrics(metrics_csv, total_wall_s, len(parallel_levels), len(images))
    finally:
        collector.stop()
        collector.join(timeout=10)
        tee.close()   # restore sys.stdout and flush file even if sweep errors

    ray.shutdown()


if __name__ == "__main__":
    main()
