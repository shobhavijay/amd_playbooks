"""
Claim table + run lease on Postgres (INSTALL.md Part 7b).

This is the suite that justifies the migration. The file-backed manifest cannot
fence: it can only answer "already done", and safety rests on the operator
blocking the victim tenant before killing the pod. Here that becomes enforced.

SKIPS cleanly with no Postgres:

    ARCHIVIST_PG_HOST=127.0.0.1 ARCHIVIST_PG_PORT=5433 \
    ARCHIVIST_PG_PASSWORD=testpw ./.venv/bin/python tests/test_postgres_manifest.py
"""
import os, subprocess, sys, textwrap, uuid
from pathlib import Path

PROJ = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJ)

PG = {"ARCHIVIST_STATE_BACKEND": "postgres",
      "ARCHIVIST_PG_HOST":     os.environ.get("ARCHIVIST_PG_HOST", "127.0.0.1"),
      "ARCHIVIST_PG_PORT":     os.environ.get("ARCHIVIST_PG_PORT", "5433"),
      "ARCHIVIST_PG_USER":     os.environ.get("ARCHIVIST_PG_USER", "archivist"),
      "ARCHIVIST_PG_PASSWORD": os.environ.get("ARCHIVIST_PG_PASSWORD", ""),
      "ARCHIVIST_PG_DB":       os.environ.get("ARCHIVIST_PG_DB", "archivist"),
      "ARCHIVIST_STATE_DIR":   "/nonexistent-on-purpose"}
os.environ.update(PG)

RUN = f"etest-{uuid.uuid4().hex[:8]}"
os.environ["ARCHIVIST_RUN_ID"] = RUN

try:
    import psycopg
    from culinary_archivist import config as c
    psycopg.connect(c.PG_DSN, connect_timeout=3).close()
except Exception as exc:                                        # noqa: BLE001
    print(f"SKIP — no Postgres reachable ({type(exc).__name__}: {str(exc)[:80]})")
    sys.exit(0)

from culinary_archivist.manifest import PostgresManifest       # noqa: E402

os.environ["TENANT_NAME"] = "team-a"
m = PostgresManifest()
F = "recipe_001.jpg"

print("=" * 70)
print("1. a fresh recipe can be claimed exactly once")
assert m.claim(F) is True, "first claim should succeed"
assert m.claim(F) is False, "a live claim must not be re-claimable"
print("  ✓ second claim refused while the first is live\n")

print("=" * 70)
print("2. completing it retires the recipe for good")
m.mark(F, status="ok", pdf_path="/state/output/r1.pdf")
assert m.is_done(F) is True
assert m.claim(F) is False, "a completed recipe must never be reclaimed"
assert m.completed == 1
print("  ✓ status=ok is terminal\n")

print("=" * 70)
print("3. a failure is retried, and the attempt count says how often")
G = "recipe_002.jpg"
assert m.claim(G) is True
m.mark(G, status="error", error="vLLM timeout")
assert m.is_done(G) is False
assert m.claim(G) is True, "an errored recipe must be reclaimable"
with m._conn.cursor() as cur:
    cur.execute("SELECT attempt FROM run_manifest WHERE run_id=%s AND file=%s", (RUN, G))
    attempt = cur.fetchone()[0]
print(f"  attempt counter: {attempt}")
assert attempt == 2, attempt
print("  ✓ retried, and the retry is visible — the JSONL manifest never was\n")

print("=" * 70)
print("4. a claim orphaned by a dead pod becomes reclaimable when stale")
H = "recipe_003.jpg"
assert m.claim(H) is True
assert m.claim(H) is False
with m._conn.cursor() as cur:                     # pretend the claimer died an hour ago
    cur.execute("UPDATE run_manifest SET claimed_at = now() - interval '1 hour' "
                "WHERE run_id=%s AND file=%s", (RUN, H))
os.environ["TENANT_NAME"] = "team-b"
assert m.claim(H) is True, "a stale claim must be reclaimable"
with m._conn.cursor() as cur:
    cur.execute("SELECT tenant FROM run_manifest WHERE run_id=%s AND file=%s", (RUN, H))
    assert cur.fetchone()[0] == "team-b"
print("  ✓ reclaimed by team-b, and the row records the new owner\n")

print("=" * 70)
print("5. THE FENCE — a second agent on the same run is refused")
holder = textwrap.dedent(f'''
    import sys, os, time
    sys.path.insert(0, {PROJ!r})
    from culinary_archivist.manifest import PostgresManifest
    m = PostgresManifest()
    assert m.acquire_run_lease(wait_seconds=0), "holder failed to take the lease"
    print("HOLDER-HAS-LEASE", flush=True)
    time.sleep(25)
''')
proc = subprocess.Popen([sys.executable, "-c", holder],
                        env={**os.environ, "PYTHONPATH": PROJ},
                        stdout=subprocess.PIPE, text=True)
assert proc.stdout.readline().strip() == "HOLDER-HAS-LEASE"
print("  agent A holds the lease")

second = textwrap.dedent(f'''
    import sys
    sys.path.insert(0, {PROJ!r})
    from culinary_archivist.manifest import PostgresManifest
    m = PostgresManifest()
    got = m.acquire_run_lease(wait_seconds=3)
    print("SECOND-GOT-LEASE", got)
    sys.exit(0 if not got else 9)
''')
r = subprocess.run([sys.executable, "-c", second],
                   env={**os.environ, "PYTHONPATH": PROJ},
                   capture_output=True, text=True)
assert "SECOND-GOT-LEASE False" in r.stdout, r.stdout + r.stderr
print("  agent B refused, after waiting its bounded window")
print("  ✓ two agents cannot run one run_id — this is the whole point\n")

print("=" * 70)
print("6. the lease is released when the holder dies")
proc.kill(); proc.wait()
m2 = PostgresManifest()
assert m2.acquire_run_lease(wait_seconds=30) is True, "lease not released on death"
print("  ✓ a killed agent's lease is reclaimed with no cleanup code\n")
m2.release_run_lease()

print("=" * 70)
print("7. bumping run_id gives a genuinely clean run")
os.environ["ARCHIVIST_RUN_ID"] = RUN + "-second"
import importlib
from culinary_archivist import config as _c
importlib.reload(_c)
m3 = PostgresManifest()
assert m3.is_done(F) is False, "run_id must scope the manifest"
assert m3.claim(F) is True
print("  ✓ the claim table is keyed on (run_id, file)")
print("    — the file manifest ignored run_id, so a second demo processed zero\n")

print("=" * 70)
print("8. the whole batch loop on Postgres: fail-after 2, then resume")
import tempfile                                                    # noqa: E402
MEDIA = Path(tempfile.mkdtemp(prefix="e2e-")) / "recipes"
MEDIA.mkdir(parents=True)
for i in range(1, 6):
    (MEDIA / f"recipe_{i:03d}.jpg").write_bytes(b"fake")
E2E_RUN = f"{RUN}-e2e"

HARNESS = textwrap.dedent(f'''
    import sys, types
    sys.path.insert(0, {PROJ!r})
    lt = types.ModuleType("langgraph.types")
    class Command:
        def __init__(self, resume=None): self.resume = resume
    lt.Command = Command
    sys.modules["langgraph.types"] = lt
    class _State:
        def __init__(self, v): self.values = v; self.next = (); self.tasks = []
    class _Graph:
        def stream(self, state, config=None, stream_mode=None, durability=None):
            assert durability == "sync"
            yield {{"express_transcription": "ok"}}
        def get_state(self, config):
            return _State({{"pdf_path": "/state/output/x.pdf", "mode": "express",
                            "indexed": True, "errors": []}})
    class _B:
        def compile(self, checkpointer=None): return _Graph()
    g = types.ModuleType("culinary_archivist.graph")
    g.build_graph = lambda: _B()
    sys.modules["culinary_archivist.graph"] = g
    from culinary_archivist.main import main
    main()
''')


def cli(tenant, argv, expect):
    env = {**os.environ, "TENANT_NAME": tenant, "ARCHIVIST_RUN_ID": E2E_RUN,
           "ARCHIVIST_NONINTERACTIVE": "true", "PYTHONPATH": PROJ,
           "ARCHIVIST_DURABLE_CHECKPOINTS": "false"}   # checkpointer not under test here
    r = subprocess.run([sys.executable, "-c", HARNESS, "--media", str(MEDIA)] + argv,
                       env=env, capture_output=True, text=True, cwd=PROJ)
    if r.returncode != expect:
        print(r.stdout[-3000:], r.stderr[-2000:]); sys.exit(1)
    return r.stdout


out = cli("team-a", ["--fail-after", "2"], 42)
assert "--fail-after 2 reached on tenant=team-a" in out, out
print("  team-a: processed 2, exited 42")

out = cli("team-b", [], 0)
assert "2 already completed in a previous attempt" in out, out
assert "\u2192 3 to process on tenant=team-b" in out, out
assert "3/3 succeeded this attempt (5/5 overall)" in out, out
print("  team-b: skipped 2, finished the remaining 3")

with psycopg.connect(_c.PG_DSN, autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT tenant, count(*) FROM run_manifest "
                "WHERE run_id=%s AND status='ok' GROUP BY tenant ORDER BY tenant",
                (E2E_RUN,))
    rows = cur.fetchall()
print(f"  claim table by tenant: {rows}")
assert rows == [("team-a", 2), ("team-b", 3)], rows
print("  \u2713 one batch, one run id, provably split across two tenants\n")

print("=" * 70)
print("ALL POSTGRES MANIFEST CHECKS PASSED")
print("run_id:", RUN)
