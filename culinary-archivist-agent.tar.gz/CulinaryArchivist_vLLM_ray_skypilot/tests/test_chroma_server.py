"""
Chroma SERVER mode, end to end through the app's own store module.

Unlike the other two suites this one needs a running Chroma. It SKIPS cleanly
when there isn't one, so it never breaks a laptop run:

    # terminal 1
    ./.venv/bin/chroma run --path /tmp/chroma-test --host 127.0.0.1 --port 8111
    # terminal 2
    ARCHIVIST_CHROMA_PORT=8111 ./.venv/bin/python tests/test_chroma_server.py

Embeddings come from a fake OpenAI-compatible endpoint on a thread, so no vLLM
and no GPU are involved — only the client/server wiring is under test.
"""
import hashlib, json, os, re, sys, threading, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

HOST = os.environ.get("ARCHIVIST_CHROMA_HOST", "127.0.0.1")
PORT = int(os.environ.get("ARCHIVIST_CHROMA_PORT", "8111"))


def _server_up() -> bool:
    for path in ("/api/v2/heartbeat", "/api/v1/heartbeat"):
        try:
            urllib.request.urlopen(f"http://{HOST}:{PORT}{path}", timeout=3)
            return True
        except Exception:
            continue
    return False


if not _server_up():
    print(f"SKIP — no Chroma server on {HOST}:{PORT}")
    print("      start one with:  ./.venv/bin/chroma run --path /tmp/chroma-test "
          f"--host {HOST} --port {PORT}")
    sys.exit(0)

# ── fake embeddings endpoint ─────────────────────────────────────────────────
# A hashing bag-of-words, not a hash of the whole string: texts that share words
# must come out close together, or ranking assertions below would be testing
# nothing. Still deterministic, still needs no model.
DIM = 64


def _vec(t: str):
    v = [0.0] * DIM
    for w in re.findall(r"[a-z0-9]+", t.lower()):
        v[int(hashlib.sha256(w.encode()).hexdigest(), 16) % DIM] += 1.0
    n = sum(x * x for x in v) ** 0.5 or 1.0
    return [x / n for x in v]


class _H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_GET(self):
        self._json({"object": "list", "data": [{"id": "fake-embed", "object": "model"}]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        inp = body.get("input")
        if isinstance(inp, str):
            inp = [inp]
        self._json({"object": "list", "model": "fake-embed",
                    "data": [{"object": "embedding", "index": i, "embedding": _vec(t)}
                             for i, t in enumerate(inp)],
                    "usage": {"prompt_tokens": 0, "total_tokens": 0}})

    def _json(self, o):
        b = json.dumps(o).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


_srv = HTTPServer(("127.0.0.1", 0), _H)
threading.Thread(target=_srv.serve_forever, daemon=True).start()

os.environ.update({
    "ARCHIVIST_CHROMA_MODE": "server",
    "ARCHIVIST_CHROMA_HOST": HOST,
    "ARCHIVIST_CHROMA_PORT": str(PORT),
    "VLLM_EMBED_BASE_URL": f"http://127.0.0.1:{_srv.server_address[1]}/v1",
    # Nothing in server mode may need a writable state directory.
    "ARCHIVIST_STATE_DIR": "/nonexistent-on-purpose",
})

import chromadb                                                     # noqa: E402
from culinary_archivist import config as c                          # noqa: E402
from culinary_archivist.db import chroma_store as cs                # noqa: E402

# Hermetic: a dedicated collection, so this never reads or writes the real
# `recipes` data and repeat runs cannot contaminate each other.
COLL = f"recipes_test_{os.getpid()}"
cs._COLLECTION_NAME = COLL


def _cleanup():
    try:
        chromadb.HttpClient(host=HOST, port=PORT).delete_collection(COLL)
    except Exception:
        pass


import atexit                                                       # noqa: E402
atexit.register(_cleanup)

print("=" * 70)
print("1. config selects server mode and the store honours it")
assert c.USE_CHROMA_SERVER, "config did not select server mode"
col = cs._get_collection()
assert "Persistent" not in type(cs._client).__name__, type(cs._client)
print(f"  connected to {c.CHROMA_HOST}:{c.CHROMA_PORT} — collection={col.name!r}")
assert col.name == COLL
print(f"  cosine space preserved: {col.metadata}")
assert col.metadata.get("hnsw:space") == "cosine"
print("  ✓ HttpClient, not PersistentClient\n")

print("=" * 70)
print("2. upsert / query / delete reach the server")
before = col.count()
assert before == 0, "dedicated test collection should start empty"
RECS = [
    {"id": "t-fondue", "title": "Cheese Fondue", "region": "ALPINE", "meal_type": "dinner",
     "ingredients": ["gruyere", "white wine"], "steps": ["melt", "stir"]},
    {"id": "t-payasam", "title": "Sameya Payasam", "region": "SOUTH_INDIAN",
     "meal_type": "dessert", "ingredients": ["millet", "jaggery"], "steps": ["boil"]},
]
for r in RECS:
    cs.upsert_recipe(r)
assert cs._get_collection().count() == before + 2, "upsert did not reach the server"
hits = cs.query_similar("Cheese Fondue", n_results=2)
assert hits and hits[0]["id"] == "t-fondue", hits
print(f"  upserted 2, query returned {[h['id'] for h in hits]}")
print("  ✓ round-trip through the server\n")

print("=" * 70)
print("3. the data is server-side, not in this process")
fresh = chromadb.HttpClient(host=HOST, port=PORT)
assert fresh.get_collection(COLL).count() == before + 2
print("  an independent client sees the same rows")
cs._collection = None
cs._client = None                       # reconnect, the way a relaunched pod does
assert cs.delete_recipe("t-fondue") is True
assert cs._get_collection().count() == before + 1
cs.delete_recipe("t-payasam")
print("  ✓ survives a client restart — this is what a tenant move needs\n")

print("=" * 70)
print("ALL CHROMA SERVER CHECKS PASSED")
