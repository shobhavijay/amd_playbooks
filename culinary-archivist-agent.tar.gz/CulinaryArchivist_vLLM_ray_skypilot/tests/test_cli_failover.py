"""Drive culinary_archivist.main's batch loop with a stubbed LangGraph, to test
the actual --fail-after / resume path a demo depends on."""
import os, sys, json, types, tempfile, subprocess, textwrap
from pathlib import Path

PROJ  = str(__import__('pathlib').Path(__file__).resolve().parent.parent)
STATE = tempfile.mkdtemp(prefix="cli-state-")
MEDIA = Path(STATE) / "data" / "recipes"; MEDIA.mkdir(parents=True)
for i in range(1, 9):
    (MEDIA / f"recipe_{i:03d}.jpg").write_bytes(b"fake")

HARNESS = textwrap.dedent(f'''
    import sys, types
    sys.path.insert(0, {PROJ!r})

    # ── stub langgraph.types.Command ─────────────────────────────────────────
    lt = types.ModuleType("langgraph.types")
    class Command:
        def __init__(self, resume=None): self.resume = resume
    lt.Command = Command
    sys.modules["langgraph.types"] = lt

    # ── stub the compiled graph ──────────────────────────────────────────────
    # `next` is NO LONGER hardcoded to (). It used to be, which meant the resume
    # branch of _run_single could never be reached and the suite passed green
    # over a bug that silently dropped recipes. Pending work is file-backed so it
    # survives across processes, the way a real checkpoint survives a dead pod.
    #   ARCHIVIST_TEST_STALL=<substr>  leave work queued once; stream(None) drains it
    #   ARCHIVIST_TEST_STUCK=<substr>  leave work queued and NEVER drain it
    import os as _os, json as _json
    _PEND = _os.path.join(_os.environ.get("ARCHIVIST_STATE_DIR", "."), "_pending.json")
    def _load_pend():
        try:
            with open(_PEND) as fh: return _json.load(fh)
        except Exception: return {{}}
    def _save_pend(d):
        with open(_PEND, "w") as fh: _json.dump(d, fh)

    class _State:
        def __init__(self, values, nxt=()):
            self.values = values; self.next = tuple(nxt); self.tasks = []
    class _Graph:
        def __init__(self): self._seen = {{}}
        def stream(self, state, config=None, stream_mode=None, durability=None):
            assert durability == "sync", f"checkpoints must be synchronous; got {{durability!r}}"
            tid  = config["configurable"]["thread_id"]
            pend = _load_pend()
            if state is not None:
                self._seen[tid] = dict(state)
                path = str(dict(state).get("media_path", ""))
                for knob in ("ARCHIVIST_TEST_STALL", "ARCHIVIST_TEST_STUCK"):
                    m = _os.environ.get(knob, "")
                    if m and m in path:
                        pend[tid] = ["make_pdf"]; _save_pend(pend)
                        print("[stub] pod died mid-recipe — work left queued", flush=True)
                        yield {{"express_transcription": "partial"}}
                        return
            elif _os.environ.get("ARCHIVIST_TEST_STUCK"):
                yield {{"express_transcription": "still stuck"}}   # yields, never advances
                return
            pend.pop(tid, None); _save_pend(pend)
            yield {{"express_transcription": "ok"}}
        def get_state(self, config):
            tid = config["configurable"]["thread_id"]
            return _State({{"pdf_path": f"/state/output/{{tid[-6:]}}.pdf",
                           "mode": "express", "indexed": True, "errors": []}},
                          _load_pend().get(tid, ()))
    class _Builder:
        def compile(self, checkpointer=None): return _Graph()
    g = types.ModuleType("culinary_archivist.graph")
    g.build_graph = lambda: _Builder()
    sys.modules["culinary_archivist.graph"] = g

    from culinary_archivist.main import main
    main()
''')

def run(args, expect_rc=0, state=None, media=None, extra=None):
    env = {**os.environ, "ARCHIVIST_STATE_DIR": state or STATE, "ARCHIVIST_RUN_ID": "demo-01",
           "ARCHIVIST_NONINTERACTIVE": "true", "TENANT_NAME": args["tenant"]}
    env.pop("ARCHIVIST_TEST_STALL", None); env.pop("ARCHIVIST_TEST_STUCK", None)
    env.update(extra or {})
    r = subprocess.run([sys.executable, "-c", HARNESS, "--media", str(media or MEDIA)] + args["argv"],
                       env=env, capture_output=True, text=True, cwd=PROJ)
    if r.returncode != expect_rc:
        print(f"rc={r.returncode} expected {expect_rc}\n{r.stdout}\n{r.stderr}"); sys.exit(1)
    return r.stdout

print("=" * 70)
print("ATTEMPT 1 — team-a, --fail-after 3  (expect exit 42)")
out = run({"tenant": "team-a", "argv": ["--fail-after", "3"]}, expect_rc=42)
print("\n".join(l for l in out.splitlines()
                if any(k in l for k in ("TENANT ", "to process", "fail-after", "Exiting", "recipes done"))))
assert "--fail-after 3 reached on tenant=team-a" in out
assert "Exiting 42" in out
done_a = sum(1 for l in open(Path(STATE)/"output"/"manifest.jsonl") if '"status": "ok"' in l)
assert done_a == 3, f"expected 3 manifest records, got {done_a}"
print(f"  ✓ exited 42 after exactly {done_a} recipes\n")

print("=" * 70)
print("ATTEMPT 2 — team-b resumes (SkyPilot relaunch), no trigger")
out = run({"tenant": "team-b", "argv": []}, expect_rc=0)
print("\n".join(l for l in out.splitlines()
                if any(k in l for k in ("TENANT ", "already completed", "to process", "Batch complete"))))
assert "3 already completed in a previous attempt" in out
assert "→ 5 to process on tenant=team-b" in out
assert "Batch complete on tenant=team-b: 5/5 succeeded this attempt (8/8 overall)" in out
print("  ✓ skipped 3, processed the remaining 5, finished the batch\n")

print("=" * 70)
print("ATTEMPT 3 — rerun is a no-op (idempotent)")
out = run({"tenant": "team-b", "argv": []}, expect_rc=0)
assert "→ 0 to process" in out
print("  ✓ nothing reprocessed\n")

print("=" * 70)
print("--no-resume forces a full reprocess")
out = run({"tenant": "team-a", "argv": ["--no-resume"]}, expect_rc=0)
assert "→ 8 to process" in out
print("  ✓ override works\n")


def _fresh(prefix, n=3):
    d = tempfile.mkdtemp(prefix=prefix)
    m = Path(d) / "data" / "recipes"; m.mkdir(parents=True)
    for i in range(1, n + 1):
        (m / f"recipe_{i:03d}.jpg").write_bytes(b"fake")
    return d, m

def _manifest(state):
    rows = []
    p = Path(state) / "output" / "manifest.jsonl"
    if p.exists():
        for l in open(p):
            if l.strip(): rows.append(json.loads(l))
    return rows

print("=" * 70)
print("MID-RECIPE KILL — work pending with NO interrupt must still be driven")
S1, M1 = _fresh("cli-stall-")
out = run({"tenant": "team-b", "argv": []}, expect_rc=0, state=S1, media=M1,
          extra={"ARCHIVIST_TEST_STALL": "recipe_002"})
assert "[stub] pod died mid-recipe" in out, "the stall never happened"
assert "Batch complete on tenant=team-b: 3/3 succeeded this attempt (3/3 overall)" in out, out
assert all(r["status"] == "ok" for r in _manifest(S1)), _manifest(S1)
print("  ✓ recipe_002 left work queued, stream(None) drove it to completion")
print("    (before the fix this returned DONE with the node unrun)\n")

print("=" * 70)
print("UNFINISHED WORK is never recorded as ok")
S2, M2 = _fresh("cli-stuck-")
out = run({"tenant": "team-a", "argv": []}, expect_rc=0, state=S2, media=M2,
          extra={"ARCHIVIST_TEST_STUCK": "recipe_002"})
rows = {r["file"]: r["status"] for r in _manifest(S2)}
assert rows.get("recipe_002.jpg") == "error", rows
assert "pipeline did not complete" in out
assert rows.get("recipe_001.jpg") == "ok" and rows.get("recipe_003.jpg") == "ok", rows
print("  ✓ recipe_002 recorded status=error, not a false ok")
print("  ✓ the other two recipes still completed\n")

print("=" * 70)
print("RELAUNCH resumes the thread the dead pod left behind")
out = run({"tenant": "team-b", "argv": []}, expect_rc=0, state=S2, media=M2)
assert "RESUMING from checkpoint" in out, "resume branch still not exercised"
assert "→ 1 to process on tenant=team-b" in out, out
rows = [r for r in _manifest(S2) if r["file"] == "recipe_002.jpg"]
assert rows[-1]["status"] == "ok" and rows[-1]["tenant"] == "team-b", rows
print("  ✓ team-b resumed recipe_002 from its pending node and finished it\n")

tenants = set()
for l in open(Path(STATE)/"output"/"manifest.jsonl"):
    if l.strip(): tenants.add(json.loads(l)["tenant"])
print("=" * 70)
print("manifest records tenants:", sorted(tenants))
assert tenants == {"team-a", "team-b"}
print("ALL CLI CHECKS PASSED")
