"""
PDF storage parity: local directory vs S3 (INSTALL.md Part 7b).

Uses moto's threaded S3 server, so the s3 path goes over real HTTP through real
boto3 — no monkeypatched client. Needs no MinIO and no network.

    ./.venv/bin/python tests/test_blob_store.py
"""
import os, subprocess, sys, tempfile, textwrap
from pathlib import Path

PROJ = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJ)

try:
    from moto.server import ThreadedMotoServer
except ImportError:
    print("SKIP — moto[server] not installed:  ./.venv/bin/pip install 'moto[server]'")
    sys.exit(0)

server = ThreadedMotoServer(port=0, verbose=False)
server.start()
S3_PORT = server.get_host_and_port()[1]
ENDPOINT = f"http://127.0.0.1:{S3_PORT}"
print(f"  moto S3 on {ENDPOINT}")

BODY = textwrap.dedent(f'''
    import json, sys
    sys.path.insert(0, {PROJ!r})
    from fpdf import FPDF
    from culinary_archivist.db import blob_store

    NAME = "Cheese_Fondue_20260831_120000.pdf"
    pdf = FPDF(); pdf.add_page(); pdf.set_font("Helvetica", size=12)
    pdf.cell(40, 10, "Cheese Fondue")

    staged = blob_store.staging_path(NAME)
    pdf.output(str(staged))
    uri = blob_store.commit(staged, NAME)

    fetched = blob_store.fetch(uri)
    head = open(fetched, "rb").read(5) if fetched else b""
    print("RESULT " + json.dumps({{
        "backend":       blob_store.BACKEND,
        "uri":           str(uri),
        "is_remote":     blob_store.is_remote(uri),
        "fetch_ok":      fetched is not None,
        "fetched_exists": bool(fetched and fetched.exists()),
        "looks_like_pdf": head == b"%PDF-",
        "staged_leftover": staged.exists() and blob_store.BACKEND == "s3",
        "fetch_missing": blob_store.fetch("s3://nope/none.pdf") is None
                         if blob_store.BACKEND == "s3" else
                         blob_store.fetch("/no/such/file.pdf") is None,
    }}))
''')


def run(extra, label):
    env = {**os.environ, "PYTHONPATH": PROJ, **extra}
    for k in list(env):
        if k.startswith("ARCHIVIST_") and k not in extra:
            del env[k]
    r = subprocess.run([sys.executable, "-c", BODY], env=env,
                       capture_output=True, text=True, cwd=PROJ)
    if r.returncode != 0:
        print(f"--- {label} FAILED ---\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")
        server.stop(); sys.exit(1)
    import json
    return json.loads([l for l in r.stdout.splitlines() if l.startswith("RESULT ")][0][7:])


try:
    print("=" * 70)
    print("1. local backend — unchanged behaviour")
    LOCAL = tempfile.mkdtemp(prefix="blob-local-")
    a = run({"ARCHIVIST_STATE_DIR": LOCAL, "ARCHIVIST_BLOB_STORE": "local"}, "local")
    print(f"  uri        : {a['uri']}")
    assert a["backend"] == "local"
    assert not a["is_remote"], "a filesystem path must not look remote"
    assert a["uri"].startswith(LOCAL), a["uri"]
    assert a["fetched_exists"] and a["looks_like_pdf"]
    assert a["fetch_missing"], "a missing local file must fetch as None"
    assert Path(a["uri"]).exists(), "the PDF must be where pdf_path says it is"
    print("  ✓ writes into ARCHIVIST_STATE_DIR/output, fetch is a no-op\n")

    print("=" * 70)
    print("2. s3 backend — through real boto3 over HTTP")
    b = run({"ARCHIVIST_STATE_DIR": "/nonexistent-on-purpose",
             "ARCHIVIST_BLOB_STORE": "s3",
             "ARCHIVIST_S3_ENDPOINT": ENDPOINT,
             "ARCHIVIST_S3_BUCKET": "archivist",
             "ARCHIVIST_S3_ACCESS_KEY": "test",
             "ARCHIVIST_S3_SECRET_KEY": "test"}, "s3")
    print(f"  uri        : {b['uri']}")
    assert b["backend"] == "s3"
    assert b["is_remote"] and b["uri"] == "s3://archivist/Cheese_Fondue_20260831_120000.pdf"
    assert b["fetched_exists"] and b["looks_like_pdf"], b
    assert not b["staged_leftover"], "the staging temp dir must be cleaned up"
    assert b["fetch_missing"], "a missing object must fetch as None, not raise"
    print("  ✓ uploaded, re-downloaded, staging cleaned up\n")

    print("=" * 70)
    print("3. the object really is in the bucket, not just in our return value")
    import boto3
    from botocore.config import Config as BotoConfig
    s3 = boto3.client("s3", endpoint_url=ENDPOINT,
                      aws_access_key_id="test", aws_secret_access_key="test",
                      region_name="us-east-1",
                      config=BotoConfig(s3={"addressing_style": "path"}))
    keys = [o["Key"] for o in s3.list_objects_v2(Bucket="archivist").get("Contents", [])]
    print(f"  bucket contents: {keys}")
    assert keys == ["Cheese_Fondue_20260831_120000.pdf"], keys
    meta = s3.head_object(Bucket="archivist", Key=keys[0])
    print(f"  content-type   : {meta['ContentType']}  size: {meta['ContentLength']}")
    assert meta["ContentType"] == "application/pdf"
    print("  ✓ an independent client sees the PDF\n")

    print("=" * 70)
    print("4. the Chainlit path: a uri is not a filesystem path")
    print(f"  Path({b['uri']!r}).exists() -> {Path(b['uri']).exists()}   <- the old check")
    assert not Path(b["uri"]).exists()
    print("  blob_store.fetch(uri)      -> a real local file  <- what app.py does now")
    print("  ✓ the UI would have silently shown no PDF without this\n")

    print("=" * 70)
    print("ALL BLOB STORE CHECKS PASSED")
finally:
    server.stop()
