"""
Resume-after-failover on the Postgres backend (INSTALL.md Part 7b).

The point of the state plane is that a pod killed in one tenant can be replaced
by a pod in another tenant that continues the SAME LangGraph thread. This drives
that with real processes and a real Postgres — the SQLite suites cannot, because
their durability boundary is a file on a shared volume.

SKIPS cleanly when no Postgres is reachable, so laptop runs are unaffected:

    ARCHIVIST_PG_HOST=127.0.0.1 ARCHIVIST_PG_PORT=5433 \
    ARCHIVIST_PG_PASSWORD=testpw ./.venv/bin/python tests/test_postgres_checkpointer.py
"""
import os, subprocess, sys, textwrap, uuid
from pathlib import Path

PROJ = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJ)

PG = {"ARCHIVIST_STATE_BACKEND": "postgres",
      "ARCHIVIST_PG_HOST":     os.environ.get("ARCHIVIST_PG_HOST", "127.0.0.1"),
      "ARCHIVIST_PG_PORT":     os.environ.get("ARCHIVIST_PG_PORT", "5433"),
      "ARCHIVIST_PG_USER":     os.environ.get("ARCHIVIST_PG_USER", "archivist"),
      "ARCHIVIST_PG_PASSWORD": os.environ.get("ARCHIVIST_PG_PASSWORD", ""),
      "ARCHIVIST_PG_DB":       os.environ.get("ARCHIVIST_PG_DB", "archivist")}

try:
    import psycopg
    from culinary_archivist import config as _probe_cfg  # noqa: F401
    _dsn_env = {**os.environ, **PG}
    _saved = dict(os.environ); os.environ.update(PG)
    import importlib
    from culinary_archivist import config as _c
    importlib.reload(_c)
    psycopg.connect(_c.PG_DSN, connect_timeout=3).close()
    os.environ.clear(); os.environ.update(_saved)
except Exception as exc:                                    # noqa: BLE001
    print(f"SKIP — no Postgres reachable ({type(exc).__name__}: {str(exc)[:80]})")
    print("      start one with:  initdb -D /tmp/pgd -U postgres --auth=trust && \\")
    print("                       LC_ALL=C pg_ctl -D /tmp/pgd -o '-p 5433' start")
    sys.exit(0)

RUN_ID = f"pgtest-{uuid.uuid4().hex[:8]}"

GRAPH = textwrap.dedent(f'''
    import sys, types, os
    sys.path.insert(0, {PROJ!r})
    g = types.ModuleType("culinary_archivist.graph"); g.build_graph = lambda: None
    sys.modules["culinary_archivist.graph"] = g

    from typing_extensions import TypedDict
    from langgraph.graph import StateGraph, START, END
    from culinary_archivist.checkpointer import get_checkpointer, thread_id_for

    class S(TypedDict, total=False):
        media_path: str
        transcription: str
        pdf_path: str

    def transcribe(state):
        print("   [node] transcribe ran  <- the expensive vision call")
        return {{"transcription": "TRANSCRIBED"}}

    def make_pdf(state):
        if os.getenv("KILL_HERE") == "1":
            print("   [node] make_pdf starting -> pod deleted", flush=True)
            os._exit(137)
        print("   [node] make_pdf ran")
        return {{"pdf_path": "/state/output/recipe_001.pdf"}}

    b = StateGraph(S)
    b.add_node("transcribe", transcribe); b.add_node("make_pdf", make_pdf)
    b.add_edge(START, "transcribe"); b.add_edge("transcribe", "make_pdf")
    b.add_edge("make_pdf", END)
    SAVER = get_checkpointer()
    GRAPH = b.compile(checkpointer=SAVER)
    MEDIA = "/state/data/recipes/recipe_001.jpg"
    CFG = {{"configurable": {{"thread_id": thread_id_for(MEDIA)}}}}
''')


def run(tenant, snippet, kill=False, expect=(0,)):
    env = {**os.environ, **PG,
           "TENANT_NAME": tenant,
           "ARCHIVIST_RUN_ID": RUN_ID,
           "ARCHIVIST_NONINTERACTIVE": "true",
           "ARCHIVIST_STATE_DIR": "/nonexistent-on-purpose",
           "KILL_HERE": "1" if kill else "0",
           "PYTHONPATH": PROJ}
    r = subprocess.run([sys.executable, "-c", GRAPH + textwrap.dedent(snippet)],
                       env=env, capture_output=True, text=True, cwd=PROJ)
    out = "\n".join(l for l in r.stdout.splitlines() if "could not create" not in l)
    print(out, end="" if out.endswith("\n") or not out else "\n")
    if r.returncode not in expect:
        print("STDERR:", r.stderr[-1500:]); sys.exit(1)
    return out


print("=" * 70)
print("1. the Postgres backend is actually selected")
run("team-a", '''
    from culinary_archivist import config as c
    print("   saver :", type(SAVER).__name__)
    print("   dsn   :", c.PG_DSN_SAFE)
    assert type(SAVER).__name__ == "PostgresSaver", type(SAVER)
    assert "***" in c.PG_DSN_SAFE or "@" not in c.PG_DSN_SAFE
''')
print("  ✓ PostgresSaver, password redacted in the log line\n")

print("=" * 70)
print("2. team-a starts the recipe and is killed inside make_pdf")
run("team-a", '''
    for _ in GRAPH.stream({"media_path": MEDIA}, config=CFG,
                          stream_mode="values", durability="sync"): pass
''', kill=True, expect=(137,))
print("  ✓ pod died mid-node, as kubectl delete would leave it\n")

print("=" * 70)
print("3. team-b picks up the SAME thread from Postgres")
out = run("team-b", '''
    st = GRAPH.get_state(CFG)
    print("   recovered:", dict(st.values))
    print("   pending  :", st.next)
    assert st.values.get("transcription") == "TRANSCRIBED", "prior work lost"
    assert st.next == ("make_pdf",), st.next
    for _ in GRAPH.stream(None, config=CFG, stream_mode="values", durability="sync"): pass
    final = GRAPH.get_state(CFG)
    print("   final    :", dict(final.values))
    assert final.values.get("pdf_path"), "did not finish"
    assert final.next == (), final.next
''')
assert "transcribe ran" not in out, "the expensive node was replayed"
print("  ✓ resumed at make_pdf; transcribe was NOT re-run\n")

print("=" * 70)
print("4. durability='sync' is what makes that possible")
out = run("team-a", '''
    import os
    from culinary_archivist import config as c
    print("   CHECKPOINT_DURABILITY =", c.CHECKPOINT_DURABILITY)
    assert c.CHECKPOINT_DURABILITY == "sync"
''')
print("  ✓ async writes would have lost the step the kill interrupted\n")

print("=" * 70)
print("ALL POSTGRES CHECKPOINTER CHECKS PASSED")
print("run_id:", RUN_ID)
