"""
Recipe-store parity: sqlite_store and postgres_store must be interchangeable.

Runs the SAME sequence against each backend in its own process, dumps the
results as JSON, and diffs them. A port is only finished when the caller cannot
tell which one it got.

The Postgres half skips cleanly when no server is reachable; the SQLite half
always runs.
"""
import json, os, subprocess, sys, tempfile, textwrap, uuid
from pathlib import Path

PROJ = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJ)

RID = f"parity-{uuid.uuid4().hex[:8]}"

RECORD = {
    "id": RID,
    "archived_at": "2026-08-31T12:00:00Z",
    "media_path": "/state/data/recipes/fondue.jpg",
    "pdf_path": "/state/output/fondue.pdf",
    "mode": "express",
    "title": "Cheese Fondue",
    "ingredients": ["gruyere", "white wine", "garlic"],
    "steps": ["rub the pot", "melt", "stir"],
    "source_text": "A pot of melted cheese.",
    "region": "ALPINE",
    "sub_region": "Vaud",
    "era": "1950s",
    "origin_consensus": "Switzerland",
    "final_origin": "Switzerland",
    "meal_type": "dinner",
    "is_hybrid": False,
    "unknown_region": True,
    "signal_density": 0.75,
    "orphan_ratio": 0.125,
    "score_margin": 0.4,
    "registry_scores": {"ALPINE": 0.9, "FRENCH": 0.5},
    "tags": ["cheese", "winter"],
    "notes": "Serve with a dry white.",
    "vibe_keywords": ["cosy", "communal"],
    "geo_tag": "46.5197,6.6323",
}

BODY = textwrap.dedent(f'''
    import json, sys
    sys.path.insert(0, {PROJ!r})
    from culinary_archivist.db import recipe_store as store
    rec = json.loads({json.dumps(RECORD)!r})

    store.init_db()
    store.upsert_recipe(rec)
    got = store.get_recipe(rec["id"])

    rec2 = dict(rec); rec2["title"] = "Cheese Fondue (revised)"
    store.upsert_recipe(rec2)                       # upsert must replace, not duplicate
    after = store.get_recipe(rec["id"])

    listed = store.list_recipes(region="ALPINE", limit=10)
    mine = [r for r in listed if r["id"] == rec["id"]]
    filtered_out = store.list_recipes(region="NOWHERE", limit=10)

    deleted = store.delete_recipe(rec["id"])
    twice   = store.delete_recipe(rec["id"])
    gone    = store.get_recipe(rec["id"])

    print("RESULT " + json.dumps({{
        "backend": store.BACKEND,
        "get": got,
        "after_upsert_title": after["title"],
        "list_hits": len(mine),
        "list_row": mine[0] if mine else None,
        "filtered_out_has_mine": any(r["id"] == rec["id"] for r in filtered_out),
        "delete": deleted, "delete_again": twice, "after_delete": gone,
    }}, sort_keys=True, default=str))
''')


def run(env_extra, label):
    env = {**os.environ, "PYTHONPATH": PROJ, **env_extra}
    r = subprocess.run([sys.executable, "-c", BODY], env=env,
                       capture_output=True, text=True, cwd=PROJ)
    if r.returncode != 0:
        print(f"--- {label} FAILED ---\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")
        sys.exit(1)
    line = [l for l in r.stdout.splitlines() if l.startswith("RESULT ")][0]
    return json.loads(line[7:])


print("=" * 70)
print("1. sqlite backend")
SQ = tempfile.mkdtemp(prefix="parity-sq-")
a = run({"ARCHIVIST_STATE_DIR": SQ, "ARCHIVIST_STATE_BACKEND": "sqlite"}, "sqlite")
assert a["backend"] == "sqlite"
print(f"  ingredients : {a['get']['ingredients']}")
print(f"  is_hybrid   : {a['get']['is_hybrid']!r}   unknown_region: {a['get']['unknown_region']!r}")
print(f"  upsert replaced: {a['after_upsert_title']!r}, list hits: {a['list_hits']}")
assert a["get"]["ingredients"] == RECORD["ingredients"]
assert a["get"]["registry_scores"] == RECORD["registry_scores"]
assert a["delete"] is True and a["delete_again"] is False and a["after_delete"] is None
assert a["list_hits"] == 1 and a["filtered_out_has_mine"] is False
print("  ✓ sqlite behaves as before\n")

PG = {"ARCHIVIST_STATE_BACKEND": "postgres",
      "ARCHIVIST_PG_HOST":     os.environ.get("ARCHIVIST_PG_HOST", "127.0.0.1"),
      "ARCHIVIST_PG_PORT":     os.environ.get("ARCHIVIST_PG_PORT", "5433"),
      "ARCHIVIST_PG_USER":     os.environ.get("ARCHIVIST_PG_USER", "archivist"),
      "ARCHIVIST_PG_PASSWORD": os.environ.get("ARCHIVIST_PG_PASSWORD", ""),
      "ARCHIVIST_PG_DB":       os.environ.get("ARCHIVIST_PG_DB", "archivist"),
      "ARCHIVIST_STATE_DIR":   "/nonexistent-on-purpose"}
try:
    import psycopg, importlib
    _saved = dict(os.environ); os.environ.update(PG)
    from culinary_archivist import config as _c
    importlib.reload(_c)
    psycopg.connect(_c.PG_DSN, connect_timeout=3).close()
    os.environ.clear(); os.environ.update(_saved)
except Exception as exc:                                        # noqa: BLE001
    print(f"SKIP the parity half — no Postgres ({type(exc).__name__})")
    print("SQLITE CHECKS PASSED")
    sys.exit(0)

print("=" * 70)
print("2. postgres backend")
b = run(PG, "postgres")
assert b["backend"] == "postgres"
print(f"  ingredients : {b['get']['ingredients']}")
print(f"  is_hybrid   : {b['get']['is_hybrid']!r}   unknown_region: {b['get']['unknown_region']!r}")
print(f"  upsert replaced: {b['after_upsert_title']!r}, list hits: {b['list_hits']}")
print("  ✓ same operations complete on postgres\n")

print("=" * 70)
print("3. PARITY — a caller cannot tell the backends apart")
diffs = []
for key in ("get", "after_upsert_title", "list_hits", "list_row",
            "filtered_out_has_mine", "delete", "delete_again", "after_delete"):
    if a[key] != b[key]:
        diffs.append(key)
if diffs:
    for k in diffs:
        print(f"  MISMATCH {k}:\n    sqlite  : {a[k]}\n    postgres: {b[k]}")
    sys.exit(1)
print("  every field identical, including:")
for f in ("ingredients", "steps", "registry_scores", "tags", "vibe_keywords"):
    print(f"    {f:16} {type(a['get'][f]).__name__:5} == {type(b['get'][f]).__name__}")
for f in ("is_hybrid", "unknown_region"):
    print(f"    {f:16} {a['get'][f]!r} == {b['get'][f]!r}   (int, not bool, on both)")
for f in ("signal_density", "orphan_ratio", "score_margin"):
    print(f"    {f:16} {a['get'][f]!r} == {b['get'][f]!r}")
print("\n  ✓ the dispatcher can swap backends without changing behaviour\n")

print("=" * 70)
print("ALL RECIPE STORE PARITY CHECKS PASSED")
