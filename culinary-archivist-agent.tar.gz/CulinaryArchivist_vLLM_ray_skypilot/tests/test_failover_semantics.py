"""Simulates the A->B move against the real modules: state paths, durable
checkpoints, deterministic thread ids, and manifest-based resume."""
import os, sys, json, subprocess, tempfile, textwrap
from pathlib import Path

PROJ = str(__import__('pathlib').Path(__file__).resolve().parent.parent)
STATE = tempfile.mkdtemp(prefix="archivist-state-")

def run_as_tenant(tenant, snippet, cwd=None, extra=None):
    """Fresh interpreter = a genuinely separate process, like a new pod."""
    # Hermetic: drop any ARCHIVIST_* the caller's shell happens to export, so a
    # developer with the state plane configured still gets the same results.
    base = {k: v for k, v in os.environ.items() if not k.startswith("ARCHIVIST_")}
    env = {**base,
           "ARCHIVIST_STATE_DIR": STATE,
           "TENANT_NAME": tenant,
           "ARCHIVIST_RUN_ID": "demo-01",
           "ARCHIVIST_NONINTERACTIVE": "true",
           "PYTHONPATH": PROJ,
           **(extra or {})}
    code = f"import sys; sys.path.insert(0,{PROJ!r})\n" + textwrap.dedent(snippet)
    r = subprocess.run([sys.executable, "-c", code], env=env,
                       capture_output=True, text=True, cwd=cwd or PROJ)
    if r.returncode != 0:
        print(f"--- {tenant} FAILED ---\n{r.stdout}\n{r.stderr}")
        sys.exit(1)
    return r.stdout

print("=" * 70); print("1. config derives every stateful path from ARCHIVIST_STATE_DIR")
out = run_as_tenant("team-a", """
    from culinary_archivist import config as c
    for k in ("STATE_DIR","OUTPUT_DIR","DB_DIR","CHROMA_DIR","CHECKPOINT_DB_PATH","MANIFEST_PATH"):
        print(f"  {k:20} {getattr(c,k)}")
    print("  TENANT_NAME         ", c.TENANT_NAME)
    print("  vLLM text           ", c.VLLM_TEXT_BASE_URL)
""")
print(out)
assert STATE in out and out.count(STATE) >= 6, "paths not rooted at STATE_DIR"
print("  ✓ all six paths under the shared volume\n")

print("=" * 70); print("2. endpoint resolution: explicit URL wins, else VLLM_HOST")
# archivist.sky.yaml injects explicit URLs, so that path must win.
out = run_as_tenant("team-b", """
    import os
    os.environ["VLLM_TEXT_BASE_URL"]="http://vllm-text.vllm.svc.cluster.local:8000/v1"
    os.environ["VLLM_HOST"]="ignored-host"
    import importlib, culinary_archivist.config as c; importlib.reload(c)
    print("explicit :", c.VLLM_TEXT_BASE_URL)
""")
print("  " + out.strip())
assert "vllm-text.vllm.svc.cluster.local:8000" in out
# and with no explicit URL, one VLLM_HOST moves all four endpoints
_nodotenv = tempfile.mkdtemp(prefix="no-dotenv-")
out2 = run_as_tenant("team-b", """
    import os
    os.environ["VLLM_HOST"]="vllm.team-b.svc"
    from culinary_archivist import config as c
    print("by host  :", c.VLLM_TEXT_BASE_URL, c.VLLM_EMBED_BASE_URL)
""", cwd=_nodotenv)
print("  " + out2.strip())
assert "vllm.team-b.svc:8000" in out2 and "vllm.team-b.svc:8002" in out2
print("  ✓ both precedence rules correct\n")

print("=" * 70); print("3. thread ids are deterministic (the basis of resume)")
a = run_as_tenant("team-a", """
    from culinary_archivist.checkpointer import thread_id_for
    print(thread_id_for("/state/data/recipes/recipe_007.jpg"))
""").strip()
b = run_as_tenant("team-b", """
    from culinary_archivist.checkpointer import thread_id_for
    print(thread_id_for("/somewhere/else/recipe_007.jpg"))
""").strip()
print(f"  team-a: {a}\n  team-b: {b}")
assert a == b, "thread id must survive the move AND a different mount path"
print("  ✓ identical across tenants and mount paths\n")

print("=" * 70); print("4. checkpointer is durable + banner renders")
out = run_as_tenant("team-a", """
    from culinary_archivist import identity
    from culinary_archivist.checkpointer import get_checkpointer
    cp = get_checkpointer(); print("SAVER:", type(cp).__name__)
    identity.print_banner(role="agent (test)")
""")
print(out)
assert "SqliteSaver" in out, "should have picked the durable saver"
assert "TENANT      : team-a" in out
# The GPUs-held row is environment-dependent: identity._gpu_unique_ids() shells
# out to rocm-smi, which exists on the MI300X host but NOT in the agent image
# (python:3.11-slim, no ROCm — the Dockerfile asserts torch/vllm never leak in).
# So a laptop or a pod prints "none", while running this suite on the host prints
# the host's own GPU ids. Both are correct; only the pod case matters for the
# demo, and that is the one the banner is read in.
import shutil as _shutil
if _shutil.which("rocm-smi"):
    assert "GPUs held" in out, "the row must still render on a ROCm host"
    print("  (running on a ROCm host — 'GPUs held' lists the HOST's GPUs;")
    print("   in the agent pod there is no rocm-smi, so it reads 'none')")
else:
    assert "none — this process is a vLLM *client*" in out
db = Path(STATE) / "checkpoints" / "langgraph.sqlite"
assert db.exists() and db.stat().st_size > 0, "checkpoint db not created"
print(f"  ✓ SqliteSaver, db created ({db.stat().st_size} bytes), banner correct\n")

print("=" * 70); print("5. FAILOVER: team-a completes 3, dies; team-b resumes")
run_as_tenant("team-a", """
    from culinary_archivist import config as c
    from culinary_archivist.manifest import DoneManifest
    m = DoneManifest(c.MANIFEST_PATH)
    for i in range(1,4): m.mark(f"/data/recipe_{i:03d}.jpg", pdf_path=f"/state/output/r{i}.pdf")
    print("marked", m.completed)
""")
# a torn final write, exactly as a killed pod would leave it
with open(Path(STATE)/"output"/"manifest.jsonl", "a") as fh:
    fh.write('{"file": "recipe_004.jpg", "sta')

out = run_as_tenant("team-b", """
    from culinary_archivist import config as c
    from culinary_archivist.manifest import DoneManifest
    m = DoneManifest(c.MANIFEST_PATH)
    files = [f"/data/recipe_{i:03d}.jpg" for i in range(1,9)]
    pending = [f for f in files if not m.is_done(f)]
    print("already done :", m.completed)
    print("pending      :", len(pending), [f.split('/')[-1] for f in pending])
""")
print("  " + out.replace("\n","\n  "))
assert "already done : 3" in out and "pending      : 5" in out
recs = [json.loads(l) for l in open(Path(STATE)/"output"/"manifest.jsonl") if l.strip().endswith("}")]
assert {r["tenant"] for r in recs} == {"team-a"}
print("  ✓ 3 skipped, 5 pending, torn line survived, tenant recorded\n")

print("=" * 70); print("6. graceful degradation when the sqlite driver is absent")
env = {**os.environ, "ARCHIVIST_STATE_DIR": STATE, "TENANT_NAME": "team-a",
       "ARCHIVIST_DURABLE_CHECKPOINTS": "false"}
r = subprocess.run([sys.executable, "-c",
    f"import sys; sys.path.insert(0,{PROJ!r});"
    "from culinary_archivist.checkpointer import get_checkpointer;"
    "print(type(get_checkpointer()).__name__)"], env=env, capture_output=True, text=True, cwd=PROJ)
print("  opt-out ->", r.stdout.strip())
assert "MemorySaver" in r.stdout
print("  ✓ falls back cleanly\n")
print("=" * 70); print("7. guard fires when a stray .env pins localhost in a tenant")
out = run_as_tenant("team-b", """
    from culinary_archivist import identity
    identity.print_banner(role="agent (test)")
""")
assert "WARNING" in out and "localhost" in out, "guard did not fire"
print("  " + [l for l in out.splitlines() if "WARNING" in l][0].strip())
out_local = run_as_tenant("local", """
    from culinary_archivist import identity
    identity.print_banner(role="agent (test)")
""")
assert "WARNING" not in out_local, "guard must stay quiet on a laptop"
print("  ✓ fires in a tenant, silent locally\n")

print("=" * 70); print("8. state plane: switches default to the single-node layout")
out = run_as_tenant("local", """
    from culinary_archivist import config as c
    print("  backends:", c.STATE_BACKEND, c.CHROMA_MODE, c.BLOB_STORE)
    print("  flags   :", c.USE_POSTGRES, c.USE_CHROMA_SERVER, c.USE_S3)
    assert (c.STATE_BACKEND, c.CHROMA_MODE, c.BLOB_STORE) == ("sqlite", "persistent", "local")
    assert not (c.USE_POSTGRES or c.USE_CHROMA_SERVER or c.USE_S3)
    assert c.validate_state_config() == []
""")
print(out, end="")
print("  \u2713 an unconfigured process behaves exactly as before\n")

print("=" * 70); print("9. DSN: parts are percent-encoded; an explicit DSN wins")
out = run_as_tenant("team-a", """
    from urllib.parse import urlsplit, unquote
    from culinary_archivist import config as c
    u = urlsplit(c.PG_DSN)
    print("  built   :", c.PG_DSN)
    # libpq percent-decodes URI components; urlsplit deliberately does not.
    assert unquote(u.password) == "p@ss/word+1", u.password
    assert u.hostname == "10.43.1.5" and u.port == 5432 and u.path == "/archivist"
""", extra={"ARCHIVIST_STATE_BACKEND": "postgres", "ARCHIVIST_PG_HOST": "10.43.1.5",
            "ARCHIVIST_PG_PASSWORD": "p@ss/word+1"})
print(out, end="")
out = run_as_tenant("team-a", """
    from culinary_archivist import config as c
    print("  explicit:", c.PG_DSN)
    assert c.PG_DSN == "postgresql://someone:pw@other-host:6543/otherdb"
""", extra={"ARCHIVIST_STATE_BACKEND": "postgres", "ARCHIVIST_PG_HOST": "ignored-host",
            "ARCHIVIST_PG_DSN": "postgresql://someone:pw@other-host:6543/otherdb"})
print(out, end="")
print("  \u2713 special characters survive; explicit beats parts\n")

print("=" * 70); print("10. redaction covers both DSN forms")
out = run_as_tenant("local", """
    from culinary_archivist.config import redact_dsn
    for raw, want in (
        ("postgresql://u:hunter2@h:5432/db",        "postgresql://u:***@h:5432/db"),
        ("postgresql://u@h:5432/db",                "postgresql://u@h:5432/db"),
        ("host=h user=u password=hunter2 dbname=d", "host=h user=u password=*** dbname=d"),
        ("", ""),
    ):
        got = redact_dsn(raw)
        assert got == want, f"{raw!r} -> {got!r} (wanted {want!r})"
        print(f"  {raw or '(empty)':42} -> {got or '(empty)'}")
""")
print(out, end="")
print("  \u2713 no password survives redaction\n")

print("=" * 70); print("11. misconfiguration is caught at startup, not mid-recipe")
for label, extra, needle in (
    ("postgres without credentials", {"ARCHIVIST_STATE_BACKEND": "postgres"}, "ARCHIVIST_PG_DSN"),
    ("s3 without credentials",       {"ARCHIVIST_BLOB_STORE": "s3"},          "ARCHIVIST_S3_ENDPOINT"),
    ("typo in a switch",             {"ARCHIVIST_STATE_BACKEND": "postgress"}, "expected one of"),
):
    out = run_as_tenant("team-a", """
        from culinary_archivist import config as c
        probs = c.validate_state_config()
        assert probs, "expected a problem, got none"
        print("   ", probs[0][:96])
    """, extra=extra)
    assert needle in out, (label, out)
    print(f"  {label:30}", out.strip().split(chr(10))[0].strip()[:60])
print("  \u2713 all three caught\n")

print("=" * 70); print("12. credentials never reach the banner or the logs")
out = run_as_tenant("team-b", """
    import logging; logging.basicConfig(level=logging.DEBUG)
    from culinary_archivist import identity
    identity.print_banner(role="leak check")
""", extra={"ARCHIVIST_STATE_BACKEND": "postgres", "ARCHIVIST_CHROMA_MODE": "server",
            "ARCHIVIST_BLOB_STORE": "s3",
            "ARCHIVIST_PG_HOST": "10.43.1.5", "ARCHIVIST_PG_PASSWORD": "SUPERSECRETPW",
            "ARCHIVIST_CHROMA_HOST": "10.43.1.6",
            "ARCHIVIST_S3_ENDPOINT": "http://10.43.1.7:9000",
            "ARCHIVIST_S3_ACCESS_KEY": "archivist", "ARCHIVIST_S3_SECRET_KEY": "MINIOSECRETPW"})
for secret in ("SUPERSECRETPW", "MINIOSECRETPW"):
    assert secret not in out, f"{secret} leaked into banner/logs"
assert "postgres  10.43.1.5:5432/archivist" in out
assert "chroma server  10.43.1.6:8000" in out
assert "s3  http://10.43.1.7:9000/archivist" in out
print("  banner shows the endpoints, never the secrets:")
print("\n".join(l for l in out.splitlines() if any(
    k in l for k in ("checkpoints :", "vectors     :", "blobs       :"))))
print("  \u2713 0 credential occurrences in banner + DEBUG logs\n")

print("=" * 70); print("13. the agent needs no writable filesystem on the full state plane")
out = run_as_tenant("team-b", """
    from culinary_archivist import config as c
    print("  dirs required:", [str(d) for d in c._needed] or "none")
    assert c._needed == [], "a remote-backend agent must not require local dirs"
""", extra={"ARCHIVIST_STATE_DIR": "/state",          # does not exist here, on purpose
            "ARCHIVIST_STATE_BACKEND": "postgres", "ARCHIVIST_CHROMA_MODE": "server",
            "ARCHIVIST_BLOB_STORE": "s3", "ARCHIVIST_PG_PASSWORD": "x",
            "ARCHIVIST_S3_ENDPOINT": "http://h:9000",
            "ARCHIVIST_S3_ACCESS_KEY": "a", "ARCHIVIST_S3_SECRET_KEY": "b"})
print(out, end="")
print("  \u2713 config imports cleanly with no shared volume at all")
print("    (the two-node topology has no hostPath to mount)\n")

print("=" * 70); print("ALL CHECKS PASSED"); print("state dir:", STATE)
